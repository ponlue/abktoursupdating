-- phpMyAdmin SQL Dump
-- version 2.11.7
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: May 02, 2011 at 11:17 AM
-- Server version: 5.0.51
-- PHP Version: 5.2.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `abktourscom`
--

-- --------------------------------------------------------

--
-- Table structure for table `jos_banner`
--

CREATE TABLE IF NOT EXISTS `jos_banner` (
  `bid` int(11) NOT NULL auto_increment,
  `cid` int(11) NOT NULL default '0',
  `type` varchar(30) NOT NULL default 'banner',
  `name` varchar(255) NOT NULL default '',
  `alias` varchar(255) NOT NULL default '',
  `imptotal` int(11) NOT NULL default '0',
  `impmade` int(11) NOT NULL default '0',
  `clicks` int(11) NOT NULL default '0',
  `imageurl` varchar(100) NOT NULL default '',
  `clickurl` varchar(200) NOT NULL default '',
  `date` datetime default NULL,
  `showBanner` tinyint(1) NOT NULL default '0',
  `checked_out` tinyint(1) NOT NULL default '0',
  `checked_out_time` datetime NOT NULL default '0000-00-00 00:00:00',
  `editor` varchar(50) default NULL,
  `custombannercode` text,
  `catid` int(10) unsigned NOT NULL default '0',
  `description` text NOT NULL,
  `sticky` tinyint(1) unsigned NOT NULL default '0',
  `ordering` int(11) NOT NULL default '0',
  `publish_up` datetime NOT NULL default '0000-00-00 00:00:00',
  `publish_down` datetime NOT NULL default '0000-00-00 00:00:00',
  `tags` text NOT NULL,
  `params` text NOT NULL,
  PRIMARY KEY  (`bid`),
  KEY `viewbanner` (`showBanner`),
  KEY `idx_banner_catid` (`catid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `jos_banner`
--


-- --------------------------------------------------------

--
-- Table structure for table `jos_bannerclient`
--

CREATE TABLE IF NOT EXISTS `jos_bannerclient` (
  `cid` int(11) NOT NULL auto_increment,
  `name` varchar(255) NOT NULL default '',
  `contact` varchar(255) NOT NULL default '',
  `email` varchar(255) NOT NULL default '',
  `extrainfo` text NOT NULL,
  `checked_out` tinyint(1) NOT NULL default '0',
  `checked_out_time` time default NULL,
  `editor` varchar(50) default NULL,
  PRIMARY KEY  (`cid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `jos_bannerclient`
--


-- --------------------------------------------------------

--
-- Table structure for table `jos_bannertrack`
--

CREATE TABLE IF NOT EXISTS `jos_bannertrack` (
  `track_date` date NOT NULL,
  `track_type` int(10) unsigned NOT NULL,
  `banner_id` int(10) unsigned NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `jos_bannertrack`
--


-- --------------------------------------------------------

--
-- Table structure for table `jos_categories`
--

CREATE TABLE IF NOT EXISTS `jos_categories` (
  `id` int(11) NOT NULL auto_increment,
  `parent_id` int(11) NOT NULL default '0',
  `title` varchar(255) NOT NULL default '',
  `name` varchar(255) NOT NULL default '',
  `alias` varchar(255) NOT NULL default '',
  `image` varchar(255) NOT NULL default '',
  `section` varchar(50) NOT NULL default '',
  `image_position` varchar(30) NOT NULL default '',
  `description` text NOT NULL,
  `published` tinyint(1) NOT NULL default '0',
  `checked_out` int(11) unsigned NOT NULL default '0',
  `checked_out_time` datetime NOT NULL default '0000-00-00 00:00:00',
  `editor` varchar(50) default NULL,
  `ordering` int(11) NOT NULL default '0',
  `access` tinyint(3) unsigned NOT NULL default '0',
  `count` int(11) NOT NULL default '0',
  `params` text NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `cat_idx` (`section`,`published`,`access`),
  KEY `idx_access` (`access`),
  KEY `idx_checkout` (`checked_out`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=38 ;

--
-- Dumping data for table `jos_categories`
--

INSERT INTO `jos_categories` (`id`, `parent_id`, `title`, `name`, `alias`, `image`, `section`, `image_position`, `description`, `published`, `checked_out`, `checked_out_time`, `editor`, `ordering`, `access`, `count`, `params`) VALUES
(1, 0, 'category contackform', '', 'category-contackform', 'pastarchives.jpg', 'com_contact_details', 'right', '<p>modules\\mod_slideshow_pro\\photos</p>', 1, 0, '0000-00-00 00:00:00', NULL, 1, 0, 0, ''),
(32, 0, 'Kep Hotel', '', 'kep-hotel', '', '3', 'left', '', 1, 0, '0000-00-00 00:00:00', NULL, 5, 0, 0, ''),
(30, 0, 'Battambang Hotel', '', 'battambang-hotel', '', '3', 'left', '', 1, 0, '0000-00-00 00:00:00', NULL, 1, 0, 0, ''),
(31, 0, 'Kamport Hotels', '', 'kamport-hotels', '', '3', 'left', '', 1, 0, '0000-00-00 00:00:00', NULL, 2, 0, 0, ''),
(29, 0, 'Golf Tours', '', 'golf-tours', '', '2', 'left', '', 1, 0, '0000-00-00 00:00:00', NULL, 3, 0, 0, ''),
(28, 0, 'Phnom Penh Tours', '', 'phnom-penh-tours', '', '2', 'left', '', 1, 0, '0000-00-00 00:00:00', NULL, 4, 0, 0, ''),
(20, 0, 'Travel Guide', '', 'travel-guide', '', '1', 'left', '', 1, 62, '2011-04-21 08:22:45', NULL, 1, 0, 0, ''),
(27, 0, 'Siem Reap Tours', '', 'siem-reap-tours', '', '2', 'left', '', 1, 0, '0000-00-00 00:00:00', NULL, 3, 0, 0, ''),
(26, 0, 'Adventure Tours', '', 'adventure-tours', '', '2', 'left', '', 1, 0, '0000-00-00 00:00:00', NULL, 2, 0, 0, ''),
(25, 0, 'Hooneymoon Tours', '', 'hooneymoon-tours', '', '2', 'left', '', 1, 0, '0000-00-00 00:00:00', NULL, 2, 0, 0, ''),
(24, 0, 'Classic Tours', '', 'classic-tours', '', '2', 'left', '', 1, 0, '0000-00-00 00:00:00', NULL, 1, 0, 0, ''),
(33, 0, 'Koh Kong Hotel', '', 'koh-kong-hotel', '', '3', 'left', '', 1, 0, '0000-00-00 00:00:00', NULL, 3, 0, 0, ''),
(34, 0, 'Kampong Tom Hotel', '', 'kampong-tom-hotel', '', '3', 'left', '', 1, 0, '0000-00-00 00:00:00', NULL, 6, 0, 0, ''),
(35, 0, 'Phnom Penh Hotel', '', 'phnom-penh-hotel', '', '3', 'left', '', 1, 0, '0000-00-00 00:00:00', NULL, 7, 0, 0, ''),
(36, 0, 'Siem Reap Hotel', '', 'siem-reap-hotel', '', '3', 'left', '', 1, 0, '0000-00-00 00:00:00', NULL, 8, 0, 0, ''),
(37, 0, 'Syhanoukvill Hotel', '', 'syhanoukvill-hotel', '', '3', 'left', '', 1, 0, '0000-00-00 00:00:00', NULL, 9, 0, 0, '');

-- --------------------------------------------------------

--
-- Table structure for table `jos_components`
--

CREATE TABLE IF NOT EXISTS `jos_components` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(50) NOT NULL default '',
  `link` varchar(255) NOT NULL default '',
  `menuid` int(11) unsigned NOT NULL default '0',
  `parent` int(11) unsigned NOT NULL default '0',
  `admin_menu_link` varchar(255) NOT NULL default '',
  `admin_menu_alt` varchar(255) NOT NULL default '',
  `option` varchar(50) NOT NULL default '',
  `ordering` int(11) NOT NULL default '0',
  `admin_menu_img` varchar(255) NOT NULL default '',
  `iscore` tinyint(4) NOT NULL default '0',
  `params` text NOT NULL,
  `enabled` tinyint(4) NOT NULL default '1',
  PRIMARY KEY  (`id`),
  KEY `parent_option` (`parent`,`option`(32))
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=147 ;

--
-- Dumping data for table `jos_components`
--

INSERT INTO `jos_components` (`id`, `name`, `link`, `menuid`, `parent`, `admin_menu_link`, `admin_menu_alt`, `option`, `ordering`, `admin_menu_img`, `iscore`, `params`, `enabled`) VALUES
(1, 'Banners', '', 0, 0, '', 'Banner Management', 'com_banners', 0, 'js/ThemeOffice/component.png', 0, 'track_impressions=0\ntrack_clicks=0\ntag_prefix=\n\n', 1),
(2, 'Banners', '', 0, 1, 'option=com_banners', 'Active Banners', 'com_banners', 1, 'js/ThemeOffice/edit.png', 0, '', 1),
(3, 'Clients', '', 0, 1, 'option=com_banners&c=client', 'Manage Clients', 'com_banners', 2, 'js/ThemeOffice/categories.png', 0, '', 1),
(4, 'Web Links', 'option=com_weblinks', 0, 0, '', 'Manage Weblinks', 'com_weblinks', 0, 'js/ThemeOffice/component.png', 0, 'show_comp_description=1\ncomp_description=\nshow_link_hits=1\nshow_link_description=1\nshow_other_cats=1\nshow_headings=1\nshow_page_title=1\nlink_target=0\nlink_icons=\n\n', 1),
(5, 'Links', '', 0, 4, 'option=com_weblinks', 'View existing weblinks', 'com_weblinks', 1, 'js/ThemeOffice/edit.png', 0, '', 1),
(6, 'Categories', '', 0, 4, 'option=com_categories&section=com_weblinks', 'Manage weblink categories', '', 2, 'js/ThemeOffice/categories.png', 0, '', 1),
(7, 'Contacts', 'option=com_contact', 0, 0, '', 'Edit contact details', 'com_contact', 0, 'js/ThemeOffice/component.png', 1, 'contact_icons=0\nicon_address=\nicon_email=\nicon_telephone=\nicon_fax=\nicon_misc=\nshow_headings=1\nshow_position=1\nshow_email=0\nshow_telephone=1\nshow_mobile=1\nshow_fax=1\nbannedEmail=\nbannedSubject=\nbannedText=\nsession=1\ncustomReply=0\n\n', 1),
(8, 'Contacts', '', 0, 7, 'option=com_contact', 'Edit contact details', 'com_contact', 0, 'js/ThemeOffice/edit.png', 1, '', 1),
(9, 'Categories', '', 0, 7, 'option=com_categories&section=com_contact_details', 'Manage contact categories', '', 2, 'js/ThemeOffice/categories.png', 1, 'contact_icons=0\nicon_address=\nicon_email=\nicon_telephone=\nicon_fax=\nicon_misc=\nshow_headings=1\nshow_position=1\nshow_email=0\nshow_telephone=1\nshow_mobile=1\nshow_fax=1\nbannedEmail=\nbannedSubject=\nbannedText=\nsession=1\ncustomReply=0\n\n', 1),
(10, 'Polls', 'option=com_poll', 0, 0, 'option=com_poll', 'Manage Polls', 'com_poll', 0, 'js/ThemeOffice/component.png', 0, '', 1),
(11, 'News Feeds', 'option=com_newsfeeds', 0, 0, '', 'News Feeds Management', 'com_newsfeeds', 0, 'js/ThemeOffice/component.png', 0, '', 1),
(12, 'Feeds', '', 0, 11, 'option=com_newsfeeds', 'Manage News Feeds', 'com_newsfeeds', 1, 'js/ThemeOffice/edit.png', 0, 'show_headings=1\nshow_name=1\nshow_articles=1\nshow_link=1\nshow_cat_description=1\nshow_cat_items=1\nshow_feed_image=1\nshow_feed_description=1\nshow_item_description=1\nfeed_word_count=0\n\n', 1),
(13, 'Categories', '', 0, 11, 'option=com_categories&section=com_newsfeeds', 'Manage Categories', '', 2, 'js/ThemeOffice/categories.png', 0, '', 1),
(14, 'User', 'option=com_user', 0, 0, '', '', 'com_user', 0, '', 1, '', 1),
(15, 'Search', 'option=com_search', 0, 0, 'option=com_search', 'Search Statistics', 'com_search', 0, 'js/ThemeOffice/component.png', 1, 'enabled=0\n\n', 1),
(16, 'Categories', '', 0, 1, 'option=com_categories&section=com_banner', 'Categories', '', 3, '', 1, '', 1),
(17, 'Wrapper', 'option=com_wrapper', 0, 0, '', 'Wrapper', 'com_wrapper', 0, '', 1, '', 1),
(18, 'Mail To', '', 0, 0, '', '', 'com_mailto', 0, '', 1, '', 1),
(19, 'Media Manager', '', 0, 0, 'option=com_media', 'Media Manager', 'com_media', 0, '', 1, 'upload_extensions=bmp,csv,doc,epg,gif,ico,jpg,odg,odp,ods,odt,pdf,png,ppt,swf,txt,xcf,xls,BMP,CSV,DOC,EPG,GIF,ICO,JPG,ODG,ODP,ODS,ODT,PDF,PNG,PPT,SWF,TXT,XCF,XLS\nupload_maxsize=10000000\nfile_path=images\nimage_path=images/stories\nrestrict_uploads=1\ncheck_mime=1\nimage_extensions=bmp,gif,jpg,png\nignore_extensions=\nupload_mime=image/jpeg,image/gif,image/png,image/bmp,application/x-shockwave-flash,application/msword,application/excel,application/pdf,application/powerpoint,text/plain,application/x-zip\nupload_mime_illegal=text/html', 1),
(20, 'Articles', 'option=com_content', 0, 0, '', '', 'com_content', 0, '', 1, 'show_noauth=0\nshow_title=1\nlink_titles=0\nshow_intro=1\nshow_section=0\nlink_section=0\nshow_category=0\nlink_category=0\nshow_author=1\nshow_create_date=1\nshow_modify_date=1\nshow_item_navigation=0\nshow_readmore=1\nshow_vote=0\nshow_icons=1\nshow_pdf_icon=1\nshow_print_icon=1\nshow_email_icon=1\nshow_hits=1\nfeed_summary=0\n\n', 1),
(21, 'Configuration Manager', '', 0, 0, '', 'Configuration', 'com_config', 0, '', 1, '', 1),
(22, 'Installation Manager', '', 0, 0, '', 'Installer', 'com_installer', 0, '', 1, '', 1),
(23, 'Language Manager', '', 0, 0, '', 'Languages', 'com_languages', 0, '', 1, '', 1),
(24, 'Mass mail', '', 0, 0, '', 'Mass Mail', 'com_massmail', 0, '', 1, 'mailSubjectPrefix=\nmailBodySuffix=\n\n', 1),
(25, 'Menu Editor', '', 0, 0, '', 'Menu Editor', 'com_menus', 0, '', 1, '', 1),
(27, 'Messaging', '', 0, 0, '', 'Messages', 'com_messages', 0, '', 1, '', 1),
(28, 'Modules Manager', '', 0, 0, '', 'Modules', 'com_modules', 0, '', 1, '', 1),
(29, 'Plugin Manager', '', 0, 0, '', 'Plugins', 'com_plugins', 0, '', 1, '', 1),
(30, 'Template Manager', '', 0, 0, '', 'Templates', 'com_templates', 0, '', 1, '', 1),
(31, 'User Manager', '', 0, 0, '', 'Users', 'com_users', 0, '', 1, 'allowUserRegistration=1\nnew_usertype=Registered\nuseractivation=1\nfrontend_userparams=1\n\n', 1),
(32, 'Cache Manager', '', 0, 0, '', 'Cache', 'com_cache', 0, '', 1, '', 1),
(33, 'Control Panel', '', 0, 0, '', 'Control Panel', 'com_cpanel', 0, '', 1, '', 1),
(54, 'Plugins', '', 0, 34, 'option=com_joomfish&task=plugin.show', 'Plugins', 'com_joomfish', 8, 'components/com_joomfish/assets/images/icon-16-plugin.png', 0, '', 1),
(53, 'Content elements', '', 0, 34, 'option=com_joomfish&task=elements.show', 'Content elements', 'com_joomfish', 7, 'components/com_joomfish/assets/images/icon-16-extension.png', 0, '', 1),
(52, 'Languages', '', 0, 34, 'option=com_joomfish&task=languages.show', 'Languages', 'com_joomfish', 6, 'components/com_joomfish/assets/images/icon-16-language.png', 0, '', 1),
(51, '', '', 0, 34, 'option=com_joomfish', '', 'com_joomfish', 5, 'components/com_joomfish/assets/images/icon-10-blank.png', 0, '', 1),
(50, 'Statistics', '', 0, 34, 'option=com_joomfish&task=statistics.overview', 'Statistics', 'com_joomfish', 4, 'components/com_joomfish/assets/images/icon-16-statistics.png', 0, '', 1),
(49, 'Manage Translations', '', 0, 34, 'option=com_joomfish&task=manage.overview', 'Manage Translations', 'com_joomfish', 3, 'components/com_joomfish/assets/images/icon-16-manage.png', 0, '', 1),
(48, 'Orphan Translations', '', 0, 34, 'option=com_joomfish&task=translate.orphans', 'Orphan Translations', 'com_joomfish', 2, 'components/com_joomfish/assets/images/icon-16-orphan.png', 0, '', 1),
(47, 'Translation', '', 0, 34, 'option=com_joomfish&task=translate.overview', 'Translation', 'com_joomfish', 1, 'components/com_joomfish/assets/images/icon-16-translation.png', 0, '', 1),
(46, 'Control Panel', '', 0, 34, 'option=com_joomfish', 'Control Panel', 'com_joomfish', 0, 'components/com_joomfish/assets/images/icon-16-cpanel.png', 0, '', 1),
(34, 'Joom!Fish', 'option=com_joomfish', 0, 0, 'option=com_joomfish', 'Joom!Fish', 'com_joomfish', 0, 'components/com_joomfish/assets/images/icon-16-joomfish.png', 0, 'noTranslation=2\ndefaultText=\noverwriteGlobalConfig=1\nstorageOfOriginal=md5\nfrontEndPublish=1\nfrontEndPreview=1\nshowDefaultLanguageAdmin=0\ncopyparams=1\ntranscaching=0\ncachelife=180\nqacaching=1\nqalogging=0\n', 1),
(55, '', '', 0, 34, 'option=com_joomfish', '', 'com_joomfish', 9, 'components/com_joomfish/assets/images/icon-10-blank.png', 0, '', 1),
(56, 'Help', '', 0, 34, 'option=com_joomfish&task=help.show', 'Help', 'com_joomfish', 10, 'components/com_joomfish/assets/images/icon-16-help.png', 0, '', 1),
(57, 'Fade Gallery', 'option=com_fadegallery', 0, 0, 'option=com_fadegallery', 'Fade Gallery', 'com_fadegallery', 0, 'js/ThemeOffice/component.png', 0, '', 0),
(133, 'ContactMap', 'option=com_contactmap', 0, 0, 'option=com_contactmap', 'ContactMap', 'com_contactmap', 0, 'components/com_contactmap/images/logo_contactmap.png', 0, 'contactmap_height=500\r\ncontactmap_width=500\r\ncontactmap_auto=1\r\ncontactmap_centre_lat=47.927644470\r\ncontactmap_centre_lng=2.1391367912\r\ncontactmap_zoom=5\r\ncontactmap_zoom_lightbox_carte=0\r\ncontactmap_zoom_lightbox_imprimer=0\r\ncontactmap_width_bulle_contactmap=400\r\ncontactmap_taille_bulle_cesure=200\r\ncontactmap_itineraire=1\r\ncontactmap_traffic=1\r\ncontactmap_streetView=1\r\ncontactmap_height_sv=500\r\ncontactmap_photo_icon=0\r\ncontactmap_normal=1\r\ncontactmap_satellite=1\r\ncontactmap_hybrid=1\r\ncontactmap_physic=1\r\ncontactmap_vertical=1\r\ncontactmap_choix_affichage_carte=1\r\ncontactmap_mapcontrol=1\r\ncontactmap_scalecontrol=1\r\ncontactmap_mousewheel=1\r\ncontactmap_afficher_horaires_prix=1\r\ncontactmap_hauteur_img=100\r\ncontactmap_afficher_captcha=1\r\ncontactmap_geoXML=\r\ncontactmap_licence=1', 1),
(84, 'Vinaora Visitors Counter', 'option=com_vvisit_counter', 0, 0, 'option=com_vvisit_counter', 'Vinaora Visitors Counter', 'com_vvisit_counter', 0, 'js/ThemeOffice/component.png', 0, '', 0),
(146, 'T Booking', 'option=com_ttbooking', 0, 0, 'option=com_ttbooking', 'T Booking', 'com_ttbooking', 0, 'js/ThemeOffice/component.png', 0, '', 1),
(134, 'Accueil', '', 0, 133, 'option=com_contactmap', 'Accueil', 'com_contactmap', 0, 'js/ThemeOffice/cpanel.png', 0, '', 1),
(135, 'Contacts', '', 0, 133, 'option=com_contactmap&controller=contactmap&task=view', 'Contacts', 'com_contactmap', 1, 'js/ThemeOffice/user.png', 0, '', 1),
(136, 'Categories', '', 0, 133, 'option=com_categories&section=com_contact_details', 'Categories', 'com_contactmap', 2, 'js/ThemeOffice/category.png', 0, '', 1),
(137, 'Marqueurs', '', 0, 133, 'option=com_contactmap&controller=marqueurs&task=view', 'Marqueurs', 'com_contactmap', 3, 'components/com_contactmap/images/marqueur.png', 0, '', 1),
(138, 'CSS', '', 0, 133, 'option=com_contactmap&controller=css&task=view', 'CSS', 'com_contactmap', 4, 'js/ThemeOffice/content.png', 0, '', 1);

-- --------------------------------------------------------

--
-- Table structure for table `jos_contactmap_marqueurs`
--

CREATE TABLE IF NOT EXISTS `jos_contactmap_marqueurs` (
  `id` int(11) NOT NULL auto_increment,
  `nom` text NOT NULL,
  `url` text NOT NULL,
  `published` tinyint(1) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=50 ;

--
-- Dumping data for table `jos_contactmap_marqueurs`
--

INSERT INTO `jos_contactmap_marqueurs` (`id`, `nom`, `url`, `published`) VALUES
(1, 'marqueur', 'http://www.google.com/mapfiles/marker.png', 1),
(2, 'marqueur home', 'http://chart.apis.google.com/chart?chst=d_map_xpin_icon&chld=pin_star|home|FFFF00|FF0000', 1),
(3, 'marqueur flag', 'http://chart.apis.google.com/chart?chst=d_map_xpin_icon&chld=pin_star|flag|FFFF00|FF0000', 1),
(4, 'marqueur info', 'http://chart.apis.google.com/chart?chst=d_map_xpin_icon&chld=pin_star|info|FFFF00|FF0000', 1),
(5, 'marqueur bar', 'http://chart.apis.google.com/chart?chst=d_map_xpin_icon&chld=pin_star|bar|FFFF00|FF0000', 1),
(6, 'marqueur cafe', 'http://chart.apis.google.com/chart?chst=d_map_xpin_icon&chld=pin_star|cafe|FFFF00|FF0000', 1),
(7, 'marqueur perso', 'http://chart.apis.google.com/chart?chst=d_map_spin&chld=1.2|0|FF0000|10|_|foo|bar', 1),
(8, 'marqueurA', 'http://www.google.com/mapfiles/markerA.png', 1),
(9, 'marqueurB', 'http://www.google.com/mapfiles/markerB.png', 1),
(10, 'marqueurC', 'http://www.google.com/mapfiles/markerC.png', 1),
(11, 'marqueurD', 'http://www.google.com/mapfiles/markerD.png', 1),
(12, 'marqueurE', 'http://www.google.com/mapfiles/markerE.png', 1),
(13, 'marqueurF', 'http://www.google.com/mapfiles/markerF.png', 1),
(14, 'marqueurG', 'http://www.google.com/mapfiles/markerG.png', 1),
(15, 'marqueurH', 'http://www.google.com/mapfiles/markerH.png', 1),
(16, 'marqueurI', 'http://www.google.com/mapfiles/markerI.png', 1),
(17, 'marqueurJ', 'http://www.google.com/mapfiles/markerJ.png', 1),
(18, 'marqueurK', 'http://www.google.com/mapfiles/markerK.png', 1),
(19, 'marqueurL', 'http://www.google.com/mapfiles/markerL.png', 1),
(20, 'marqueurM', 'http://www.google.com/mapfiles/markerM.png', 1),
(21, 'marqueurN', 'http://www.google.com/mapfiles/markerN.png', 1),
(22, 'marqueurO', 'http://www.google.com/mapfiles/markerO.png', 1),
(23, 'marqueurP', 'http://www.google.com/mapfiles/markerP.png', 1),
(24, 'marqueurQ', 'http://www.google.com/mapfiles/markerQ.png', 1),
(25, 'marqueurR', 'http://www.google.com/mapfiles/markerR.png', 1),
(26, 'marqueurS', 'http://www.google.com/mapfiles/markerS.png', 1),
(27, 'marqueurT', 'http://www.google.com/mapfiles/markerT.png', 1),
(28, 'marqueurU', 'http://www.google.com/mapfiles/markerU.png', 1),
(29, 'marqueurV', 'http://www.google.com/mapfiles/markerV.png', 1),
(30, 'marqueurW', 'http://www.google.com/mapfiles/markerW.png', 1),
(31, 'marqueurX', 'http://www.google.com/mapfiles/markerX.png', 1),
(32, 'marqueurY', 'http://www.google.com/mapfiles/markerY.png', 1),
(33, 'marqueurZ', 'http://www.google.com/mapfiles/markerZ.png', 1),
(34, 'marqueurBleu', 'http://maps.gstatic.com/intl/fr_ALL/mapfiles/ms/micons/blue-dot.png', 1),
(35, 'marqueurVert', 'http://maps.gstatic.com/intl/fr_ALL/mapfiles/ms/micons/green-dot.png', 1),
(36, 'marqueurOrange', 'http://maps.gstatic.com/intl/fr_ALL/mapfiles/ms/micons/orange-dot.png', 1),
(37, 'marqueurJaune', 'http://maps.gstatic.com/intl/fr_ALL/mapfiles/ms/micons/yellow-dot.png', 1),
(38, 'marqueurViolet', 'http://maps.gstatic.com/intl/fr_ALL/mapfiles/ms/micons/purple-dot.png', 1),
(39, 'marqueurRose', 'http://maps.gstatic.com/intl/fr_ALL/mapfiles/ms/micons/pink-dot.png', 1),
(40, 'purple', 'http://labs.google.com/ridefinder/images/mm_20_purple.png', 1),
(41, 'yellow', 'http://labs.google.com/ridefinder/images/mm_20_yellow.png', 1),
(42, 'blue', 'http://labs.google.com/ridefinder/images/mm_20_blue.png', 1),
(43, 'white', 'http://labs.google.com/ridefinder/images/mm_20_white.png', 1),
(44, 'green', 'http://labs.google.com/ridefinder/images/mm_20_green.png', 1),
(45, 'red', 'http://labs.google.com/ridefinder/images/mm_20_red.png', 1),
(46, 'black', 'http://labs.google.com/ridefinder/images/mm_20_black.png', 1),
(47, 'orange', 'http://labs.google.com/ridefinder/images/mm_20_orange.png', 1),
(48, 'gray', 'http://labs.google.com/ridefinder/images/mm_20_gray.png', 1),
(49, 'brown', 'http://labs.google.com/ridefinder/images/mm_20_brown.png', 1);

-- --------------------------------------------------------

--
-- Table structure for table `jos_contact_details`
--

CREATE TABLE IF NOT EXISTS `jos_contact_details` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(255) NOT NULL default '',
  `alias` varchar(255) NOT NULL default '',
  `con_position` varchar(255) default NULL,
  `address` text,
  `suburb` varchar(100) default NULL,
  `state` varchar(100) default NULL,
  `country` varchar(100) default NULL,
  `postcode` varchar(100) default NULL,
  `telephone` varchar(255) default NULL,
  `fax` varchar(255) default NULL,
  `misc` mediumtext,
  `message` mediumtext,
  `horaires_prix` mediumtext,
  `link` varchar(200) default NULL,
  `article_id` int(100) NOT NULL default '0',
  `icon` varchar(100) default NULL,
  `icon_label` varchar(100) default NULL,
  `affichage` smallint(1) NOT NULL default '0',
  `marqueur` varchar(200) default NULL,
  `glng` varchar(12) default NULL,
  `glat` varchar(12) default NULL,
  `gzoom` varchar(2) default NULL,
  `metadesc` text,
  `metakey` text,
  `image` varchar(255) default NULL,
  `imagepos` varchar(20) default NULL,
  `email_to` varchar(255) default NULL,
  `default_con` tinyint(1) unsigned NOT NULL default '0',
  `published` tinyint(1) unsigned NOT NULL default '0',
  `checked_out` int(11) unsigned NOT NULL default '0',
  `checked_out_time` datetime NOT NULL default '0000-00-00 00:00:00',
  `ordering` int(11) NOT NULL default '0',
  `params` text NOT NULL,
  `user_id` int(11) NOT NULL default '0',
  `catid` int(11) NOT NULL default '0',
  `access` tinyint(3) unsigned NOT NULL default '0',
  `mobile` varchar(255) NOT NULL default '',
  `webpage` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`id`),
  KEY `catid` (`catid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `jos_contact_details`
--


-- --------------------------------------------------------

--
-- Table structure for table `jos_content`
--

CREATE TABLE IF NOT EXISTS `jos_content` (
  `id` int(11) unsigned NOT NULL auto_increment,
  `title` varchar(255) NOT NULL default '',
  `alias` varchar(255) NOT NULL default '',
  `title_alias` varchar(255) NOT NULL default '',
  `introtext` mediumtext NOT NULL,
  `fulltext` mediumtext NOT NULL,
  `state` tinyint(3) NOT NULL default '0',
  `sectionid` int(11) unsigned NOT NULL default '0',
  `mask` int(11) unsigned NOT NULL default '0',
  `catid` int(11) unsigned NOT NULL default '0',
  `created` datetime NOT NULL default '0000-00-00 00:00:00',
  `created_by` int(11) unsigned NOT NULL default '0',
  `created_by_alias` varchar(255) NOT NULL default '',
  `modified` datetime NOT NULL default '0000-00-00 00:00:00',
  `modified_by` int(11) unsigned NOT NULL default '0',
  `checked_out` int(11) unsigned NOT NULL default '0',
  `checked_out_time` datetime NOT NULL default '0000-00-00 00:00:00',
  `publish_up` datetime NOT NULL default '0000-00-00 00:00:00',
  `publish_down` datetime NOT NULL default '0000-00-00 00:00:00',
  `images` text NOT NULL,
  `urls` text NOT NULL,
  `attribs` text NOT NULL,
  `version` int(11) unsigned NOT NULL default '1',
  `parentid` int(11) unsigned NOT NULL default '0',
  `ordering` int(11) NOT NULL default '0',
  `metakey` text NOT NULL,
  `metadesc` text NOT NULL,
  `access` int(11) unsigned NOT NULL default '0',
  `hits` int(11) unsigned NOT NULL default '0',
  `metadata` text NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `idx_section` (`sectionid`),
  KEY `idx_access` (`access`),
  KEY `idx_checkout` (`checked_out`),
  KEY `idx_state` (`state`),
  KEY `idx_catid` (`catid`),
  KEY `idx_createdby` (`created_by`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=19 ;

--
-- Dumping data for table `jos_content`
--

INSERT INTO `jos_content` (`id`, `title`, `alias`, `title_alias`, `introtext`, `fulltext`, `state`, `sectionid`, `mask`, `catid`, `created`, `created_by`, `created_by_alias`, `modified`, `modified_by`, `checked_out`, `checked_out_time`, `publish_up`, `publish_down`, `images`, `urls`, `attribs`, `version`, `parentid`, `ordering`, `metakey`, `metadesc`, `access`, `hits`, `metadata`) VALUES
(1, 'test en', 'test-en', '', '<p align="left"><strong><span style="font-family: Arial; color: #333333; font-size: xx-small;"><span style="font-family: Arial; color: #333333; font-size: xx-small;"><span style="font-family: Arial; color: #333333; font-size: xx-small;"><strong><span style="font-family: Arial; color: #333333; font-size: xx-small;"><span style="font-family: Arial; color: #333333; font-size: xx-small;"><span style="font-family: Arial; color: #333333; font-size: xx-small;">ota Importante:</span></span></span></strong></span></span></span></strong><span style="font-family: Arial; color: #333333; font-size: xx-small;"><span style="font-family: Arial; color: #333333; font-size: xx-small;"><span style="font-family: Arial; color: #333333; font-size: xx-small;">Las cadenas de texto o lo que se entiende por "VARCHAR" o "TEXT"deben de ir entre comillas. Los números no tienen porque ir entre comillas.</span></span></span><strong><span style="font-family: Arial; color: #333333; font-size: xx-small;"><span style="font-family: Arial; color: #333333; font-size: xx-small;"><span style="font-family: Arial; color: #333333; font-size: xx-small;">Nota Importante 2: </span></span></span></strong><span style="font-family: Arial; color: #333333; font-size: xx-small;"><span style="font-family: Arial; color: #333333; font-size: xx-small;"><span style="font-family: Arial; color: #333333; font-size: xx-small;">Como norma general debes respetar las mayúsculas y minúsculas en los</span></span></span></p>\r\n<p align="left"><span style="font-family: Arial; color: #333333; font-size: xx-small;"><span style="font-family: Arial; color: #333333; font-size: xx-small;"><span style="font-family: Arial; color: #333333; font-size: xx-small;"> </span></span></span></p>\r\n<p align="left"><span style="font-family: Arial; color: #333333; font-size: xx-small;"><span style="font-family: Arial; color: #333333; font-size: xx-small;"><span style="font-family: Arial; color: #333333; font-size: xx-small;">{besps}simpleslideshow{/besps}</span></span></span></p>', '', -2, 0, 0, 0, '2011-04-01 13:58:22', 62, '', '2011-04-01 18:07:31', 62, 0, '0000-00-00 00:00:00', '2011-04-01 13:58:22', '0000-00-00 00:00:00', '', '', 'show_title=\nlink_titles=\nshow_intro=\nshow_section=\nlink_section=\nshow_category=\nlink_category=\nshow_vote=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nlanguage=en-GB\nkeyref=\nreadmore=', 4, 0, 0, '', '', 0, 1, 'robots=\nauthor='),
(2, 'About Cambodia', 'about-cambodia', '', '<p><img src="images/stories/1692357.jpg" border="0" width="200" height="130" style="float: left; border: 1px solid black; margin-left: 10px; margin-right: 10px; margin-top: 1px; margin-bottom: 1px;" /></p>\r\n<p style="text-align: justify;">No one knows for certain how long people have lived in what is now Cambodia, as studies of its prehistory are undeveloped. A carbon-l4 dating from a cave in northwestern Cambodia suggests that people using stone tools lived in the ave as early as 4000 bc, and rice has been grown on Cambodian soil since well before the 1st century ad. The first Cambodians.{BookingWizard}elll{BookingWizard}</p>\r\n<p><strong> </strong></p>\r\n<p><strong> </strong></p>\r\n', '\r\n<p>The Khmer Kingdom (Funan)</p>\r\n<p style="text-align: justify;">Early Chinese writers referred to a kingdom in Cambodia that they called Funan. Modern-day archaeological findings provide evidence of a commercial society centered on the Mekong Delta that flourished from the 1st century to the 6th century. Among these findings are excavations of a port city from the 1st century, located in the region of Oc-Eo in what is now southern Vietnam. Served by a network of canals, the city was an important trade link between India and China. Ongoing excavations in southern Cambodia have revealed the existence of another important city near the present-day village of Angkor Borei.</p>\r\n<p style="text-align: justify;"><strong><em>A group of inland kingdoms, known collectively to the Chinese as Zhenla, flourished in the 6th and 7th centuries from southern Cambodia to southern Laos. The first stone inscriptions in the Khmer language and the first brick and stone Hindu temples in Cambodia date from the Zhenla period.</em></strong></p>\r\n<p> </p>', 1, 0, 0, 0, '2011-04-02 04:43:03', 62, '', '2011-04-21 08:03:05', 62, 0, '0000-00-00 00:00:00', '2011-04-02 04:43:03', '0000-00-00 00:00:00', '', '', 'show_title=1\nlink_titles=0\nshow_intro=0\nshow_section=0\nlink_section=0\nshow_category=0\nlink_category=0\nshow_vote=0\nshow_author=0\nshow_create_date=0\nshow_modify_date=0\nshow_pdf_icon=0\nshow_print_icon=1\nshow_email_icon=1\nlanguage=en-GB\nkeyref=\nreadmore=', 36, 0, 5, '', '', 0, 30, 'robots=\nauthor='),
(3, 'About Cambodia Trip', 'about-cambodia-trip', '', '<p style="text-align: justify;"><img src="images/stories/55350715__f2p0166.jpg" border="0" width="200" height="130" style="float: left; border: 1px solid black; margin-left: 10px; margin-right: 10px; margin-top: 1px; margin-bottom: 1px;" /></p>\r\n<p style="text-align: justify;"><span class="hps" title="Click for alternate translations"> </span></p>\r\n<p style="text-align: justify;">Cambodia trip advisor.com has been operating as a full service travel agency in Cambodia for nearly 10 years, and was fully licensed by Cambodia National Authority For Tourism as an International Tour Operator License 028/10 A.T.C.G.B.R.Y. We are specializing in tailor-made and customized tours for couples, families and groups, those looking for a valuable…</p>\r\n<p style="text-align: justify;"> </p>\r\n', '\r\n<p style="text-align: justify;">A Walk to Remember</p>\r\n<p style="text-align: justify;">It was simply a fabulous trip organized by my responsible pals at Angkorwat Discovery.com. It would have been a real miss, if we would have skipped the trip, as we decided initially, but it was predestined and so we made it and packed our bags and set forth on the wondrous journey to Combodia. All the destinations we have explored in the beautiful country were just splendid but the place I have loved the most was Angkor Wat. I have simply fallen in love with the surroundings of the picturesque location. The friendly guide provided by Angkorwat Discovery.com has depicted the essence of the various landmarks so vividly, that for a while it seemed that we have been transported to those lost eras.. His communication skill was just excellent, , he was honest and out and out professional. Mr David indeed made the trip a cherishing one. The thanks go to none other than Angkor Wat Discovery. We drove all around in a big air conditioned car to the great locations like Siem and others. I recommend you to all, who are travelers at heart</p>', 1, 0, 0, 0, '2011-04-02 04:49:36', 62, '', '2011-04-21 08:09:59', 62, 0, '0000-00-00 00:00:00', '2011-04-02 04:49:36', '0000-00-00 00:00:00', '', '', 'show_title=1\nlink_titles=0\nshow_intro=1\nshow_section=0\nlink_section=0\nshow_category=0\nlink_category=0\nshow_vote=0\nshow_author=0\nshow_create_date=0\nshow_modify_date=0\nshow_pdf_icon=0\nshow_print_icon=1\nshow_email_icon=1\nlanguage=en-GB\nkeyref=\nreadmore=', 36, 0, 4, '', '', 0, 25, 'robots=\nauthor='),
(4, 'Travel Trip Review', 'travel-trip-review', '', '<p style="text-align: justify"><img src="images/stories/62997628_ww8ndkv3__f2p4226.jpg" border="0" width="200" height="130" style="float: left; border: 1px solid black; margin-left: 10px; margin-right: 10px; margin-top: 1px; margin-bottom: 1px;" /></p>\r\n<p style="text-align: justify">My recent tour to Angkorwat Temple was a memorable one. I was mesmerized to view Buddhist temple complex speaking of 12th century architecture. After getting a peek at this world famous heritage, I also experienced a breathtaking sunrise at Banteay Srei and saw the Terrace of Leper Kings and Terrace of Elephants...</p>\r\n<p style="text-align: justify"><strong> \r\n', '\r\n</strong></p>\r\n<p> </p>\r\n<p> </p>\r\n<p style="text-align: justify"><strong>Zurker Frankatine</strong></p>\r\n<p style="text-align: justify">My recent tour to Angkorwat Temple was a memorable one. I was mesmerized to view Buddhist temple complex speaking of 12th century architecture. After getting a peek at this world famous heritage, I also experienced a breathtaking sunrise at Banteay Srei and saw the Terrace of Leper Kings and Terrace of Elephants.</p>\r\n<p style="text-align: justify"><strong>Zurker Frankatine </strong></p>\r\n<p style="text-align: justify">My recent tour to Angkorwat Temple was a memorable one. I was mesmerized to view Buddhist temple complex speaking of 12th century architecture. After getting a peek at this world famous heritage, I also experienced a breathtaking sunrise at Banteay Srei and saw the Terrace of Leper Kings and Terrace of Elephants.</p>\r\n<p style="text-align: justify"><strong>Zurker Frankatine</strong></p>\r\n<p><strong> </strong></p>\r\n<p> </p>', 1, 0, 0, 0, '2011-04-02 04:52:44', 62, '', '2011-04-08 06:47:55', 62, 0, '0000-00-00 00:00:00', '2011-04-02 04:52:44', '0000-00-00 00:00:00', '', '', 'show_title=1\nlink_titles=0\nshow_intro=1\nshow_section=0\nlink_section=0\nshow_category=0\nlink_category=0\nshow_vote=0\nshow_author=0\nshow_create_date=0\nshow_modify_date=0\nshow_pdf_icon=0\nshow_print_icon=1\nshow_email_icon=1\nlanguage=en-GB\nkeyref=\nreadmore=', 31, 0, 3, '', '', 0, 19, 'robots=\nauthor='),
(5, 'About Cambodia', 'about-cambodia', '', '<p style="text-align: justify;"><strong>Tour Operator by Cambodia Ministry of Tourism</strong></p>\r\n<p style="text-align: justify;"><br />www.abktours.com is a leading tour operator servicing international and domestic clients in the Indochina region. We can service your travel needs within Cambodia, Vietnam and Laos. Our dynamic and enthusiastic staff are well trained, very experienced and multilingual. We can meet your needs in English, French and Chinese languages and we are always willing to help our clients in all circumstances and urgent cases. We are committed to providing services of the highest standard to our customers to ensure that your experience is satisfying and you enjoy many unforgettable moments when travelling with us.<br /><br />We provide Private Small Group Tour packages to all parts of Cambodia, and specialize in customizing and tailor-making tours for individuals, families and groups to specific requirements at great value for money. Hotels and restaurants are carefully selected to provide comfort and the best local food. Our English speaking guides are knowledgeable and experienced. We take you to the best attractions and sights in comfortable cars with safe drivers.<br /><br />We work hard to give our customers an unforgettable Cambodia experience and many customers have come back to Cambodia with us and kindly referred us to their families and friends. Come and explore the beauty and diversity of Cambodia with us.</p>\r\n<p style="text-align: justify;"><strong>Why travel with us? </strong><br /><br />Our staff have visited many of the places you wish to see. Our services are true value for money. We offer a money back guarantee if our services are not to meet your expectation.<br /><br />As a specialized tourism consultancy, we understand what our customers want. Our consultants can design a customized itinerary to suit your needs and budget. We will advise and design a unique tour schedule upon your expectations. Our friendly and reliable service will add to the enjoyment your travel experience in the Indochina region.<br /><br />CambodiaTripAdvisor places the safety of its customers as “first priority”. Cambodia is regarded as one of the safest destinations in the world to travel and we are always up to date to what is happening in the region.<br /><br />When you come to CambodiaTripAdvisor you will receive an efficient, friendly response from our tour guides. Our guides are very welcoming and experienced and are willing to take a good care of you so that you can enjoy a wonderful holiday. Most of our tour guides are native, so they can show you many interesting things. They will bring you to travel sites to discover local people and historical relics which will challenge and surprise you.<br /><br />Let CambodiaTripAdvisor’s travel consultants arrange an unforgettable journey for you. We are dedicated to exceeding your expectations.<br /><br /><br />This means working directly with you, together, we design your unique travel experiences, provide you with the actual services and offer you at the best prices. You will not go through a broker! When you deal with CambodiaTripAdvisor you cut out all middlemen. Our prices are competitive. Further, we guarantee our price structure is true value for money. If you are not satisfied with CambodiaTripAdvisor you can claim a refund.</p>', '', 1, 0, 0, 0, '2011-04-10 09:36:50', 62, '', '2011-04-24 13:12:40', 62, 0, '0000-00-00 00:00:00', '2011-04-10 09:36:50', '0000-00-00 00:00:00', '', '', 'show_title=0\nlink_titles=0\nshow_intro=0\nshow_section=0\nlink_section=0\nshow_category=0\nlink_category=0\nshow_vote=0\nshow_author=0\nshow_create_date=0\nshow_modify_date=0\nshow_pdf_icon=0\nshow_print_icon=1\nshow_email_icon=1\nlanguage=en-GB\nkeyref=\nreadmore=', 8, 0, 2, '', '', 0, 71, 'robots=\nauthor='),
(6, 'Album Photo Gallery', 'album-photo-gallery', '', '<p>&lt;div style="background:red"&gt;</p>\r\n<p>{gallery}{/gallery} &lt;/div&gt;</p>', '', 1, 0, 0, 0, '2011-04-10 13:11:13', 62, '', '2011-04-19 15:19:14', 62, 62, '2011-04-29 06:49:23', '2011-04-10 13:11:13', '0000-00-00 00:00:00', '', '', 'show_title=0\nlink_titles=0\nshow_intro=0\nshow_section=0\nlink_section=0\nshow_category=0\nlink_category=0\nshow_vote=0\nshow_author=0\nshow_create_date=0\nshow_modify_date=0\nshow_pdf_icon=0\nshow_print_icon=0\nshow_email_icon=0\nlanguage=en-GB\nkeyref=\nreadmore=', 50, 0, 1, '', '', 0, 92, 'robots=\nauthor='),
(7, 'Viedeo Gallery', 'viedeo-gallery', '', '<p>{flv}1{/flv}{flv}1{/flv}</p>', '', -2, 0, 0, 0, '2011-04-11 01:48:49', 62, '', '2011-04-11 03:51:08', 62, 0, '0000-00-00 00:00:00', '2011-04-11 01:48:49', '0000-00-00 00:00:00', '', '', 'show_title=\nlink_titles=\nshow_intro=\nshow_section=\nlink_section=\nshow_category=\nlink_category=\nshow_vote=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nlanguage=\nkeyref=\nreadmore=', 12, 0, 0, '', '', 0, 17, 'robots=\nauthor='),
(8, 'Embassy Abroad', 'embassy-abroad', '', '<div class="box_twothirds mt35 pr60">\r\n<div>\r\n<table border="0" cellspacing="1" cellpadding="15" width="100%">\r\n<tbody>\r\n<tr>\r\n<td align="center">\r\n<p><img src="images/stories/australi.png" border="0" /></p>\r\n<p>AUSTRALIA<br />( Canberra )</p>\r\n</td>\r\n<td align="center">Tel: (612) 6273 1259, 6273 1154<br />Fax: (612) 6273 1053<br />E-mail: cambodianembassy@ozemail.com.au<br />Website: www.embassyofcambodia.org.nz</td>\r\n<td align="center">Royal Embassy of Cambodia<br />No. 5 Canterbury Crescent,<br />Deakin , A.C.T. 2600, AUSTRALIA</td>\r\n</tr>\r\n<tr>\r\n<td align="center">\r\n<p><img src="images/stories/brunei00.png" border="0" /></p>\r\n<p>BRUNEI DARUSSALAM<br />( Bandar Seri Begawan )</p>\r\n</td>\r\n<td align="center">Tel: (673-2) 654 046<br />Fax: (673-2) 650 646<br />E-mail: cambodia@brunet.bn</td>\r\n<td align="center">Royal Embassy of Cambodia<br />8 Simpang 845 KG Tasek Meradum,<br />JLN Tutong, B.S.B,<br />BRUNEI DARUSSALAM</td>\r\n</tr>\r\n<tr>\r\n<td align="center">\r\n<p><img src="images/stories/china000.png" border="0" /></p>\r\n<p>PEOPLE’S REPUBLIC 0F CHINA<br />( Beijing )</p>\r\n</td>\r\n<td align="center">Tel: (861) 06532 1889, 06532 7290<br />Fax: (861) 06532 3507<br />E-mail: cambassybeijing@yahoo.com</td>\r\n<td align="center">Royal Embassy of Cambodia<br />No. 9 Dong Zhi MenWai Dajio 100600 Beijing, P.R.CHINA</td>\r\n</tr>\r\n<tr>\r\n<td align="center">\r\n<p><img src="images/stories/china000.png" border="0" /></p>\r\n<p>PEOPLE’S REPUBLIC OF CHINA<br />( Guangzhou )</p>\r\n</td>\r\n<td align="center">Tel: (8620) 838 79005<br />Fax: (8620) 838 79006<br />E-mail: cambodia@public.guangzhou.gd.cn</td>\r\n<td align="center">Royal Consulate General of Cambodia<br />The Garden Tower, Room 804 – 808Huanshi Rd.<br />E.Guangzhou P.R.. CHINA,P C : 510064</td>\r\n</tr>\r\n<tr>\r\n<td align="center">\r\n<p><img src="images/stories/china000.png" border="0" /></p>\r\n<p>PEOPLE’S REPUBLIC OF CHINA<br />( Hong Kong )</p>\r\n</td>\r\n<td align="center">Tel : (852) 2546 0718, 2362 3656<br />Fax : (852) 2803 0570<br />E-mail : cacghk@netvigator.com</td>\r\n<td align="center">Royal Consulate General of Cambodia<br />Room No. 3606 Sigga CC 144-151, Connaught, Road West, HONG KONG, P.R.CHINA</td>\r\n</tr>\r\n<tr>\r\n<td align="center">\r\n<p><img src="images/stories/china000.png" border="0" /></p>\r\n<p>PEOPLE’S REPUBLIC OF CHINA<br />( Shanghai )</p>\r\n</td>\r\n<td align="center">Tel : ( 8621) 636 1668, 636 00949<br />Fax : (8621) 636 11437<br />E-mail : tangjx@online.sh.cn</td>\r\n<td align="center">Royal Consulate General of Cambodia<br />Huasheng Commercial Building 9th Floor,<br />Hankou Road 400 Shanghai, P.R.CHINA</td>\r\n</tr>\r\n<tr>\r\n<td align="center">\r\n<p><img src="images/stories/cuba0000.png" border="0" /></p>\r\n<p>REPUBLIC OF CUBA<br />( Havana )</p>\r\n</td>\r\n<td align="center">Tel : (537) 241 495, 241 496, 242 333<br />Fax : (537) 246 400<br />E-mail : cambodia@ceniai.if.cu</td>\r\n<td align="center">Royal Embassy of Cambodia<br />No. 7001 Sta AV. ESQ 70 Miramar, Havana, CUBA</td>\r\n</tr>\r\n<tr>\r\n<td align="center">\r\n<p><img src="images/stories/france00.png" border="0" /></p>\r\n<p>REPUBLIC OF FRANCE<br />( Paris )</p>\r\n</td>\r\n<td align="center">Tel : (331) 4503 4720<br />Fax : (331) 4503 4740<br />Email : ambcambodgeparis@mangoosta.fr</td>\r\n<td align="center">Royal Embassy of Cambodia<br />4,rue Adolphe Yvon 75116 Paris, FRANCE</td>\r\n</tr>\r\n<tr>\r\n<td align="center">\r\n<p><img src="images/stories/france00.png" border="0" /></p>\r\n<p>REPUBLIC OF FRANCE<br />( Paris )</p>\r\n</td>\r\n<td align="center">Tel : (331) 4525 1502<br />Fax : (331) 4525 8472<br />E-mai l: DPCAMBODGE@wanadoo.fr</td>\r\n<td align="center">Permanent Delegation of the Kingdom of Cambodia to UNESCO<br />No. 2 Place de Barcelone75016 Paris, FRANCE</td>\r\n</tr>\r\n<tr>\r\n<td align="center">\r\n<p><img src="images/stories/germany0.png" border="0" /></p>\r\n<p>FEDERAL REPUBLIC OF GERMANY<br />( Berlin )</p>\r\n</td>\r\n<td align="center">Tel : (4930) 4863 7901<br />Fax : (4930) 4863 7973<br />E-mail : REC-Berlin@tonline.de</td>\r\n<td align="center">Royal Embassy of Cambodia<br />Benjamin-Vogelsdorf Str. 213187 Berlin, GERMANY</td>\r\n</tr>\r\n<tr>\r\n<td align="center">\r\n<p><img src="images/stories/india000.png" border="0" /></p>\r\n<p>REPUBLIC OF INDIA<br />( New Delhi )</p>\r\n</td>\r\n<td align="center">Tel: (91-11) 649 5091. 649 5092<br />Fax : (91-11) 649 5093<br />E-mail : camboemb@hclinfinet.com</td>\r\n<td align="center">Royal Embassy of Cambodia<br />N-14, Panchsheel Park, New Delhi-110017, INDIA</td>\r\n</tr>\r\n<tr>\r\n<td align="center">\r\n<p><img src="images/stories/indonesi.png" border="0" /></p>\r\n<p>REPUBLIC OF INDONESIA<br />( Jakarta )</p>\r\n</td>\r\n<td align="center">Tel : (62-21) 919 2895<br />Fax : (62-21) 520 2673<br />E-mail : recjkt@indo.net.id</td>\r\n<td align="center">Royal Embassy of Cambodia<br />JL.Kintamani Raya C15 No.33, Kuningan Timur<br />Jakarta Selatan 12950, Republic of Indonesia</td>\r\n</tr>\r\n<tr>\r\n<td align="center">\r\n<p><img src="images/stories/japan000.png" border="0" /></p>\r\n<p>KINGDOM OF JAPAN<br />( Tokyo )</p>\r\n</td>\r\n<td align="center">Tel : ( 813 ) 5412 8521-2-4<br />Fax : ( 813 ) 5412 8526<br />E-mail : aap33850@hkg.odn.ne.jp</td>\r\n<td align="center">Royal Embassy of Cambodia<br />8-6-9,Akasaka, Minato-Ku, Tokyo 1070052, JAPAN</td>\r\n</tr>\r\n<tr>\r\n<td align="center">\r\n<p><img src="images/stories/north korea.png" border="0" /></p>\r\n<p>KOREA (D.P.R)<br />( Pyong Yang )</p>\r\n</td>\r\n<td align="center">Tel : (8502) 381 7283<br />Fax : (8502) 381 7625</td>\r\n<td align="center">Royal Embassy of Cambodia.<br />Rue de L’université Commune Moscou<br />Arrondissement Daedongang<br />R.P.D. DU COREE</td>\r\n</tr>\r\n<tr>\r\n<td align="center">\r\n<p><img src="images/stories/south korea.png" border="0" /></p>\r\n<p>KOREA REPUBLIC<br />( Seoul )</p>\r\n</td>\r\n<td align="center">Tel : (822) 3785 1040<br />Fax : (822) 3785 1041<br />E-mail : camboemb@korea.com</td>\r\n<td align="center">Royal Embassy of Cambodia<br />653-8 Hanan Dong,Yougsan Gu,<br />Seoul , REPUBLIC OF KOREA</td>\r\n</tr>\r\n<tr>\r\n<td align="center">\r\n<p><img src="images/stories/laos0000.png" border="0" /></p>\r\n<p>P.D.R. OF LAO<br />( Vientiane )</p>\r\n</td>\r\n<td align="center">Tel : (8562) 131 4950, 131 4952, 131 5851<br />Fax : (8562) 131 4951<br />E-mail : recamlao@laotel.com</td>\r\n<td align="center">Royal Embassy of Cambodia<br />Thadeua Road, KM2Vientiane,<br />B.P. 34, LaoLAO P.D.R.</td>\r\n</tr>\r\n<tr>\r\n<td align="center">\r\n<p><img src="images/stories/malaysia.png" border="0" /></p>\r\n<p>FEDERATION OF MALAYSIA<br />( Kuala Lumpur )</p>\r\n</td>\r\n<td align="center">Tel : (603) 4257 1150, 4257 3711<br />Fax : (603) 4257 1157<br />E-mail : reckl@tm.net.my</td>\r\n<td align="center">Royal Embassy of Cambodia<br />Nº 46,Jalan U-Than55000 Kuala Lumpur, MALAYSIA</td>\r\n</tr>\r\n<tr>\r\n<td align="center">\r\n<p><img src="images/stories/myanmar0.png" border="0" /></p>\r\n<p>UNION OF MYANMAR<br />( Yangon )</p>\r\n</td>\r\n<td align="center">Tel : (951) 54 96 09, (951) 55 81 57<br />Fax : (951) 55 81 56<br />E-mail : RECYANGON@mptmail.net.mm</td>\r\n<td align="center">Royal Embassy of Cambodia<br />Nº. 25 &lt;3B, 4B&gt;, New University Avenue Road<br />Bahan Township, Yangon, MYANMAR</td>\r\n</tr>\r\n<tr>\r\n<td align="center">\r\n<p><img src="images/stories/philippi.png" border="0" /></p>\r\n<p>REPUBLIC OF THE PHILIPPINES<br />( Manila )</p>\r\n</td>\r\n<td align="center">Tel : (632) 818 9981<br />Fax : (632) 818 9983<br />E-mail : cam.emb.ma@netasia.net</td>\r\n<td align="center">Royal Embassy of Cambodia<br />Unit 7A/7th Floor, Country Space<br />I Bldg., Sen. Gil Puyat, Avenue Salcedo Village,<br />Makata City, MM, PHILIPPINES</td>\r\n</tr>\r\n<tr>\r\n<td align="center">\r\n<p><img src="images/stories/russian0.png" border="0" /></p>\r\n<p>FERATION OF RUSSIA<br />( Moscow )</p>\r\n</td>\r\n<td align="center">Tel : (7095) 201 7668, 201 2115,<br />201 3925, 201 2234<br />Fax : (7095) 956 6573<br />E-mail : cambodia@mail.cnt.ru</td>\r\n<td align="center">Royal Embassy of Cambodia<br />Starokonyushenny Per. 11, Moscow</td>\r\n</tr>\r\n<tr>\r\n<td align="center">\r\n<p><img src="images/stories/singapor.png" border="0" /></p>\r\n<p>REPUBLIC OF SINGAPORE</p>\r\n</td>\r\n<td align="center">Tel : (65) 299 3028<br />Fax : (65) 299 3622<br />E-mail : cambodiaembasy@pacific.net.sg</td>\r\n<td align="center">Royal Embassy of Cambodia<br />152 Beach Road, #11-05 Gateway East Singapore<br />189721, SINGAPORE</td>\r\n</tr>\r\n<tr>\r\n<td align="center">\r\n<p><img src="images/stories/switzerl.png" border="0" /></p>\r\n<p>SWITZERLAND<br />( Geneva )</p>\r\n</td>\r\n<td align="center">Tel : (41 22) 0479 341 776<br />Fax : (41 22)<br />E-mail : ssuos@wanadoo.fr</td>\r\n<td align="center">Permanent Mission of Cambodia<br />to UN and International Organizations<br />Geneva, SWITZERLAND</td>\r\n</tr>\r\n<tr>\r\n<td align="center">\r\n<p><img src="images/stories/thailand.png" border="0" /></p>\r\n<p>KINGDOM OF THAILAND<br />( Bangkok )</p>\r\n</td>\r\n<td align="center">Tel : (662) 254 6630, 253 9851, 253 7967<br />Fax : (662) 253 9859, 253 7961<br />E-mail : recbkk@cscoms.com</td>\r\n<td align="center">Royal Embassy of Cambodia<br />Nº 185 Rajdamri Road, Lumpini Patumwan Bangkok 10330, THAILAND</td>\r\n</tr>\r\n<tr>\r\n<td align="center">\r\n<p><img src="images/stories/thailand.png" border="0" /></p>\r\n<p>KINGDOM OF THAILAND<br />( Sa Kaew )</p>\r\n</td>\r\n<td align="center">Tel : (66 37) 421 734, 421 735<br />Fax : (66 37) 421 736<br />E-mail : consulsk@cscoms.com</td>\r\n<td align="center">Royal Consulate General of Cambodia<br />No. 666, Sovanasone Road Ampheu, Meung Sa Kaew 27000, Sa Kaew Province, THAILAND</td>\r\n</tr>\r\n<tr>\r\n<td align="center">\r\n<p><img src="images/stories/united states of america.png" border="0" /></p>\r\n<p>U.S.A<br />( Washington )</p>\r\n</td>\r\n<td align="center">Tel : (202) 726 7742<br />Fax : (202) 726 8381<br />E-mail : cambodia@embassy.org<br />Website : www.embassy.org/cambodia</td>\r\n<td align="center">Royal Embassy of Cambodia<br />4530 16th Street N.W. Washington , D.C 20011 U.S.A</td>\r\n</tr>\r\n<tr>\r\n<td align="center">\r\n<p><img src="images/stories/united states of america.png" border="0" /></p>\r\n<p>U.S.A<br />( New York )</p>\r\n</td>\r\n<td align="center">Tel : (1212) 223 0676, 369 1369<br />Fax : (1212) 223 0425<br />E-mail : cambodia@un.int<br />Website : www.un.int/cambodia</td>\r\n<td align="center">Permanent Mission of the Kingdom<br />of Cambodia to the United Nations<br />866 U.N.O, Plaza,Suite 420 New York, NY10017, USA</td>\r\n</tr>\r\n<tr>\r\n<td align="center">\r\n<p><img src="images/stories/united states of america.png" border="0" /></p>\r\n<p>U.S.A<br />( Washington State )</p>\r\n</td>\r\n<td align="center">Tel : (206) 217 0830<br />Fax : (206) 361 7888<br />E-mail : consul_huoth@diplomats.com</td>\r\n<td align="center">Royal Honorary Consulate of Cambodia<br />1818 Westlake Avenue N.,<br />Suite #315 Seattle, WA 98109, U.S.A</td>\r\n</tr>\r\n<tr>\r\n<td align="center">\r\n<p><img src="images/stories/viet0000.png" border="0" /></p>\r\n<p>SOCIALIST REPUBLIC OF VIETNAM<br />( Hanoi )</p>\r\n</td>\r\n<td align="center">Tel : (844) 942 4788, 942 4789<br />Mobile : 090 342 2034<br />Fax : (844) 942 3225<br />E-mail : arch@fpt.vn</td>\r\n<td align="center">Royal Embassy of Cambodia<br />71,Tran Hung Dao Str, Hanoi S.R.VIETNAM</td>\r\n</tr>\r\n<tr>\r\n<td align="center">\r\n<p><img src="images/stories/viet0000.png" border="0" /></p>\r\n<p>SOCIALIST REPUBLIC OF VIETNAM<br />( Ho Chi Minh )</p>\r\n</td>\r\n<td align="center">Tel : (848) 829 2751<br />Fax : (848) 829 2744<br />E-mail : cambocg@hcm.vnn.vn</td>\r\n<td align="center">Royal Consulate General of Cambodia<br />No. 41, Phung Khac Khoan,<br />Hochiminh City, S.R.VIETNAM</td>\r\n</tr>\r\n</tbody>\r\n</table>\r\n</div>\r\n</div>', '', 1, 1, 0, 20, '2011-04-11 05:10:49', 62, '', '2011-04-26 11:18:41', 62, 0, '0000-00-00 00:00:00', '2011-04-11 05:10:49', '0000-00-00 00:00:00', '', '', 'show_title=0\nlink_titles=0\nshow_intro=0\nshow_section=0\nlink_section=0\nshow_category=0\nlink_category=0\nshow_vote=0\nshow_author=0\nshow_create_date=0\nshow_modify_date=0\nshow_pdf_icon=0\nshow_print_icon=0\nshow_email_icon=0\nlanguage=en-GB\nkeyref=\nreadmore=Embassy Abroad', 29, 0, 7, '', '', 0, 112, 'robots=\nauthor='),
(9, 'Time and Currency', 'time-and-currency', '', '<p style="line-height: 200%" align="justify"> </p>\r\n', '\r\n<p style="line-height: 200%" align="justify"> </p>\r\n<p style="line-height: 200%" align="justify"><em><strong>Time Local</strong></em><br />Cambodia runs at GMT +7 hours, the same time zone as its neighbors Thailand, Vietnam and Laos.</p>\r\n<p style="line-height: 200%" align="justify"><em><strong>Cambodian Currency</strong></em><br />US dollars are as commonly used as the Cambodian Riel and even Thai Baht is acceptable in many places. Most hotels and many restaurants and shops set their prices in dollars. Small transactions are usually done in Riel. Always carry some small Riel for motorcycle taxis, snacks, beggars and other small purchases.<br />Riel notes come in 50, 100, 200, 500, 1000, 5000, 10,000, 50,000 and 100,000 denominations, but the distinctive red 500 Riel note is the most commonly used.<br />Please click here for the exchange rate with your own currency.<br />Credit cards and travelers checks are not common but are catching on. US dollar travelers checks are much more easily encashed than any other kind.<br />Money changers cluster around the markets. When accepting money, inspect the bills. Marred Riel is acceptable tender, but the tiniest tear in a large US note renders it worthless.<br />There are banks in all of the larger provincial capitals, including Phnom Penh, Siem Reap, Sihanoukville, Battambang. Banks can change money, effect telegraphic transfers and some banks can cash travelers checks and accept Visa cards.<br />There is only two ATM in Cambodia, at the Canadia Bank in Phnom Penh and ANZ Royal Bank in Phnom Penh, and you must have a local account in order to use it. You cannot access foreign accounts from this.</p>', 1, 1, 0, 20, '2011-04-11 05:23:04', 62, '', '2011-04-24 11:46:07', 62, 62, '2011-04-24 12:15:22', '2011-04-11 05:23:04', '0000-00-00 00:00:00', '', '', 'show_title=0\nlink_titles=0\nshow_intro=0\nshow_section=0\nlink_section=0\nshow_category=0\nlink_category=0\nshow_vote=0\nshow_author=0\nshow_create_date=0\nshow_modify_date=0\nshow_pdf_icon=0\nshow_print_icon=1\nshow_email_icon=1\nlanguage=en-GB\nkeyref=\nreadmore=Time and Currency', 7, 0, 6, '', '', 0, 41, 'robots=\nauthor='),
(10, 'Get in and Get out', 'get-in-and-get-out', '', '<p style="line-height: 200%; margin-top: 0; margin-bottom: 0" align="justify"> </p>\r\n', '\r\n<p style="line-height: 200%; margin-top: 0; margin-bottom: 0" align="justify"> </p>\r\n<p style="line-height: 200%; margin-top: 0; margin-bottom: 0" align="justify">Cambodia is served by an increasing number of flights from neighboring countries to both Phnom Penh and Siem Reap, though the best choice is from Bangkok in Thailand. There are now five overland crossings open to foreigners, two from Thailand, and two from Vietnam and one from Laos. Even if you have obtained a Cambodia visa before entry, it is essential to obtain an entry stamp in your passport when crossing overland, as failure to do so will cause serious problems when you come to leave the country.</p>\r\n<p style="line-height: 200%; margin-top: 0; margin-bottom: 0" align="justify"><br /> <em><strong>THAILAND</strong></em><br />From Bangkok, there are regular daily flights to Phnom Penh, taking around an hour, with Thai Airways, Bangkok Airways; the last of these offers slightly cheaper fares than the other two, but can’t be booked from outside the region. Bangkok Airways and Siem Reap Airways also fly daily to Siem Reap, with slightly higher frequency in the high season of December to February. The Cambodia Angkor Airways (National Ariline) will be operating this flight soon.<br /><br />Overland trips to Cambodia from Thailand have increased in popularity and are well publicized in Bangkok, particularity on the Khao San Road, where travel agents try to sell their Bangkok-Siem Reap trips by alleging that doing the trip independently entails various problems (dealing with Cambodian border officials, sorting out onward transport, etc). In fact, it’s straightforward enough to do the journey by public transport, and the convenience of using one of these private firms can be offset by much waiting around until the required number of passenger’s turns up. Though most of these companies are reputable, a small minority of travelers has reported being ripped off over visas, and even being left for hours at the border waiting for onward transport; therefore it’s worth asking fellow travelers of staff at your guesthouse about companies they would recommend or avoid.<br /><br />The Aranyaprethet/Poipet border crossing is ideal if you want to start your visit to Cambodia in the north at Battambang and Siem Reap, while Trat/Koh Kong is good for Sihanoukville and Phnom Penh. From Bangkok, you can reach Aranyaprathet by train (7hr) or by air-con bus (4hr); there are also air-con buses to Trat 95hr). Both borders are open daily (7am-5pm) and visas are issued on arrival. From Poipet, onward transport by shared taxi or pick-up is readily available to Sisophon ( for Siem Reap) and daily boats from Hong Kong to Sre Ambel (for Phnom Penh) and to Sihanoukville. Poipet is in fact derelict, the nearest train station being at Sisophon.</p>\r\n<p style="line-height: 200%; margin-top: 0; margin-bottom: 0" align="justify"><br /> <em><strong>Cambodia-Thailand crossing border:</strong></em></p>\r\n<div>\r\n<ul>\r\n<li>\r\n<p style="line-height: 200%">Cham Yeam International Check Point (Koh Kong Province)</p>\r\n</li>\r\n<li>\r\n<p style="line-height: 200%">Poi Pet International Check Point (Banteay Meanchey Province)</p>\r\n</li>\r\n<li>\r\n<p style="line-height: 200%">Osmach International Check Point (Odor Meanchey Province)</p>\r\n</li>\r\n<li>\r\n<p style="line-height: 200%">Sihanoukville International Check Point (Sihanoukville Province)</p>\r\n</li>\r\n<li>\r\n<p style="line-height: 200%">Choam Sanguam International Check Point (Banteay Meanchey Province)</p>\r\n</li>\r\n<li>\r\n<p style="line-height: 200%">Prum International Check Point (Pailin Province)</p>\r\n</li>\r\n<li>\r\n<p style="line-height: 200%">Doung International Check Point (Battambang Province)</p>\r\n</li>\r\n<li>\r\n<p style="line-height: 200%">Preah Vihear International Check Point (Preah Vihear Province)</p>\r\n</li>\r\n</ul>\r\n<p> </p>\r\n</div>\r\n<p style="line-height: 200%; margin-top: 0; margin-bottom: 0" align="justify"><strong><span style="font-style:italic">VIETNAM</span></strong><br />There are several regular daily flights to Phnom Penh and to Siem Reap from Ho Chi Minh City, operated by Vietnam Airlines and Royal Phnom Penh Airways. Border crossing are open to foreigners at Moc Bai/Bavet, 200km southeast of Phnom Penh, and at Chau Doc on the Bassac River, through note that Cambodian visas are not issued at either crossing point. From Bavet, it’s easy to get shared taxis to Phnom Penh (6hr); though the road has been in appalling condition, the journey time should be reduced when repairs are completed at the beginning of 2003. If you’ve crossed over at Chau Doc, you may be able to get a motor the 60km to Phnom Penh, but given River, it’s easier to take a short motor ride to the Mekong village of K’am Samnar, where you can get a boat north to Neak Leung (3hr), 37km east of Phnom Penh and connected to the capital by bus and shared taxi.<br /><br />Note that only Cambodians and Vietnamese are permitted to cross east of Kep, despite assurances to the contrary from Sihanoukvill’s Vietnamese consulate.</p>\r\n<p style="line-height: 200%; margin-top: 0; margin-bottom: 0" align="justify"><br /> <em><strong>Cambodia-Vietnam crossing border:</strong></em></p>\r\n<div>\r\n<ul>\r\n<li>\r\n<p style="line-height: 200%">Bavet International Check Point (Svay Rieng Province)</p>\r\n</li>\r\n<li>\r\n<p style="line-height: 200%">Kha Orm Sam Nor International Check Point (Kandal Province)</p>\r\n</li>\r\n<li>\r\n<p style="line-height: 200%">Koh Rohka International Check Point (Prey Veng Province)</p>\r\n</li>\r\n<li>\r\n<p style="line-height: 200%">Banteay Chakrey International Check Point (Preyveng Province)</p>\r\n</li>\r\n<li>\r\n<p style="line-height: 200%">Tropeang Sre International Check Point (Kratie Province)</p>\r\n</li>\r\n<li>\r\n<p style="line-height: 200%">Prek Chak International Check Point (Kampot Province)</p>\r\n</li>\r\n<li>\r\n<p style="line-height: 200%">Phnom Den International Check Point (Takeo Province)</p>\r\n</li>\r\n<li>\r\n<p style="line-height: 200%">Oyadav International Check Point (Rattankiri Province)</p>\r\n</li>\r\n<li>\r\n<p style="line-height: 200%">Tropieng Phlong International Check Point (Kampong Cham Province)<br /><br /></p>\r\n</li>\r\n</ul>\r\n</div>\r\n<p style="line-height: 200%; margin-top: 0; margin-bottom: 0" align="justify"><em><strong>LAOS</strong></em><br />Laos Aviation and Vietnam Airlines operate daily flights from Vientiane to Phnom Penh, with stops in Siem Reap on Tuesday and Fridays; sometimes there’s also an unscheduled stop in Pakxe.</p>\r\n<p style="line-height: 200%; margin-top: 0; margin-bottom: 0" align="justify">Adventurous travelers may wish to try the crossing between Voeng Kham by boat or Dong Khon (Parkse) by land, and the Cambodian town of Stung Treng. Visa can be obtained at Dong Krolar border check point – Cambodia side with feee of 20usd. This will take about 6 to 7 hour to reach Phnom Penh city by bus or taxi.</p>\r\n<p style="line-height: 200%; margin-top: 0; margin-bottom: 0" align="justify"><strong><em>Cambodia-Lao crossing border:</em></strong></p>\r\n<div>\r\n<ul>\r\n<li>\r\n<p style="line-height: 200%">Dong Krolar International Check Point (Steung Treng Province)</p>\r\n</li>\r\n<li>\r\n<p style="line-height: 200%">Tropieng Kreal International Check Point (Stung Treng Province)</p>\r\n</li>\r\n</ul>\r\n<p> </p>\r\n</div>', 1, 1, 0, 20, '2011-04-11 05:26:40', 62, '', '2011-04-24 04:25:59', 62, 0, '0000-00-00 00:00:00', '2011-04-11 05:26:40', '0000-00-00 00:00:00', '', '', 'show_title=0\nlink_titles=0\nshow_intro=0\nshow_section=0\nlink_section=0\nshow_category=0\nlink_category=0\nshow_vote=0\nshow_author=0\nshow_create_date=0\nshow_modify_date=0\nshow_pdf_icon=0\nshow_print_icon=1\nshow_email_icon=1\nlanguage=en-GB\nkeyref=\nreadmore=Get in Get out', 7, 0, 5, '', '', 0, 19, 'robots=\nauthor='),
(11, 'Climate and Weather', 'climate-and-weather', '', '<p> </p>\r\n', '\r\n<p> </p>\r\n<p>The climate can generally be described as tropical. As the country is affected by monsoon, it is hot and humid with an overage temperature around 27.C (80.F). There are two distinct seasons: the Rainy Season and the Dry Season. However, the Dry Season is divided into two sub-seasons, cool and hot. These seasons are:</p>\r\n<p style="margin-top: 0; margin-bottom: 0">The Rainy season:</p>\r\n<p style="margin-top: 0; margin-bottom: 0">From June till October 27-35.C (80-95.f)<br /><br />The Dry season (cool):<br />From November till February 17-27.C (80-95.F)<br /><br />The Dry season (Hot) :<br />From March till May 29-38.C (84-100.F)<br /><br />Please click here for Weather in Cambodia</p>\r\n<p> </p>', 1, 1, 0, 20, '2011-04-11 06:17:53', 62, '', '2011-04-24 12:46:35', 62, 0, '0000-00-00 00:00:00', '2011-04-11 06:17:53', '0000-00-00 00:00:00', '', '', 'show_title=0\nlink_titles=0\nshow_intro=0\nshow_section=0\nlink_section=0\nshow_category=0\nlink_category=0\nshow_vote=0\nshow_author=0\nshow_create_date=0\nshow_modify_date=0\nshow_pdf_icon=0\nshow_print_icon=1\nshow_email_icon=1\nlanguage=en-GB\nkeyref=\nreadmore=Climate and Weather', 8, 0, 4, '', '', 0, 40, 'robots=\nauthor='),
(12, 'Health and Advice', 'health-and-advice', '', '<p> </p>\r\n', '\r\n<p style="text-align: justify;"> </p>\r\n<p style="text-align: justify; line-height:150%">Drink lots of water. Never drink tap water purified, bottled water is available everywhere.<br />Use an insect repellent against mosquitoes. It is the only way to be sure of protection against mosquito borne diseases. Since Cambodia has a hot and humid tropical climate, casual and light-weight clothing is best. Clothing made from natural fibers is the best option. A jacket might be needed on cool winter evenings or in hotels and restaurants using excessive air-conditioning. A hat and high-factor sun block is advisable as protection against the hot sun when sightseeing.<br /><br />When visiting temples or pagodas, including those of Angkor Wat, shorts and T-shirts are acceptable. Shoes are generally removed at the entrance to pagodas. For visits to the Silver Pagoda, which is within the Royal Palace grounds, visitors are asked to dress more formally. Gentlemen are required to wear long trousers and ladies should wear long trousers or long skirts.<br /><br />Standard film, (such as Kodak, FUJI or Konica 100, ), slide and digital camera memory are widely available. Photos are inexpensive to process in the country. Any specialized photo equipment should be brought with you. Photography in airports, railway stations and near any military installations is forbidden and discretion should be used when photographing people, particularly monks. The cheapest &amp; best quality photo service in Phnom Penh is SPK Photo Studio FUJI Shop at Monivong Blvd.</p>\r\n<p style="text-align: justify; line-height:150%"><br /><strong>HEALTH REQUIREMENTS</strong><br /><br />Although no vaccinations are officially required for entry to Cambodia, they are highly encouraged. Visitors are advised to check with their doctor or a travel immunization clinic regarding protection against malaria, typhoid, tetanus, hepatitis A and B. Any essential medications should be brought with you as there is no guarantee they will be available in Cambodia.</p>', 1, 1, 0, 20, '2011-04-11 06:20:06', 62, '', '2011-04-24 04:23:02', 62, 0, '0000-00-00 00:00:00', '2011-04-11 06:20:06', '0000-00-00 00:00:00', '', '', 'show_title=0\nlink_titles=0\nshow_intro=0\nshow_section=0\nlink_section=0\nshow_category=0\nlink_category=0\nshow_vote=0\nshow_author=0\nshow_create_date=0\nshow_modify_date=0\nshow_pdf_icon=0\nshow_print_icon=1\nshow_email_icon=1\nlanguage=\nkeyref=\nreadmore=Health and Advice', 7, 0, 3, '', '', 0, 30, 'robots=\nauthor='),
(13, 'Learn Khmer', 'learn-khmer', '', '<!-- BEGIN FUSION TAG CODE -->\r\n<div>\r\n<p> </p>\r\n<p align="justify">The Cambodian language is Khmer, which is inherited itself – and advanced in education with application of Indic languages Pali and Sangkrit from India. Also, the Khmer language is influenced by spoken and written Thai. Some technical languages are borrowed from French. However, English is commonly communicated in hotels and business compounds at present days.</p>\r\n<h3>Learn Khmer:</h3>\r\n<p align="justify">Here are some useful Khmer words and phrases, written phonetically, that will come in handy. Khmer may sound confusing. But with a little patience and practice, you can get by.</p>\r\n<p align="justify">There are 33 consonants and 26 vowels. “Ai” is pronounced as in Thai; “ay” as in pay; “dt” takes the t sound while “bp” takes the p sound. “Oo” is pronounced as in cook and “ao” as in Laos.</p>\r\n<table border="0" cellspacing="1" cellpadding="10" width="100%">\r\n<tbody>\r\n<tr>\r\n<td>\r\n<p style="text-align: left;"><strong>English </strong></p>\r\n<p>Hello</p>\r\n<p>How are you?</p>\r\n<p>Good morning</p>\r\n<p>Good night</p>\r\n<p>Afternoon</p>\r\n<p>My name is…..</p>\r\n<p>Yes</p>\r\n<p>No</p>\r\n<p>Please</p>\r\n<p>Thank You</p>\r\n<p>Excuse me</p>\r\n<p>Goodbye</p>\r\n<p>I don’t understand</p>\r\n<p>I want a…</p>\r\n<p>Water</p>\r\n<p>Tea</p>\r\n<p>Rice (cooked)</p>\r\n<p>Rice (uncooked)</p>\r\n<p>Meat</p>\r\n<p>Fish</p>\r\n<p>Chicken</p>\r\n<p>Bread</p>\r\n<p>Restaurant</p>\r\n<p>Where is the…?</p>\r\n<p>Market</p>\r\n<p>Bank</p>\r\n<p>Post Office</p>\r\n<p>Doctor</p>\r\n<p>Bus</p>\r\n<p>Train</p>\r\n<p>Cycle</p>\r\n<p>Policeman</p>\r\n<p>Turn left</p>\r\n<p>Turn right</p>\r\n<p>Go straight</p>\r\n<p>Morning</p>\r\n<p>Midnight</p>\r\n<p>Night</p>\r\n<p>Sunday</p>\r\n<p>Monday</p>\r\n<p>Tuesday</p>\r\n<p>Wednesday</p>\r\n<p>Thursday</p>\r\n<p>Friday</p>\r\n<p>Saturday</p>\r\n</td>\r\n<td>\r\n<p style="text-align: left;"><strong>Khmer </strong></p>\r\n<p>jum-reap soo-a</p>\r\n<p>tau neak sok sapbaiy teh?</p>\r\n<p>arun sour sdei</p>\r\n<p>tiveah sour sdei</p>\r\n<p>reah-trey sour sdei</p>\r\n<p>k’nyom tchmouh…</p>\r\n<p>baat</p>\r\n<p>dteh</p>\r\n<p>suom mehta</p>\r\n<p>or-koon</p>\r\n<p>sohm dtoh</p>\r\n<p>joom-reap leah</p>\r\n<p>k’nyom men yoo-ul tee</p>\r\n<p>k’nyom jang baan…</p>\r\n<p>teuk</p>\r\n<p>tai</p>\r\n<p>bia</p>\r\n<p>angkoh</p>\r\n<p>saich</p>\r\n<p>t’ray</p>\r\n<p>moan</p>\r\n<p>num pung</p>\r\n<p>haang bai</p>\r\n<p>noev eah nah…?</p>\r\n<p>p’sah</p>\r\n<p>tho neea kear</p>\r\n<p>bprai sa nee</p>\r\n<p>peth</p>\r\n<p>laan ch’noul</p>\r\n<p>ra dteah plerng</p>\r\n<p>see kloa</p>\r\n<p>bpoa leeh or norkor-bahl</p>\r\n<p>bot dtoy ch’wayng</p>\r\n<p>bot dtoy s’dum</p>\r\n<p>dtov dtrong</p>\r\n<p>bpreuk</p>\r\n<p>aa-tree-at</p>\r\n<p>yoop</p>\r\n<p>t/ngai aa-dteut</p>\r\n<p>t’ngai jan</p>\r\n<p>t’ngai ong-gee-a</p>\r\n<p>t’ngai bpoot</p>\r\n<p>t’ngai bpra-hoa-a</p>\r\n<p>t’ngai sok</p>\r\n<p>t’ngai sao</p>\r\n</td>\r\n<td>\r\n<p style="margin-top: 0px; margin-bottom: 0px; text-align: left;"><strong>English</strong></p>\r\n<p style="margin-top: 0; margin-bottom: 0" align="center"> </p>\r\n<p style="margin-top: 0; margin-bottom: 0">Yesterday</p>\r\n<p>Today</p>\r\n<p>Tomorrow</p>\r\n<p>Month</p>\r\n<p>Year</p>\r\n<p>Last Year</p>\r\n<p>New Year</p>\r\n<p>Next Year</p>\r\n<p>January</p>\r\n<p>February</p>\r\n<p>March</p>\r\n<p>April</p>\r\n<p>May</p>\r\n<p>June</p>\r\n<p>July</p>\r\n<p>August</p>\r\n<p>September</p>\r\n<p>October</p>\r\n<p>November</p>\r\n<p>December</p>\r\n<p>One</p>\r\n<p>Two</p>\r\n<p>Three</p>\r\n<p>Four</p>\r\n<p>Five</p>\r\n<p>Six</p>\r\n<p>Seven</p>\r\n<p>Eight</p>\r\n<p>Night</p>\r\n<p>Ten</p>\r\n<p>Eleven</p>\r\n<p>Twenty</p>\r\n<p>Thirty</p>\r\n<p>Forty</p>\r\n<p>Fifty</p>\r\n<p>Sixty</p>\r\n<p>Seventy</p>\r\n<p>Eighty</p>\r\n<p>Ninety</p>\r\n<p>Hundred</p>\r\n<p>Thousand</p>\r\n<p>Ten thousand</p>\r\n<p>Hundred thousand</p>\r\n<p>Million</p>\r\n<p> </p>\r\n</td>\r\n<td>\r\n<p style="text-align: left;"><strong>Khmer </strong></p>\r\n<p>m’serl menh</p>\r\n<p>t’ngai nih</p>\r\n<p>t’ngai sa-aik</p>\r\n<p>khaeh</p>\r\n<p>ch’nam</p>\r\n<p>ch’nam moon</p>\r\n<p>ch’nam thmey</p>\r\n<p>ch’nam groy</p>\r\n<p>ma ga raa</p>\r\n<p>kompheak</p>\r\n<p>mee nah</p>\r\n<p>meh sah</p>\r\n<p>oo sa phea</p>\r\n<p>mi thok nah</p>\r\n<p>ka kada</p>\r\n<p>say haa</p>\r\n<p>kan’ya</p>\r\n<p>to laa</p>\r\n<p>wech a gaa</p>\r\n<p>t’noo</p>\r\n<p>moo ay</p>\r\n<p>bpee</p>\r\n<p>bay</p>\r\n<p>boun</p>\r\n<p>bpram</p>\r\n<p>bpram moo ay</p>\r\n<p>bpram bpee</p>\r\n<p>bpram bay</p>\r\n<p>bpram buon</p>\r\n<p>dahp</p>\r\n<p>dahp moo ay</p>\r\n<p>m’pay</p>\r\n<p>saam seup</p>\r\n<p>sai seup</p>\r\n<p>ha seup</p>\r\n<p>hok seup</p>\r\n<p>jeht seup</p>\r\n<p>bpait seup</p>\r\n<p>gao seup</p>\r\n<p>moo-ay roy</p>\r\n<p>moo-aybpoan</p>\r\n<p>moo-ay meun</p>\r\n<p>moo-ay sain</p>\r\n<p>moo-ay lee-un</p>\r\n<p> </p>\r\n</td>\r\n</tr>\r\n</tbody>\r\n</table>\r\n</div>\r\n<!-- end div#wrapper --><!-- This document saved from http://www.cambodiatripadvisor.com/cambodia-travel-guide/learn-khmer -->', '', 1, 1, 0, 20, '2011-04-11 06:26:24', 62, '', '2011-04-24 04:22:16', 62, 0, '0000-00-00 00:00:00', '2011-04-11 06:26:24', '0000-00-00 00:00:00', '', '', 'show_title=1\nlink_titles=0\nshow_intro=0\nshow_section=0\nlink_section=0\nshow_category=0\nlink_category=0\nshow_vote=0\nshow_author=0\nshow_create_date=0\nshow_modify_date=0\nshow_pdf_icon=0\nshow_print_icon=1\nshow_email_icon=1\nlanguage=\nkeyref=\nreadmore=Learn Khmer', 8, 0, 2, '', '', 0, 76, 'robots=\nauthor=');
INSERT INTO `jos_content` (`id`, `title`, `alias`, `title_alias`, `introtext`, `fulltext`, `state`, `sectionid`, `mask`, `catid`, `created`, `created_by`, `created_by_alias`, `modified`, `modified_by`, `checked_out`, `checked_out_time`, `publish_up`, `publish_down`, `images`, `urls`, `attribs`, `version`, `parentid`, `ordering`, `metakey`, `metadesc`, `access`, `hits`, `metadata`) VALUES
(14, 'Visa and Passport', 'visa-and-passport', '', '<p style="line-height: 150%"><strong>Airport Tax (Passenger Service Charges)</strong><br /> <em><strong>For International Travel</strong></em><br /><em>Foreigner:<br /></em>Adult US$25<br />Under 12 years old US$13<br />Under 2 years old FREE<br /> <br /><em>Cambodian:</em><br />Adult US$18<br />Under 12 years old US$10<br />Under 2 years old FREE<br /> <br /><em><strong>For Domestic Travel</strong></em><br /><em>Foreigner:</em><br />Adult US$6<br /><br /> <em>Cambodian:</em><br />Adult US$5<br />The entry points to obtain Visa<br /> <br /><em><strong>Airports:</strong></em><br />Phnom Penh International Airport<br />Siem Reap International Airport<br /> <br /><em><strong>Cambodia-Vietnam border:</strong></em></p>\r\n<div>\r\n<ul>\r\n<li>\r\n<p style="line-height: 200%">Bavet International Check Point (Svay Rieng Province)</p>\r\n</li>\r\n<li>\r\n<p style="line-height: 200%">Kha Orm Sam Nor International Check Point (Kandal Province)</p>\r\n</li>\r\n<li>\r\n<p style="line-height: 200%">Koh Rohka International Check Point (Prey Veng Province)</p>\r\n</li>\r\n<li>\r\n<p style="line-height: 200%">Banteay Chakrey International Check Point (Preyveng Province)</p>\r\n</li>\r\n<li>\r\n<p style="line-height: 200%">Tropeang Sre International Check Point (Kratie Province)</p>\r\n</li>\r\n<li>\r\n<p style="line-height: 200%">Prek Chak International Check Point (Kampot Province)</p>\r\n</li>\r\n<li>\r\n<p style="line-height: 200%">Phnom Den International Check Point (Takeo Province)</p>\r\n</li>\r\n<li>\r\n<p style="line-height: 200%">Oyadav International Check Point (Rattankiri Province)</p>\r\n</li>\r\n<li>\r\n<p style="line-height: 200%">Tropieng Phlong International Check Point (Kampong Cham Province)</p>\r\n</li>\r\n</ul>\r\n</div>\r\n<div><strong><em>Cambodia-Thailand border:</em></strong>\r\n<div>\r\n<ul>\r\n<li>\r\n<p style="line-height: 200%">Cham Yeam International Check Point (Koh Kong Province)</p>\r\n</li>\r\n<li>\r\n<p style="line-height: 200%">Poi Pet International Check Point (Banteay Meanchey Province)</p>\r\n</li>\r\n<li>\r\n<p style="line-height: 200%">Osmach International Check Point (Odor Meanchey Province)</p>\r\n</li>\r\n<li>\r\n<p style="line-height: 200%">Sihanoukville International Check Point (Sihanoukville Province)</p>\r\n</li>\r\n<li>\r\n<p style="line-height: 200%">Choam Sanguam International Check Point (Banteay Meanchey Province)</p>\r\n</li>\r\n<li>\r\n<p style="line-height: 200%">Prum International Check Point (Pailin Province)</p>\r\n</li>\r\n<li>\r\n<p style="line-height: 200%">Doung International Check Point (Battambang Province)</p>\r\n</li>\r\n<li>\r\n<p style="line-height: 200%">Preah Vihear International Check Point (Preah Vihear Province)</p>\r\n</li>\r\n</ul>\r\n</div>\r\n<strong><em>Cambodia-Lao border:</em></strong> \r\n<ul>\r\n<li>\r\n<p style="line-height: 200%">Dong Krolar International Check Point (Steung Treng Province)</p>\r\n</li>\r\n<li>\r\n<p style="line-height: 200%">Tropieng Kreal International Check Point (Stung Treng Province)</p>\r\n</li>\r\n</ul>\r\n<p style="line-height: 200%"><em><strong>Application for Visas and Fee</strong></em><br />It is required for the visa applicants to submit passport, application forms, a recent passport-style color photograph, and such other documents as determined by the status of stay.</p>\r\n<div>\r\n<ul>\r\n<li>\r\n<p style="line-height: 200%">Sin<span style="font-family: ">gle entry visa fee for tourist: US$ 20</span></p>\r\n</li>\r\n<li>\r\n<p style="line-height: 200%"><span style="font-family: ">Single entry visa fee for business: US$ 25</span></p>\r\n</li>\r\n</ul>\r\n</div>\r\n<p style="line-height: 150%"><br /><strong>Visa Type</strong><br /><strong><em>Tourist &amp; Business Visas:</em></strong><br />Visitors from countries not under Visa Exemption Agreements must apply for a Tourists or business visa valid for one month at the points of entry.<br />Siem Reap International Airport<br /> <br /><strong><em>Visa K:</em></strong><br />Visa K can be issued to a Cambodian national entering the Kingdom on a foreign passport. (The applicant has to provide well-documented evidence, such as proof that one’s parents were Cambodian).<br /> <br /><em><strong>Visa Exemption:</strong></em><br />The nationals of the Philippines and Malaysia do not need a tourist visa and may stay in Cambodia for 21 and 30 days respectively.<br /> <br /><strong>Visa extension</strong><br /><em><strong>Tourist &amp; Business Visas:</strong></em><br />The tourist (T) and business (E) visas can be extended at the Immigration Department, National Police. The Diplomatic (A), Official (B) and Courtesy (C) visas can be extended at the Consular Department, Ministry of Foreign Affairs. A tourist visa can be extended only once for up to one month (single entry)<br /> <br /><em><strong>A business visa can be extended for:</strong></em></p>\r\n<div>\r\n<ul>\r\n<li>\r\n<p style="line-height: 200%">One month (Single entry)</p>\r\n</li>\r\n<li>\r\n<p style="line-height: 200%">Three months (Multiple entry)</p>\r\n</li>\r\n<li>\r\n<p style="line-height: 200%">Six months (Multiple entry)</p>\r\n</li>\r\n<li>\r\n<p style="line-height: 200%">One year (Multiple entry)</p>\r\n</li>\r\n<li>\r\n<p style="line-height: 200%">Overstayers will be fined US$ 5 per day.</p>\r\n</li>\r\n</ul>\r\n<p> </p>\r\n</div>\r\n<p style="line-height: 150%"> </p>\r\n<p style="line-height: 150%"> </p>\r\n<p style="line-height: 150%"> </p>\r\n</div>', '', 1, 1, 0, 20, '2011-04-11 06:29:29', 62, '', '2011-04-24 04:21:47', 62, 0, '0000-00-00 00:00:00', '2011-04-11 06:29:29', '0000-00-00 00:00:00', '', '', 'show_title=0\nlink_titles=0\nshow_intro=0\nshow_section=0\nlink_section=0\nshow_category=0\nlink_category=0\nshow_vote=0\nshow_author=0\nshow_create_date=0\nshow_modify_date=0\nshow_pdf_icon=0\nshow_print_icon=1\nshow_email_icon=1\nlanguage=en-GB\nkeyref=\nreadmore=Visa and Passport', 14, 0, 1, '', '', 0, 79, 'robots=\nauthor='),
(15, 'Ankor Tours', 'abk-0004', '', '<p align="justify"><strong>Day 01  :   Welcome to Viet Nam - Arrive in Ha Noi    (D)</strong></p>\r\n<p align="justify"><br /><img src="images/stories/1692357.jpg" border="0" width="120" height="90" style="border: 1px solid black; float: left; margin: 3px;" />Greeting  at the airport and transfer to hotel for check-in and tour-briefing. In  the afternoon, an orientation tour of Ha Noi, and a chance to acclimate  yourself. You’ll have time to enjoy a walking tour of Ha Noi’s famous  “Old Quarter,” noted for its 36 guild streets. The evening is  highlighted by a performance of the famed Water Puppet Theatre of Hanoi,  a traditional art form created by village farmers around the Red River  Delta region. Unique but recognized internationally. Overnight in Hanoi.</p>\r\n<p align="justify"> </p>\r\n<p align="justify"><strong>Day 02:   Hanoi City Tour (B/L/D)</strong></p>\r\n<p align="justify"><br /><img src="images/stories/55350730__f2p0750.jpg" border="0" width="120" height="90" style="float: left; border: 1px solid black; margin: 3px;" />Morning  sightseeing of the city’s most outstanding historical and cultural  sites, to include The Ho Chi Minh Mausoleum, the Presidential Palace,  President Ho’s House on Stilts, and Ba Dinh Square, often referred to as  the political heart of Viet Nam. The day’s touring continues to the One  Pillar Pagoda and the Temple of Literature, in order to gain an  understanding of two guiding forces in Viet Nam culture, Buddhism and  Confucianism. Visits to other fine museums are optional. Recommended are  the Museum of History, the National Museum of Ethnology, and the Museum  of Fine Art.</p>', '', 1, 2, 0, 24, '2011-04-28 10:58:54', 62, '', '2011-04-29 15:31:16', 62, 0, '0000-00-00 00:00:00', '2011-04-28 10:58:54', '0000-00-00 00:00:00', '', '', 'show_title=0\nlink_titles=1\nshow_intro=0\nshow_section=0\nlink_section=0\nshow_category=1\nlink_category=0\nshow_vote=0\nshow_author=0\nshow_create_date=0\nshow_modify_date=0\nshow_pdf_icon=1\nshow_print_icon=1\nshow_email_icon=1\nlanguage=en-GB\nkeyref=\nreadmore=', 6, 0, 4, '', '', 0, 6, 'robots=\nauthor='),
(16, 'Bayon Tour', 'abk-0003', '', '<p align="justify"> </p>\r\n<p align="justify"><strong>Day 03:    Ha Long Bay Full Day Excursion (B/L/D)</strong><br /><img src="images/stories/62997628_ww8ndkv3__f2p4226.jpg" border="0" width="220" height="190" style="border: 1px solid black; float: left; margin: 3px;" />We  arrive early in Hanoi and have enough time to visit the remarkable  Flower Market at Quang Ba District before breakfast. After driving to Ha  Long Bay, then a 4-hour boat cruise among the more than 3,000 islands  that comprise Ha Long. Famous as a recognized world wonder and protected  World Heritage Site, the bay includes strange rock formations, caves,  and numerous islands jutting out of the surrounding emerald waters.  We’ll visit Thien Cung Cave and indulge in an on-board seafood lunch.  Overnight in Hanoi.</p>\r\n<p> </p>\r\n<p> </p>\r\n<p> </p>\r\n<p align="justify"> </p>\r\n<p align="justify"><strong>Day 04:   Hanoi – Saigon (B/L/D)</strong><strong> </strong><br /><img src="images/stories/62997622_nqty5qhb.jpg" border="0" width="220" height="180" style="border: 1px solid black; float: left; margin: 3px;" />Greeting  at the airport and transfer to hotel for check-in and tour briefing.  Depending upon arrival time, enjoy an over-view sightseeing tour around  Saigon City Center, to include the former Presidential Palace, Notre  Dame Cathedral, the elegant French-designed Old Post Office, and the  bustling commercial center of Nguyen Hue Street and the Saigon River  Waterfront. Experience Saigon’s French Colonial past directly near your  hotel and on Dong Khoi Street. Overnight in Saigon.</p>\r\n<p align="justify"> </p>\r\n<p> </p>\r\n<p> </p>\r\n<p> </p>\r\n<p><strong>Day 04:   Hanoi – Saigon (B/L/D)</strong><br /><img src="images/stories/62997622_nqty5qhb.jpg" border="0" width="220" height="180" style="border: 1px solid black; float: left; margin: 3px;" />Greeting   at the airport and transfer to hotel for check-in and tour briefing.   Depending upon arrival time, enjoy an over-view sightseeing tour around   Saigon City Center, to include the former Presidential Palace, Notre   Dame Cathedral, the elegant French-designed Old Post Office, and the   bustling commercial center of Nguyen Hue Street and the Saigon River   Waterfront. Experien</p>\r\n<p> </p>\r\n<p> </p>\r\n<p> </p>\r\n<p> </p>\r\n<p><strong>Day 04:   Hanoi – Saigon (B/L/D)</strong><strong> </strong><br /><img src="images/stories/62997622_nqty5qhb.jpg" border="0" width="220" height="180" style="border: 1px solid black; float: left; margin: 3px;" />Greeting   at the airport and transfer to hotel for check-in and tour briefing.   Depending upon arrival time, enjoy an over-view sightseeing tour around   Saigon City Center, to include the former Presidential Palace, Notre   Dame Cathedral, the elegant French-designed Old Post Office, and the   bustling commercial center of Nguyen Hue Street and the Saigon River   Waterfront. Experien</p>', '', 1, 2, 0, 24, '2011-04-28 11:18:11', 62, '', '2011-04-29 15:30:57', 62, 0, '0000-00-00 00:00:00', '2011-04-28 11:18:11', '0000-00-00 00:00:00', '', '', 'show_title=1\nlink_titles=1\nshow_intro=0\nshow_section=0\nlink_section=0\nshow_category=0\nlink_category=0\nshow_vote=0\nshow_author=0\nshow_create_date=0\nshow_modify_date=0\nshow_pdf_icon=1\nshow_print_icon=1\nshow_email_icon=1\nlanguage=\nkeyref=\nreadmore=', 10, 0, 3, '', '', 0, 19, 'robots=\nauthor='),
(18, 'Bong-Bong 7day/day', 'abk-0002', '', '<p align="justify"><strong>Day 03:    Ha Long Bay Full Day Excursion (B/L/D)</strong><br /><img src="images/stories/62997628_ww8ndkv3__f2p4226.jpg" border="0" width="222" height="160" style="border: 1px solid black; float: left; margin: 3px;" />We    arrive early in Hanoi and have enough time to visit the remarkable    Flower Market at Quang Ba District before breakfast. After driving to Ha    Long Bay, then a 4-hour boat cruise among the more than 3,000 islands    that comprise Ha Long. Famous as a recognized world wonder and   protected  World Heritage Site, the bay includes strange rock   formations, caves,  and numerous islands jutting out of the surrounding   emerald waters.  We’ll visit Thien Cung Cave and indulge in an on-board   seafood lunch.  Overnight in Hanoi.</p>\r\n<p align="justify"> </p>\r\n<p align="justify"> </p>\r\n<p align="justify"> </p>\r\n<p align="justify"><strong>Day 03:    Ha Long Bay Full Day Excursion (B/L/D)</strong><br /><img src="images/stories/62997628_ww8ndkv3__f2p4226.jpg" border="0" width="222" height="154" style="border: 1px solid black; float: left; margin: 3px;" />We    arrive early in Hanoi and have enough time to visit the remarkable    Flower Market at Quang Ba District before breakfast. After driving to Ha    Long Bay, then a 4-hour boat cruise among the more than 3,000 islands    that comprise Ha Long. Famous as a recognized world wonder and   protected  World Heritage Site, the bay includes strange rock   formations, caves,  and numerous islands jutting out of the surrounding   emerald waters.  We’ll visit Thien Cung Cave and indulge in an on-board   seafood lunch.  Overnight in Hanoi.</p>\r\n<p align="justify"> </p>\r\n<p align="justify"> </p>\r\n<p align="justify"> </p>', '', 1, 2, 0, 24, '2011-04-28 12:52:14', 62, '', '2011-04-29 15:30:37', 62, 0, '0000-00-00 00:00:00', '2011-04-28 12:52:14', '0000-00-00 00:00:00', '', '', 'show_title=\nlink_titles=\nshow_intro=\nshow_section=\nlink_section=\nshow_category=\nlink_category=\nshow_vote=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nlanguage=\nkeyref=\nreadmore=', 4, 0, 1, '', '', 0, 17, 'robots=\nauthor='),
(17, 'Banteay strey tours', 'abk-0001', '', '<p align="justify"><strong>Day 03:    Ha Long Bay Full Day Excursion (B/L/D)</strong><br /><img src="images/stories/62997628_ww8ndkv3__f2p4226.jpg" border="0" width="222" height="160" style="border: 1px solid black; float: left; margin: 3px;" />We   arrive early in Hanoi and have enough time to visit the remarkable   Flower Market at Quang Ba District before breakfast. After driving to Ha   Long Bay, then a 4-hour boat cruise among the more than 3,000 islands   that comprise Ha Long. Famous as a recognized world wonder and  protected  World Heritage Site, the bay includes strange rock  formations, caves,  and numerous islands jutting out of the surrounding  emerald waters.  We’ll visit Thien Cung Cave and indulge in an on-board  seafood lunch.  Overnight in Hanoi.</p>\r\n<p align="justify"> </p>\r\n<p align="justify"> </p>\r\n<p align="justify"> </p>\r\n<p align="justify"><strong>Day 03:    Ha Long Bay Full Day Excursion (B/L/D)</strong><br /><img src="images/stories/62997628_ww8ndkv3__f2p4226.jpg" border="0" width="222" height="154" style="border: 1px solid black; float: left; margin: 3px;" />We   arrive early in Hanoi and have enough time to visit the remarkable   Flower Market at Quang Ba District before breakfast. After driving to Ha   Long Bay, then a 4-hour boat cruise among the more than 3,000 islands   that comprise Ha Long. Famous as a recognized world wonder and  protected  World Heritage Site, the bay includes strange rock  formations, caves,  and numerous islands jutting out of the surrounding  emerald waters.  We’ll visit Thien Cung Cave and indulge in an on-board  seafood lunch.  Overnight in Hanoi.</p>\r\n<p align="justify"> </p>\r\n<p align="justify"> </p>\r\n<p align="justify"> </p>\r\n<p align="justify"><strong>Day 03:    Ha Long Bay Full Day Excursion (B/L/D)</strong><br /><img src="images/stories/62997628_ww8ndkv3__f2p4226.jpg" border="0" width="222" height="154" style="border: 1px solid black; float: left; margin: 3px;" />We   arrive early in Hanoi and have enough time to visit the remarkable   Flower Market at Quang Ba District before breakfast. After driving to Ha   Long Bay, then a 4-hour boat cruise among the more than 3,000 islands   that comprise Ha Long. Famous as a recognized world wonder and  protected  World Heritage Site, the bay includes strange rock  formations, caves,  and numerous islands jutting out of the surrounding  emerald waters.  We’ll visit Thien Cung Cave and indulge in an on-board  seafood lunch.  Overnight in Hanoi.</p>\r\n<p align="justify"> </p>\r\n<p align="justify"> </p>\r\n<p align="justify"> </p>\r\n<p align="justify"> </p>\r\n<p align="justify"> </p>\r\n<p align="justify"> </p>', '', 1, 2, 0, 24, '2011-04-28 11:36:08', 62, '', '2011-04-29 15:29:59', 62, 0, '0000-00-00 00:00:00', '2011-04-28 11:36:08', '0000-00-00 00:00:00', '', '', 'show_title=1\nlink_titles=1\nshow_intro=\nshow_section=0\nlink_section=0\nshow_category=0\nlink_category=0\nshow_vote=0\nshow_author=0\nshow_create_date=0\nshow_modify_date=0\nshow_pdf_icon=1\nshow_print_icon=1\nshow_email_icon=1\nlanguage=en-GB\nkeyref=\nreadmore=', 4, 0, 2, '', '', 0, 25, 'robots=\nauthor=');

-- --------------------------------------------------------

--
-- Table structure for table `jos_content_frontpage`
--

CREATE TABLE IF NOT EXISTS `jos_content_frontpage` (
  `content_id` int(11) NOT NULL default '0',
  `ordering` int(11) NOT NULL default '0',
  PRIMARY KEY  (`content_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `jos_content_frontpage`
--

INSERT INTO `jos_content_frontpage` (`content_id`, `ordering`) VALUES
(1, 4),
(2, 3),
(3, 2),
(4, 1);

-- --------------------------------------------------------

--
-- Table structure for table `jos_content_rating`
--

CREATE TABLE IF NOT EXISTS `jos_content_rating` (
  `content_id` int(11) NOT NULL default '0',
  `rating_sum` int(11) unsigned NOT NULL default '0',
  `rating_count` int(11) unsigned NOT NULL default '0',
  `lastip` varchar(50) NOT NULL default '',
  PRIMARY KEY  (`content_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `jos_content_rating`
--


-- --------------------------------------------------------

--
-- Table structure for table `jos_core_acl_aro`
--

CREATE TABLE IF NOT EXISTS `jos_core_acl_aro` (
  `id` int(11) NOT NULL auto_increment,
  `section_value` varchar(240) NOT NULL default '0',
  `value` varchar(240) NOT NULL default '',
  `order_value` int(11) NOT NULL default '0',
  `name` varchar(255) NOT NULL default '',
  `hidden` int(11) NOT NULL default '0',
  PRIMARY KEY  (`id`),
  UNIQUE KEY `jos_section_value_value_aro` (`section_value`(100),`value`(100)),
  KEY `jos_gacl_hidden_aro` (`hidden`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=12 ;

--
-- Dumping data for table `jos_core_acl_aro`
--

INSERT INTO `jos_core_acl_aro` (`id`, `section_value`, `value`, `order_value`, `name`, `hidden`) VALUES
(10, 'users', '62', 0, 'Administrator', 0),
(11, 'users', '63', 0, 'reach ponlue', 0);

-- --------------------------------------------------------

--
-- Table structure for table `jos_core_acl_aro_groups`
--

CREATE TABLE IF NOT EXISTS `jos_core_acl_aro_groups` (
  `id` int(11) NOT NULL auto_increment,
  `parent_id` int(11) NOT NULL default '0',
  `name` varchar(255) NOT NULL default '',
  `lft` int(11) NOT NULL default '0',
  `rgt` int(11) NOT NULL default '0',
  `value` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`id`),
  KEY `jos_gacl_parent_id_aro_groups` (`parent_id`),
  KEY `jos_gacl_lft_rgt_aro_groups` (`lft`,`rgt`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=31 ;

--
-- Dumping data for table `jos_core_acl_aro_groups`
--

INSERT INTO `jos_core_acl_aro_groups` (`id`, `parent_id`, `name`, `lft`, `rgt`, `value`) VALUES
(17, 0, 'ROOT', 1, 22, 'ROOT'),
(28, 17, 'USERS', 2, 21, 'USERS'),
(29, 28, 'Public Frontend', 3, 12, 'Public Frontend'),
(18, 29, 'Registered', 4, 11, 'Registered'),
(19, 18, 'Author', 5, 10, 'Author'),
(20, 19, 'Editor', 6, 9, 'Editor'),
(21, 20, 'Publisher', 7, 8, 'Publisher'),
(30, 28, 'Public Backend', 13, 20, 'Public Backend'),
(23, 30, 'Manager', 14, 19, 'Manager'),
(24, 23, 'Administrator', 15, 18, 'Administrator'),
(25, 24, 'Super Administrator', 16, 17, 'Super Administrator');

-- --------------------------------------------------------

--
-- Table structure for table `jos_core_acl_aro_map`
--

CREATE TABLE IF NOT EXISTS `jos_core_acl_aro_map` (
  `acl_id` int(11) NOT NULL default '0',
  `section_value` varchar(230) NOT NULL default '0',
  `value` varchar(100) NOT NULL,
  PRIMARY KEY  (`acl_id`,`section_value`,`value`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `jos_core_acl_aro_map`
--


-- --------------------------------------------------------

--
-- Table structure for table `jos_core_acl_aro_sections`
--

CREATE TABLE IF NOT EXISTS `jos_core_acl_aro_sections` (
  `id` int(11) NOT NULL auto_increment,
  `value` varchar(230) NOT NULL default '',
  `order_value` int(11) NOT NULL default '0',
  `name` varchar(230) NOT NULL default '',
  `hidden` int(11) NOT NULL default '0',
  PRIMARY KEY  (`id`),
  UNIQUE KEY `jos_gacl_value_aro_sections` (`value`),
  KEY `jos_gacl_hidden_aro_sections` (`hidden`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=11 ;

--
-- Dumping data for table `jos_core_acl_aro_sections`
--

INSERT INTO `jos_core_acl_aro_sections` (`id`, `value`, `order_value`, `name`, `hidden`) VALUES
(10, 'users', 1, 'Users', 0);

-- --------------------------------------------------------

--
-- Table structure for table `jos_core_acl_groups_aro_map`
--

CREATE TABLE IF NOT EXISTS `jos_core_acl_groups_aro_map` (
  `group_id` int(11) NOT NULL default '0',
  `section_value` varchar(240) NOT NULL default '',
  `aro_id` int(11) NOT NULL default '0',
  UNIQUE KEY `group_id_aro_id_groups_aro_map` (`group_id`,`section_value`,`aro_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `jos_core_acl_groups_aro_map`
--

INSERT INTO `jos_core_acl_groups_aro_map` (`group_id`, `section_value`, `aro_id`) VALUES
(25, '', 10),
(25, '', 11);

-- --------------------------------------------------------

--
-- Table structure for table `jos_core_log_items`
--

CREATE TABLE IF NOT EXISTS `jos_core_log_items` (
  `time_stamp` date NOT NULL default '0000-00-00',
  `item_table` varchar(50) NOT NULL default '',
  `item_id` int(11) unsigned NOT NULL default '0',
  `hits` int(11) unsigned NOT NULL default '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `jos_core_log_items`
--


-- --------------------------------------------------------

--
-- Table structure for table `jos_core_log_searches`
--

CREATE TABLE IF NOT EXISTS `jos_core_log_searches` (
  `search_term` varchar(128) NOT NULL default '',
  `hits` int(11) unsigned NOT NULL default '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `jos_core_log_searches`
--


-- --------------------------------------------------------

--
-- Table structure for table `jos_dbcache`
--

CREATE TABLE IF NOT EXISTS `jos_dbcache` (
  `id` varchar(32) NOT NULL default '',
  `groupname` varchar(32) NOT NULL default '',
  `expire` datetime NOT NULL default '0000-00-00 00:00:00',
  `value` mediumblob NOT NULL,
  PRIMARY KEY  (`id`,`groupname`),
  KEY `expire` (`expire`,`groupname`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `jos_dbcache`
--


-- --------------------------------------------------------

--
-- Table structure for table `jos_fadegallery`
--

CREATE TABLE IF NOT EXISTS `jos_fadegallery` (
  `id` int(10) NOT NULL auto_increment,
  `galleryname` varchar(50) NOT NULL,
  `folder` varchar(255) default NULL,
  `filelist` text NOT NULL,
  `width` int(10) unsigned NOT NULL default '400',
  `height` int(10) unsigned NOT NULL default '300',
  `interval` int(10) unsigned NOT NULL default '6000',
  `fadetime` int(10) unsigned NOT NULL default '2000',
  `fadestep` int(10) unsigned NOT NULL default '20',
  `align` varchar(20) default NULL,
  `cssstyle` varchar(255) default NULL,
  `padding` int(6) unsigned NOT NULL default '0',
  `randomize` int(1) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `jos_fadegallery`
--

INSERT INTO `jos_fadegallery` (`id`, `galleryname`, `folder`, `filelist`, `width`, `height`, `interval`, `fadetime`, `fadestep`, `align`, `cssstyle`, `padding`, `randomize`) VALUES
(1, 'wonder', 'images/image_slide/', '', 130, 80, 2000, 2000, 1000, 'right', NULL, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `jos_groups`
--

CREATE TABLE IF NOT EXISTS `jos_groups` (
  `id` tinyint(3) unsigned NOT NULL default '0',
  `name` varchar(50) NOT NULL default '',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `jos_groups`
--

INSERT INTO `jos_groups` (`id`, `name`) VALUES
(0, 'Public'),
(1, 'Registered'),
(2, 'Special');

-- --------------------------------------------------------

--
-- Table structure for table `jos_jf_content`
--

CREATE TABLE IF NOT EXISTS `jos_jf_content` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `language_id` int(11) NOT NULL default '0',
  `reference_id` int(11) NOT NULL default '0',
  `reference_table` varchar(100) NOT NULL default '',
  `reference_field` varchar(100) NOT NULL default '',
  `value` mediumtext NOT NULL,
  `original_value` varchar(255) default NULL,
  `original_text` mediumtext NOT NULL,
  `modified` datetime NOT NULL default '0000-00-00 00:00:00',
  `modified_by` int(11) unsigned NOT NULL default '0',
  `published` tinyint(1) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `combo` (`reference_id`,`reference_field`,`reference_table`),
  KEY `jfContent` (`language_id`,`reference_id`,`reference_table`),
  KEY `jfContentLanguage` (`reference_id`,`reference_field`,`reference_table`,`language_id`),
  KEY `reference_id` (`reference_id`),
  KEY `language_id` (`language_id`),
  KEY `reference_table` (`reference_table`),
  KEY `reference_field` (`reference_field`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=219 ;

--
-- Dumping data for table `jos_jf_content`
--

INSERT INTO `jos_jf_content` (`id`, `language_id`, `reference_id`, `reference_table`, `reference_field`, `value`, `original_value`, `original_text`, `modified`, `modified_by`, `published`) VALUES
(1, 2, 1, 'content', 'title', 'សថាកដសដថ', 'c2bcffe03b42a5c33e84e5fe59662b4e', '', '2011-04-01 14:11:15', 62, 1),
(2, 2, 1, 'content', 'introtext', '<p>សដថ​ លសដក្ថល សក្ដថល សក្ដថល លាស្កថលក ដសក្ថាលក កដស្ថលា</p>\r\n<p>លសា្ថដលក សល្កថដា​គ្ដសថលា្សដថ  ្លាស្ថល កសដថលកាកស<img src="images/stories/clock.jpg" border="0" /></p>', '3890d184b83ec8b09de8ec930df34472', '', '2011-04-01 14:11:15', 62, 1),
(3, 2, 1, 'content', 'fulltext', '', 'd41d8cd98f00b204e9800998ecf8427e', '', '2011-04-01 14:11:15', 62, 1),
(4, 2, 1, 'content', 'attribs', 'created_by=62\ncreated_by_alias=\naccess=0\ncreated=\npublish_up=\npublish_down=\nshow_title=1\nlink_titles=0\nshow_intro=1\nshow_section=0\nlink_section=0\nshow_category=0\nlink_category=0\nshow_vote=0\nshow_author=0\nshow_create_date=0\nshow_modify_date=0\nshow_pdf_icon=1\nshow_print_icon=1\nshow_email_icon=1\nlanguage=en-GB\nkeyref=\nreadmore=\n\n', '794eb327e2f0505fa3049f3752ff7473', '', '2011-04-01 14:11:15', 62, 1),
(5, 2, 1, 'menu', 'name', 'Accueil', '8cf04a9734132302f96da8e113e80ce5', '', '2011-04-24 03:46:10', 62, 1),
(6, 2, 1, 'menu', 'alias', 'accueil', '106a6c241b8797f52e1e77317b96a201', '', '2011-04-24 03:46:10', 62, 1),
(7, 2, 1, 'menu', 'params', 'num_leading_articles=1\nnum_intro_articles=4\nnum_columns=2\nnum_links=4\npage_title=\nshow_page_title=1\npageclass_sfx=\nmenu_image=-1\nsecure=0\norderby_pri=\norderby_sec=front\nmulti_column_order=1\nshow_pagination=2\nshow_pagination_results=1\nshow_feed_link=1\nshow_noauth=\nshow_title=\nlink_titles=\nshow_intro=\nshow_section=\nlink_section=\nshow_category=\nlink_category=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_item_navigation=\nshow_readmore=\nshow_vote=\nshow_icons=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nshow_hits=\nfeed_summary=\n\n', 'b837ba4b075a4cf6979ed2fc4b8afa2f', '', '2011-04-24 03:46:10', 62, 1),
(8, 2, 1, 'menu', 'link', 'index.php?option=com_content&view=frontpage', '2f791f200ff60956d42c607a5bd44303', '', '2011-04-24 03:46:10', 62, 1),
(9, 2, 13, 'menu', 'name', 'Battambang Hôtel', '97ca94922e57ab8e75a5c4c3647a33ad', '', '2011-04-01 16:22:34', 62, 1),
(10, 2, 13, 'menu', 'alias', 'battambang-hotel', '769ff71e5d519caffe3acb17320497fd', '', '2011-04-01 16:22:34', 62, 1),
(11, 2, 13, 'menu', 'params', 'page_title=\nshow_page_title=1\npageclass_sfx=\nmenu_image=-1\nsecure=0\nshow_noauth=\nshow_title=\nlink_titles=\nshow_intro=\nshow_section=\nlink_section=\nshow_category=\nlink_category=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_item_navigation=\nshow_readmore=\nshow_vote=\nshow_icons=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nshow_hits=\nfeed_summary=\n\n', '5abdcb8e4a1b658293691263ef4674d4', '', '2011-04-01 16:22:34', 62, 1),
(12, 2, 13, 'menu', 'link', 'index.php?option=com_content&view=article&layout=form', '2516582f6717b1e9d6fcf1556ceb78c3', '', '2011-04-01 16:22:34', 62, 1),
(13, 2, 3, 'menu', 'name', 'Hôtel Cambode', '6d753785de8009a989bc3739fa87e4de', '', '2011-04-01 16:23:11', 62, 1),
(14, 2, 3, 'menu', 'alias', 'hotel-cambode', '5f4b9d363753745a68acc38847f6b1ee', '', '2011-04-01 16:23:11', 62, 1),
(15, 2, 3, 'menu', 'params', 'page_title=\nshow_page_title=1\npageclass_sfx=\nmenu_image=-1\nsecure=0\nshow_noauth=\nshow_title=\nlink_titles=\nshow_intro=\nshow_section=\nlink_section=\nshow_category=\nlink_category=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_item_navigation=\nshow_readmore=\nshow_vote=\nshow_icons=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nshow_hits=\nfeed_summary=\n\n', '5abdcb8e4a1b658293691263ef4674d4', '', '2011-04-01 16:23:11', 62, 1),
(16, 2, 3, 'menu', 'link', 'index.php?option=com_content&view=article&layout=form', '2516582f6717b1e9d6fcf1556ceb78c3', '', '2011-04-01 16:23:11', 62, 1),
(17, 2, 2, 'menu', 'name', 'Tours As Cambode', '47b64167176acb22986bac96199b94c2', '', '2011-04-01 16:24:20', 62, 1),
(18, 2, 2, 'menu', 'alias', 'tours-as-cambode', '590c7aec33a8aad4780bb900d7fc5454', '', '2011-04-01 16:24:20', 62, 1),
(19, 2, 2, 'menu', 'params', 'page_title=\nshow_page_title=1\npageclass_sfx=\nmenu_image=-1\nsecure=0\nshow_noauth=\nshow_title=\nlink_titles=\nshow_intro=\nshow_section=\nlink_section=\nshow_category=\nlink_category=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_item_navigation=\nshow_readmore=\nshow_vote=\nshow_icons=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nshow_hits=\nfeed_summary=\n\n', '5abdcb8e4a1b658293691263ef4674d4', '', '2011-04-01 16:24:20', 62, 1),
(20, 2, 2, 'menu', 'link', 'index.php?option=com_content&view=article&layout=form', '2516582f6717b1e9d6fcf1556ceb78c3', '', '2011-04-01 16:24:20', 62, 1),
(21, 2, 9, 'menu', 'name', 'voyages d''aventure', 'bbfd3ab23e14c57cd1194d4016fa3065', '', '2011-04-01 16:26:28', 62, 1),
(22, 2, 9, 'menu', 'alias', 'voyages-daventure', '9fe3dd178360de6e493f36176cc10bc3', '', '2011-04-01 16:26:28', 62, 1),
(23, 2, 9, 'menu', 'params', 'page_title=\nshow_page_title=1\npageclass_sfx=\nmenu_image=-1\nsecure=0\nshow_noauth=\nshow_title=\nlink_titles=\nshow_intro=\nshow_section=\nlink_section=\nshow_category=\nlink_category=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_item_navigation=\nshow_readmore=\nshow_vote=\nshow_icons=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nshow_hits=\nfeed_summary=\n\n', '5abdcb8e4a1b658293691263ef4674d4', '', '2011-04-01 16:26:28', 62, 1),
(24, 2, 9, 'menu', 'link', 'index.php?option=com_content&view=article&layout=form', '2516582f6717b1e9d6fcf1556ceb78c3', '', '2011-04-01 16:26:28', 62, 1),
(25, 2, 7, 'menu', 'name', 'Circuits classiques', 'e5f221bf9b02091cecdc0d12ce9461b9', '', '2011-04-01 16:26:58', 62, 1),
(26, 2, 7, 'menu', 'alias', 'circuits-classiques', '7005338b084f9ac2992f201c952481db', '', '2011-04-01 16:26:58', 62, 1),
(27, 2, 7, 'menu', 'params', 'page_title=\nshow_page_title=1\npageclass_sfx=\nmenu_image=-1\nsecure=0\nshow_noauth=\nshow_title=\nlink_titles=\nshow_intro=\nshow_section=\nlink_section=\nshow_category=\nlink_category=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_item_navigation=\nshow_readmore=\nshow_vote=\nshow_icons=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nshow_hits=\nfeed_summary=\n\n', '5abdcb8e4a1b658293691263ef4674d4', '', '2011-04-01 16:26:58', 62, 1),
(28, 2, 7, 'menu', 'link', 'index.php?option=com_content&view=article&layout=form', '2516582f6717b1e9d6fcf1556ceb78c3', '', '2011-04-01 16:26:58', 62, 1),
(29, 2, 4, 'menu', 'name', 'Galerie', '5c93310dd0291e121181e830cdda892e', '', '2011-04-01 16:27:23', 62, 1),
(30, 2, 4, 'menu', 'alias', 'galerie', '2767cc3ede7592a47bd6657e3799565c', '', '2011-04-01 16:27:23', 62, 1),
(31, 2, 4, 'menu', 'params', 'page_title=\nshow_page_title=1\npageclass_sfx=\nmenu_image=-1\nsecure=0\nshow_noauth=\nshow_title=\nlink_titles=\nshow_intro=\nshow_section=\nlink_section=\nshow_category=\nlink_category=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_item_navigation=\nshow_readmore=\nshow_vote=\nshow_icons=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nshow_hits=\nfeed_summary=\n\n', '5abdcb8e4a1b658293691263ef4674d4', '', '2011-04-01 16:27:23', 62, 1),
(32, 2, 4, 'menu', 'link', 'index.php?option=com_content&view=article&layout=form', '2516582f6717b1e9d6fcf1556ceb78c3', '', '2011-04-01 16:27:23', 62, 1),
(33, 2, 10, 'menu', 'name', 'Golf Tours', 'cdd591b4a90cf759c2acb603adada70d', '', '2011-04-01 16:27:50', 62, 1),
(34, 2, 10, 'menu', 'alias', 'golf-tours', 'd663a44993441e0e648d100c082c4508', '', '2011-04-01 16:27:50', 62, 1),
(35, 2, 10, 'menu', 'params', 'page_title=\nshow_page_title=1\npageclass_sfx=\nmenu_image=-1\nsecure=0\nshow_noauth=\nshow_title=\nlink_titles=\nshow_intro=\nshow_section=\nlink_section=\nshow_category=\nlink_category=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_item_navigation=\nshow_readmore=\nshow_vote=\nshow_icons=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nshow_hits=\nfeed_summary=\n\n', '5abdcb8e4a1b658293691263ef4674d4', '', '2011-04-01 16:27:50', 62, 1),
(36, 2, 10, 'menu', 'link', 'index.php?option=com_content&view=article&layout=form', '2516582f6717b1e9d6fcf1556ceb78c3', '', '2011-04-01 16:27:50', 62, 1),
(37, 2, 8, 'menu', 'name', 'Tours de lune de miel', '8784bad0af1f97afadd69ece81b741a6', '', '2011-04-01 16:28:21', 62, 1),
(38, 2, 8, 'menu', 'alias', 'tours-de-lune-de-miel', 'e86c349c46b53c0c1f3acd3fe5ab95ce', '', '2011-04-01 16:28:21', 62, 1),
(39, 2, 8, 'menu', 'params', 'page_title=\nshow_page_title=1\npageclass_sfx=\nmenu_image=-1\nsecure=0\nshow_noauth=\nshow_title=\nlink_titles=\nshow_intro=\nshow_section=\nlink_section=\nshow_category=\nlink_category=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_item_navigation=\nshow_readmore=\nshow_vote=\nshow_icons=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nshow_hits=\nfeed_summary=\n\n', '5abdcb8e4a1b658293691263ef4674d4', '', '2011-04-01 16:28:21', 62, 1),
(40, 2, 8, 'menu', 'link', 'index.php?option=com_content&view=article&layout=form', '2516582f6717b1e9d6fcf1556ceb78c3', '', '2011-04-01 16:28:21', 62, 1),
(45, 2, 4, 'content', 'title', 'Examen de voyage Voyage', 'ae9ca1d60ce535686ef7ff0230c8dc5e', '', '2011-04-03 15:57:07', 62, 1),
(46, 2, 4, 'content', 'alias', 'examen-de-voyage-voyage', 'd7e50d336f3eab540b802dbbc33bd94b', '', '2011-04-03 15:57:07', 62, 1),
(47, 2, 4, 'content', 'introtext', '<p style="text-align: justify"><span class="hps" title="Click for alternate translations"><img src="images/stories/62997628_ww8ndkv3__f2p4226.jpg" border="0" alt="abc" width="200" height="130" align="left" style="float: left; border: 1px solid black; margin-left: 10px; margin-right: 10px; margin-top: 1px; margin-bottom: 1px;" />Ma</span> <span class="hps" title="Click for alternate translations">récente visite</span> <span class="hps" title="Click for alternate translations">à</span> <span class="hps" title="Click for alternate translations">Angkorwat</span> <span class="hps" title="Click for alternate translations">Temple</span> <span class="hps" title="Click for alternate translations">a été</span> <span class="hps" title="Click for alternate translations">un moment inoubliable</span><span title="Click for alternate translations">.</span> <span class="hps" title="Click for alternate translations">J''ai été conquise</span> <span class="hps" title="Click for alternate translations">au</span> <span class="hps" title="Click for alternate translations">point de vue bouddhiste</span> <span class="hps" title="Click for alternate translations">parle</span> <span class="hps" title="Click for alternate translations">complexe</span> <span class="hps" title="Click for alternate translations">du temple</span> <span class="hps" title="Click for alternate translations">de</span> <span class="hps" title="Click for alternate translations">l''architecture</span> <span class="hps" title="Click for alternate translations">du 12ème siècle</span><span title="Click for alternate translations">.</span> <span class="hps" title="Click for alternate translations">Après avoir obtenu un</span> <span class="hps" title="Click for alternate translations">coup d''oeil</span> <span class="hps" title="Click for alternate translations">à</span> <span class="hps" title="Click for alternate translations">ce</span> <span class="hps" title="Click for alternate translations">patrimoine</span> <span class="hps" title="Click for alternate translations">mondialement connu</span><span title="Click for alternate translations">,</span> <span class="hps" title="Click for alternate translations">j''ai aussi</span> <span class="hps" title="Click for alternate translations">connu</span> <span class="hps" title="Click for alternate translations">un lever de soleil</span> <span class="hps" title="Click for alternate translations">à couper le souffle</span> <span class="hps" title="Click for alternate translations">à</span> <span class="hps" title="Click for alternate translations">Banteay Srei</span> <span class="hps" title="Click for alternate translations">et</span> <span class="hps" title="Click for alternate translations">a vu</span> <span class="hps" title="Click for alternate translations">la</span> <span class="hps" title="Click for alternate translations">Terrasse</span> <span class="hps" title="Click for alternate translations">des</span> <span class="hps" title="Click for alternate translations">Rois</span> <span class="hps" title="Click for alternate translations">Lépreux</span> <span class="hps" title="Click for alternate translations">et la terrasse</span> <span class="hps" title="Click for alternate translations">des Eléphants</span><span title="Click for alternate translations">.</span><span title="Click for alternate translations"> \r\n', '86ed4c3c8b0bd3d146dbee963f240d80', '', '2011-04-03 15:57:07', 62, 1),
(48, 2, 4, 'content', 'fulltext', '\r\n</span></p>\r\n<p style="text-align: justify"><span class="hps" title="Click for alternate translations">Zurker</span> <span class="hps" title="Click for alternate translations">Frankatine</span></p>\r\n<p style="text-align: justify"><span class="hps" title="Click for alternate translations">Ma</span> <span class="hps" title="Click for alternate translations">récente visite</span> <span class="hps" title="Click for alternate translations">à</span> <span class="hps" title="Click for alternate translations">Angkorwat</span> <span class="hps" title="Click for alternate translations">Temple</span> <span class="hps" title="Click for alternate translations">a été</span> <span class="hps" title="Click for alternate translations">un moment inoubliable</span><span title="Click for alternate translations">.</span> <span class="hps" title="Click for alternate translations">J''ai été conquise</span> <span class="hps" title="Click for alternate translations">au</span> <span class="hps" title="Click for alternate translations">point de vue bouddhiste</span> <span class="hps" title="Click for alternate translations">parle</span> <span class="hps" title="Click for alternate translations">complexe</span> <span class="hps" title="Click for alternate translations">du temple</span> <span class="hps" title="Click for alternate translations">de</span> <span class="hps" title="Click for alternate translations">l''architecture</span> <span class="hps" title="Click for alternate translations">du 12ème siècle</span><span title="Click for alternate translations">.</span> <span class="hps" title="Click for alternate translations">Après avoir obtenu un</span> <span class="hps" title="Click for alternate translations">coup d''oeil</span> <span class="hps" title="Click for alternate translations">à</span> <span class="hps" title="Click for alternate translations">ce</span> <span class="hps" title="Click for alternate translations">patrimoine</span> <span class="hps" title="Click for alternate translations">mondialement connu</span><span title="Click for alternate translations">,</span> <span class="hps" title="Click for alternate translations">j''ai aussi</span> <span class="hps" title="Click for alternate translations">connu</span> <span class="hps" title="Click for alternate translations">un lever de soleil</span> <span class="hps" title="Click for alternate translations">à couper le souffle</span> <span class="hps" title="Click for alternate translations">à</span> <span class="hps" title="Click for alternate translations">Banteay Srei</span> <span class="hps" title="Click for alternate translations">et</span> <span class="hps" title="Click for alternate translations">a vu</span> <span class="hps" title="Click for alternate translations">la</span> <span class="hps" title="Click for alternate translations">Terrasse</span> <span class="hps" title="Click for alternate translations">des</span> <span class="hps" title="Click for alternate translations">Rois</span> <span class="hps" title="Click for alternate translations">Lépreux</span> <span class="hps" title="Click for alternate translations">et la terrasse</span> <span class="hps" title="Click for alternate translations">des Eléphants</span><span title="Click for alternate translations">.</span><br /><span class="hps" title="Click for alternate translations">Zurker</span> <span class="hps" title="Click for alternate translations">Frankatin<span class="hps" title="Click for alternate translations">Ma</span> <span class="hps" title="Click for alternate translations">récente visite</span> <span class="hps" title="Click for alternate translations">à</span> <span class="hps" title="Click for alternate translations">Angkorwat</span> <span class="hps" title="Click for alternate translations">Temple</span> <span class="hps" title="Click for alternate translations">a été</span> <span class="hps" title="Click for alternate translations">un moment inoubliable</span><span title="Click for alternate translations">.</span> <span class="hps" title="Click for alternate translations">J''ai été conquise</span> <span class="hps" title="Click for alternate translations">au</span> <span class="hps" title="Click for alternate translations">point de vue bouddhiste</span> <span class="hps" title="Click for alternate translations">parle</span> <span class="hps" title="Click for alternate translations">complexe</span> <span class="hps" title="Click for alternate translations">du temple</span> <span class="hps" title="Click for alternate translations">de</span> <span class="hps" title="Click for alternate translations">l''architecture</span> <span class="hps" title="Click for alternate translations">du 12ème siècle</span><span title="Click for alternate translations">.</span> <span class="hps" title="Click for alternate translations">Après avoir obtenu un</span> <span class="hps" title="Click for alternate translations">coup d''oeil</span> <span class="hps" title="Click for alternate translations">à</span> <span class="hps" title="Click for alternate translations">ce</span> <span class="hps" title="Click for alternate translations">patrimoine</span> <span class="hps" title="Click for alternate translations">mondialement connu</span><span title="Click for alternate translations">,</span> <span class="hps" title="Click for alternate translations">j''ai aussi</span> <span class="hps" title="Click for alternate translations">connu</span> <span class="hps" title="Click for alternate translations">un lever de soleil</span> <span class="hps" title="Click for alternate translations">à couper le souffle</span> <span class="hps" title="Click for alternate translations">à</span> <span class="hps" title="Click for alternate translations">Banteay Srei</span> <span class="hps" title="Click for alternate translations">et</span> <span class="hps" title="Click for alternate translations">a vu</span> <span class="hps" title="Click for alternate translations">la</span> <span class="hps" title="Click for alternate translations">Terrasse</span> <span class="hps" title="Click for alternate translations">des</span> <span class="hps" title="Click for alternate translations">Rois</span> <span class="hps" title="Click for alternate translations">Lépreux</span> <span class="hps" title="Click for alternate translations">et la terrasse</span> <span class="hps" title="Click for alternate translations">des Eléphants</span><span title="Click for alternate translations">.</span><br /><span class="hps" title="Click for alternate translations">Zurker</span> <span class="hps" title="Click for alternate translations">Frankatine</span>e</span></p>\r\n<p><span title="Click for alternate translations"> </span></p>\r\n<p> </p>', 'd55e1b6661beb6dfe8c77f507939bcb1', '', '2011-04-03 15:57:07', 62, 1),
(49, 2, 4, 'content', 'attribs', 'created_by=62\ncreated_by_alias=\naccess=0\ncreated=\npublish_up=\npublish_down=\nshow_title=1\nlink_titles=0\nshow_intro=1\nshow_section=0\nlink_section=0\nshow_category=0\nlink_category=0\nshow_vote=0\nshow_author=0\nshow_create_date=0\nshow_modify_date=0\nshow_pdf_icon=0\nshow_print_icon=1\nshow_email_icon=1\nlanguage=en-GB\nkeyref=\nreadmore=\n\n', '5340d79181dec8226e05fe66d21ab67a', '', '2011-04-03 15:57:07', 62, 1),
(50, 2, 2, 'content', 'title', 'A propos de Cambodai', '69248bd10365f7ba7127cab0ac4ef906', '', '2011-04-03 16:14:01', 62, 1),
(51, 2, 2, 'content', 'alias', 'a-propos-de-cambodai', '287676a0d2bb9be6ca13cce276431c81', '', '2011-04-03 16:14:01', 62, 1),
(52, 2, 2, 'content', 'introtext', '<p style="text-align: justify"><span class="hps" title="Click for alternate translations"><img src="images/stories/55350730__f2p0750.jpg" border="0" width="200" height="130" style="float: left; border: 1px solid black; margin-left: 10px; margin-right: 10px; margin-top: 1px; margin-bottom: 1px;" />Personne ne</span> <span class="hps" title="Click for alternate translations">sait</span> <span class="hps" title="Click for alternate translations">avec certitude</span> <span class="hps" title="Click for alternate translations">combien de personnes</span> <span class="hps" title="Click for alternate translations">ont vécu</span> <span class="hps" title="Click for alternate translations">longtemps</span> <span class="hps" title="Click for alternate translations">dans</span> <span class="hps" title="Click for alternate translations">ce qui est maintenant</span> <span class="hps" title="Click for alternate translations">le Cambodge</span><span title="Click for alternate translations">,</span> <span class="hps" title="Click for alternate translations">les études</span> <span class="hps" title="Click for alternate translations">de sa</span> <span class="hps" title="Click for alternate translations">préhistoire</span> <span class="hps" title="Click for alternate translations">sont sous-développés</span><span title="Click for alternate translations">.</span> <span class="hps" title="Click for alternate translations">Un</span> <span class="hps" title="Click for alternate translations">carbone</span><span class="atn" title="Click for alternate translations">-</span><span title="Click for alternate translations">l4</span> <span class="hps" title="Click for alternate translations">datant</span> <span class="hps" title="Click for alternate translations">d''une</span> <span class="hps" title="Click for alternate translations">grotte</span> <span class="hps" title="Click for alternate translations">au nord-ouest</span> <span class="hps" title="Click for alternate translations">du Cambodge</span> <span class="hps" title="Click for alternate translations">suggère</span> <span class="hps" title="Click for alternate translations">que les personnes utilisant</span> <span class="hps" title="Click for alternate translations">des outils</span> <span class="hps" title="Click for alternate translations">de pierre</span> <span class="hps" title="Click for alternate translations">vivaient</span> <span class="hps" title="Click for alternate translations">dans</span> <span class="hps" title="Click for alternate translations">la grotte</span> <span class="hps" title="Click for alternate translations">aussi tôt</span> <span class="hps" title="Click for alternate translations">que</span> <span class="hps" title="Click for alternate translations">4000 ans avant JC</span><span title="Click for alternate translations">,</span> <span class="hps" title="Click for alternate translations">et</span> <span class="hps" title="Click for alternate translations">le riz</span> <span class="hps" title="Click for alternate translations">a</span> <span class="hps" title="Click for alternate translations">été</span> <span class="hps" title="Click for alternate translations">cultivé</span> <span class="hps" title="Click for alternate translations">sur</span> <span class="hps" title="Click for alternate translations">le sol cambodgien</span> <span class="hps" title="Click for alternate translations">depuis bien</span> <span class="hps" title="Click for alternate translations">avant</span><span class="hps" title="Click for alternate translations"> \r\n', '63884ee527fecf42fd24feeb9c7aaa7e', '', '2011-04-03 16:14:01', 62, 1),
(53, 2, 2, 'content', 'fulltext', '\r\n</span></p>\r\n<p> </p>\r\n<p> </p>\r\n<p><span class="hps atn" title="Click for alternate translations"><span class="hps" title="Click for alternate translations">Le</span> <span class="hps" title="Click for alternate translations">royaume khmer</span> <span class="hps atn" title="Click for alternate translations">(</span><span title="Click for alternate translations">Funan</span><span title="Click for alternate translations">)</span><br /></span></p>\r\n<p style="text-align: justify;"><span class="hps atn" title="Click for alternate translations"><span class="hps" title="Click for alternate translations">Les premiers écrivains</span> <span class="hps" title="Click for alternate translations">chinois visé</span> <span class="hps" title="Click for alternate translations">un royaume</span> <span class="hps" title="Click for alternate translations">au Cambodge</span> <span class="hps" title="Click for alternate translations">qu''ils ont appelé</span> <span class="hps" title="Click for alternate translations">Funan</span><span title="Click for alternate translations">.</span> <span class="hps" title="Click for alternate translations">Moderne</span> <span class="hps" title="Click for alternate translations">découvertes archéologiques</span> <span class="hps" title="Click for alternate translations">témoignent d''une</span> <span class="hps" title="Click for alternate translations">société</span> <span class="hps" title="Click for alternate translations">commerciale</span> <span class="hps" title="Click for alternate translations">centrée sur</span> <span class="hps" title="Click for alternate translations">le</span> <span class="hps" title="Click for alternate translations">delta du</span> <span class="hps" title="Click for alternate translations">Mékong</span> <span class="hps" title="Click for alternate translations">qui</span> <span class="hps" title="Click for alternate translations">a prospéré à partir</span> <span class="hps" title="Click for alternate translations">du 1er siècle</span> <span class="hps" title="Click for alternate translations">au</span> <span class="hps" title="Click for alternate translations">6ème siècle</span><span title="Click for alternate translations">.</span> <span class="hps" title="Click for alternate translations">Parmi</span> <span class="hps" title="Click for alternate translations">ces</span> <span class="hps" title="Click for alternate translations">résultats</span> <span class="hps" title="Click for alternate translations">sont</span> <span class="hps" title="Click for alternate translations">fouilles</span> <span class="hps" title="Click for alternate translations">d''une ville</span> <span class="hps" title="Click for alternate translations">portuaire</span> <span class="hps" title="Click for alternate translations">du</span> <span class="hps" title="Click for alternate translations">1er siècle</span><span title="Click for alternate translations">,</span> <span class="hps" title="Click for alternate translations">situé</span> <span class="hps" title="Click for alternate translations">dans</span> <span class="hps" title="Click for alternate translations">la</span> <span class="hps" title="Click for alternate translations">région</span> <span class="hps" title="Click for alternate translations">d''Oc</span><span title="Click for alternate translations">-Eo</span> <span class="hps" title="Click for alternate translations">dans ce qui</span> <span class="hps" title="Click for alternate translations">est</span> <span class="hps" title="Click for alternate translations">aujourd''hui le sud du</span> <span class="hps" title="Click for alternate translations">Vietnam</span><span title="Click for alternate translations">.</span> <span class="hps" title="Click for alternate translations">Desservie par</span> <span class="hps" title="Click for alternate translations">un réseau de</span> <span class="hps" title="Click for alternate translations">canaux</span><span title="Click for alternate translations">,</span> <span class="hps" title="Click for alternate translations">la</span> <span class="hps" title="Click for alternate translations">ville</span> <span class="hps" title="Click for alternate translations">a été</span> <span class="hps" title="Click for alternate translations">un lien commercial important</span> <span class="hps" title="Click for alternate translations">entre</span> <span class="hps" title="Click for alternate translations">l''Inde</span> <span class="hps" title="Click for alternate translations">et</span> <span class="hps" title="Click for alternate translations">la Chine</span><span title="Click for alternate translations">.</span> <span class="hps" title="Click for alternate translations">Fouilles</span> <span class="hps" title="Click for alternate translations">en cours</span> <span class="hps" title="Click for alternate translations">dans</span> <span class="hps" title="Click for alternate translations">le sud</span> <span class="hps" title="Click for alternate translations">du Cambodge</span> <span class="hps atn" title="Click for alternate translations">ont révélé l''</span><span title="Click for alternate translations">existence</span> <span class="hps atn" title="Click for alternate translations">d''</span><span title="Click for alternate translations">une autre</span> <span class="hps" title="Click for alternate translations">ville</span> <span class="hps" title="Click for alternate translations">importante</span> <span class="hps" title="Click for alternate translations">à proximité</span> <span class="hps" title="Click for alternate translations">du village</span> <span class="hps" title="Click for alternate translations">actuel</span> <span class="hps" title="Click for alternate translations">de</span> <span class="hps" title="Click for alternate translations">Angkor</span> <span class="hps" title="Click for alternate translations">Borei</span><span title="Click for alternate translations">.</span><br /></span></p>\r\n<p style="text-align: justify;"><span class="hps atn" title="Click for alternate translations"><span class="hps" title="Click for alternate translations">Un groupe</span> <span class="hps" title="Click for alternate translations">de</span> <span class="hps" title="Click for alternate translations">royaumes</span> <span class="hps" title="Click for alternate translations">intérieure</span><span title="Click for alternate translations">,</span> <span class="hps" title="Click for alternate translations">connus</span> <span class="hps" title="Click for alternate translations">collectivement</span> <span class="hps" title="Click for alternate translations">pour</span> <span class="hps" title="Click for alternate translations">les Chinois</span> <span class="hps" title="Click for alternate translations">comme</span> <span class="hps" title="Click for alternate translations">Zhenla</span><span title="Click for alternate translations">,</span> <span class="hps" title="Click for alternate translations">a prospéré</span> <span class="hps" title="Click for alternate translations">dans</span> <span class="hps" title="Click for alternate translations">les</span> <span class="hps" title="Click for alternate translations">6e et 7e siècles</span> <span class="hps" title="Click for alternate translations">dans le sud</span> <span class="hps" title="Click for alternate translations">du Cambodge</span> <span class="hps" title="Click for alternate translations">dans le sud</span> <span class="hps" title="Click for alternate translations">du Laos</span><span title="Click for alternate translations">.</span> <span class="hps" title="Click for alternate translations">Les</span> <span class="hps" title="Click for alternate translations">inscriptions</span> <span class="hps" title="Click for alternate translations">première pierre</span> <span class="hps" title="Click for alternate translations">dans la</span> <span class="hps" title="Click for alternate translations">langue</span> <span class="hps" title="Click for alternate translations">khmère</span> <span class="hps" title="Click for alternate translations">et</span> <span class="hps" title="Click for alternate translations">la</span> <span class="hps" title="Click for alternate translations">première brique</span> <span class="hps" title="Click for alternate translations">et</span> <span class="hps" title="Click for alternate translations">la pierre</span> <span class="hps" title="Click for alternate translations">des temples hindous</span> <span class="hps" title="Click for alternate translations">en</span> <span class="hps" title="Click for alternate translations">date</span> <span class="hps" title="Click for alternate translations">du Cambodge</span> <span class="hps" title="Click for alternate translations">de la</span> <span class="hps" title="Click for alternate translations">période</span> <span class="hps" title="Click for alternate translations">Zhenla</span></span></p>\r\n<p> </p>', '4624d3ae91beb5cc42da686fe045bcb7', '', '2011-04-03 16:14:01', 62, 1),
(54, 2, 2, 'content', 'attribs', 'created_by=62\ncreated_by_alias=\naccess=0\ncreated=\npublish_up=\npublish_down=\nshow_title=1\nlink_titles=0\nshow_intro=1\nshow_section=0\nlink_section=0\nshow_category=0\nlink_category=0\nshow_vote=0\nshow_author=0\nshow_create_date=0\nshow_modify_date=0\nshow_pdf_icon=0\nshow_print_icon=1\nshow_email_icon=1\nlanguage=fr-FR\nkeyref=\nreadmore=\n\n', '5340d79181dec8226e05fe66d21ab67a', '', '2011-04-03 16:14:01', 62, 1),
(55, 2, 3, 'content', 'title', 'A propos de voyage au Cambodge', '9cb5cda7a0c592ae9d05219aa09facdc', '', '2011-04-03 16:39:29', 62, 1),
(56, 2, 3, 'content', 'alias', 'about-cambodia-trip', '2525d2b1957f26579f4dc98e9cc25f30', '', '2011-04-03 16:39:29', 62, 1),
(57, 2, 3, 'content', 'introtext', '<p style="text-align: justify;"><span class="hps" title="Click for alternate translations"><img src="images/stories/55350739__f2p1035.jpg" border="0" width="200" height="130" style="float: left; border: 1px solid black; margin-left: 10px; margin-right: 10px; margin-top: 1px; margin-bottom: 1px;" />Cambodia trip advisor.com</span> <span class="hps" title="Click for alternate translations">a été exploitée comme</span> <span class="hps" title="Click for alternate translations">une</span> <span class="hps" title="Click for alternate translations">agence de</span> <span class="hps" title="Click for alternate translations">Voyage</span> <span class="hps" title="Click for alternate translations">à service complet</span> <span class="hps" title="Click for alternate translations">au</span> <span class="hps" title="Click for alternate translations">Cambodge</span> <span class="hps" title="Click for alternate translations">depuis près de 10</span> <span class="hps" title="Click for alternate translations">ans,</span> <span class="hps" title="Click for alternate translations">et</span> <span class="hps" title="Click for alternate translations">a été</span> <span class="hps" title="Click for alternate translations">entièrement autorisé</span> <span class="hps" title="Click for alternate translations">par</span> <span class="hps" title="Click for alternate translations">le </span><span class="hps" title="Click for alternate translations">Cambodge </span><span class="hps" title="Click for alternate translations">de l''Autorité nationale</span> <span class="hps" title="Click for alternate translations">du Tourisme</span> <span class="hps" title="Click for alternate translations">comme un</span> <span class="hps" title="Click for alternate translations">Tour Opérateur International</span> <span class="hps" title="Click for alternate translations">Licence</span> <span class="hps" title="Click for alternate translations">ATCGBRY</span> <span class="hps" title="Click for alternate translations">028/10</span> <span class="hps" title="Click for alternate translations">Nous sommes</span> <span class="hps" title="Click for alternate translations">spécialisés</span> <span class="hps" title="Click for alternate translations">dans les voyages</span> <span class="hps" title="Click for alternate translations">sur</span><span class="hps" title="Click for alternate translations"> mesure</span><span class="hps" title="Click for alternate translations">et</span> <span class="hps" title="Click for alternate translations">personnalisées</span> <span class="hps" title="Click for alternate translations">pour</span> <span class="hps" title="Click for alternate translations">les couples</span><span title="Click for alternate translations">, </span><span title="Click for alternate translations">familles et groupes</span><span title="Click for alternate translations">,</span> <span class="hps" title="Click for alternate translations">ceux qui recherchent un</span> <span class="hps" title="Click for alternate translations">précieux</span> <span class="hps" title="Click for alternate translations">...</span></p>\r\n', '64d9356bd83cc58940ef9929df4bf15c', '', '2011-04-03 16:39:29', 62, 1),
(58, 2, 3, 'content', 'fulltext', '\r\n<p> </p>\r\n<p><span class="hps" title="Click for alternate translations">A Walk</span> <span class="hps" title="Click for alternate translations">to Remember</span></p>\r\n<p style="text-align: justify;"><span class="hps" title="Click for alternate translations">Il</span> <span class="hps" title="Click for alternate translations">était</span> <span class="hps" title="Click for alternate translations">tout simplement</span> <span class="hps" title="Click for alternate translations">un fabuleux voyage</span> <span class="hps" title="Click for alternate translations">organisé</span> <span class="hps" title="Click for alternate translations">par</span> <span class="hps" title="Click for alternate translations">mes copains</span> <span class="hps" title="Click for alternate translations">responsable</span> <span class="hps" title="Click for alternate translations">au</span> <span class="hps" title="Click for alternate translations">Angkorwat</span> <span class="hps" title="Click for alternate translations">Discovery.com</span><span title="Click for alternate translations">.</span> <span class="hps" title="Click for alternate translations">Il aurait</span> <span class="hps" title="Click for alternate translations">été</span> <span class="hps" title="Click for alternate translations">un véritable</span> <span class="hps" title="Click for alternate translations">manque</span><span title="Click for alternate translations">,</span> <span class="hps" title="Click for alternate translations">si</span> <span class="hps" title="Click for alternate translations">nous</span> <span class="hps" title="Click for alternate translations">aurait</span> <span class="hps" title="Click for alternate translations">sauté</span> <span class="hps" title="Click for alternate translations">du voyage</span><span title="Click for alternate translations">,</span> <span class="hps" title="Click for alternate translations">que</span> <span class="hps" title="Click for alternate translations">nous avons décidé</span> <span class="hps" title="Click for alternate translations">au départ,</span> <span class="hps" title="Click for alternate translations">mais</span> <span class="hps" title="Click for alternate translations">il</span> <span class="hps" title="Click for alternate translations">a été</span> <span class="hps" title="Click for alternate translations">prédestiné</span> <span class="hps" title="Click for alternate translations">et</span> <span class="hps" title="Click for alternate translations">nous l''avons donc</span> <span class="hps" title="Click for alternate translations">fait</span> <span class="hps" title="Click for alternate translations">nos valises</span> <span class="hps" title="Click for alternate translations">et</span> <span class="hps" title="Click for alternate translations">et</span> <span class="hps" title="Click for alternate translations">exposées sur le</span> <span class="hps" title="Click for alternate translations">voyage merveilleux</span> <span class="hps" title="Click for alternate translations">à</span> <span class="hps" title="Click for alternate translations">Combodia</span><span title="Click for alternate translations">.</span> <span class="hps" title="Click for alternate translations">Toutes</span> <span class="hps" title="Click for alternate translations">les</span> <span class="hps" title="Click for alternate translations">destinations</span><span title="Click for alternate translations">, nous avons</span> <span class="hps" title="Click for alternate translations">exploré</span> <span class="hps" title="Click for alternate translations">dans le</span> <span class="hps" title="Click for alternate translations">beau pays</span> <span class="hps" title="Click for alternate translations">ont été</span> <span class="hps" title="Click for alternate translations">simplement</span> <span class="hps" title="Click for alternate translations">splendide</span><span title="Click for alternate translations">, mais</span> <span class="hps atn" title="Click for alternate translations">l''</span><span title="Click for alternate translations">endroit</span> <span class="hps" title="Click for alternate translations">que j''ai</span> <span class="hps" title="Click for alternate translations">aimé le</span> <span class="hps" title="Click for alternate translations">plus</span> <span class="hps" title="Click for alternate translations">était</span> <span class="hps" title="Click for alternate translations">d''Angkor</span> <span class="hps" title="Click for alternate translations">Wat</span><span title="Click for alternate translations">.</span> <span class="hps" title="Click for alternate translations">J''ai</span> <span class="hps" title="Click for alternate translations">tout simplement tombée en</span> <span class="hps" title="Click for alternate translations">amour</span> <span class="hps" title="Click for alternate translations">avec</span> <span class="hps" title="Click for alternate translations">les</span> <span class="hps" title="Click for alternate translations">environs de</span> <span class="hps" title="Click for alternate translations">l''endroit</span> <span class="hps" title="Click for alternate translations">pittoresque</span><span title="Click for alternate translations">.</span> <span class="hps" title="Click for alternate translations">Le</span> <span class="hps" title="Click for alternate translations">sympathique guide</span> <span class="hps" title="Click for alternate translations">fourni</span> <span class="hps" title="Click for alternate translations">par</span> <span class="hps" title="Click for alternate translations">Angkorwat</span> <span class="hps" title="Click for alternate translations">Discovery.com</span> <span class="hps" title="Click for alternate translations">a</span> <span class="hps" title="Click for alternate translations">représenté</span> <span class="hps" title="Click for alternate translations">l''essentiel</span> <span class="hps" title="Click for alternate translations">des</span> <span class="hps" title="Click for alternate translations">points de repère</span> <span class="hps" title="Click for alternate translations">différents</span> <span class="hps" title="Click for alternate translations">si vivement</span><span title="Click for alternate translations">,</span> <span class="hps" title="Click for alternate translations">que, pour</span> <span class="hps" title="Click for alternate translations">un temps, il</span> <span class="hps" title="Click for alternate translations">semble</span> <span class="hps" title="Click for alternate translations">que</span> <span class="hps" title="Click for alternate translations">nous</span> <span class="hps" title="Click for alternate translations">avons</span> <span class="hps" title="Click for alternate translations">été</span> <span class="hps" title="Click for alternate translations">transportés</span> <span class="hps" title="Click for alternate translations">à</span> <span class="hps" title="Click for alternate translations">ces</span> <span class="hps" title="Click for alternate translations">époques</span> <span class="hps" title="Click for alternate translations">perdu</span> <span class="hps" title="Click for alternate translations">..</span> <span class="hps" title="Click for alternate translations">Son</span> <span class="hps" title="Click for alternate translations">habileté</span> <span class="hps" title="Click for alternate translations">de communication</span> <span class="hps" title="Click for alternate translations">a été</span> <span class="hps" title="Click for alternate translations">tout simplement excellents</span><span title="Click for alternate translations">,</span> <span class="hps" title="Click for alternate translations">il</span> <span class="hps" title="Click for alternate translations">était honnête</span> <span class="hps" title="Click for alternate translations">et</span> <span class="hps" title="Click for alternate translations">bel et bien</span> <span class="hps" title="Click for alternate translations">professionnel</span><span title="Click for alternate translations">.</span> <span class="hps" title="Click for alternate translations">M.</span> <span class="hps" title="Click for alternate translations">David</span> <span class="hps" title="Click for alternate translations">en effet</span> <span class="hps" title="Click for alternate translations">fait</span> <span class="hps" title="Click for alternate translations">le voyage</span> <span class="hps" title="Click for alternate translations">une</span> <span class="hps" title="Click for alternate translations">préoccupation</span><span title="Click for alternate translations">.</span> <span class="hps" title="Click for alternate translations">Les</span> <span class="hps" title="Click for alternate translations">remerciements vont à</span> <span class="hps" title="Click for alternate translations">rien d''autre</span> <span class="hps" title="Click for alternate translations">que</span> <span class="hps" title="Click for alternate translations">la découverte</span> <span class="hps" title="Click for alternate translations">d''Angkor Wat</span><span title="Click for alternate translations">.</span> <span class="hps" title="Click for alternate translations">Nous avons roulé</span> <span class="hps" title="Click for alternate translations">tout autour</span> <span class="hps" title="Click for alternate translations">dans une</span> <span class="hps" title="Click for alternate translations">voiture</span> <span class="hps" title="Click for alternate translations">big air</span> <span class="hps" title="Click for alternate translations">conditionné</span> <span class="hps" title="Click for alternate translations">dans les emplacements</span> <span class="hps" title="Click for alternate translations">grand</span> <span class="hps" title="Click for alternate translations">comme</span> <span class="hps" title="Click for alternate translations">Siem</span> <span class="hps" title="Click for alternate translations">et</span> <span class="hps" title="Click for alternate translations">d''autres</span><span title="Click for alternate translations">.</span> <span class="hps" title="Click for alternate translations">Je vous</span> <span class="hps" title="Click for alternate translations">recommande</span> <span class="hps" title="Click for alternate translations">à tous ceux qui</span> <span class="hps" title="Click for alternate translations">sont</span> <span class="hps" title="Click for alternate translations">des voyageurs</span> <span class="hps" title="Click for alternate translations">au</span> <span class="hps" title="Click for alternate translations">coeur</span></p>', 'b0980351874b53b57d75628ceab006a1', '', '2011-04-03 16:39:29', 62, 1),
(59, 2, 3, 'content', 'attribs', 'created_by=62\ncreated_by_alias=\naccess=0\ncreated=\npublish_up=\npublish_down=\nshow_title=1\nlink_titles=0\nshow_intro=1\nshow_section=0\nlink_section=0\nshow_category=0\nlink_category=0\nshow_vote=0\nshow_author=0\nshow_create_date=0\nshow_modify_date=0\nshow_pdf_icon=0\nshow_print_icon=1\nshow_email_icon=1\nlanguage=fr-FR\nkeyref=\nreadmore=\n\n', '5340d79181dec8226e05fe66d21ab67a', '', '2011-04-03 16:39:29', 62, 1),
(60, 2, 27, 'modules', 'title', 'ABONNEMENT', '4269b95f24c8cdb6c52a9b69d2934010', '', '2011-04-11 06:15:10', 62, 1),
(61, 2, 27, 'modules', 'params', 'introtext=Contactez-nous par Mail\nreceipt_email=\nsubject=\nthanks=Envoyer Mail est un succès\nerror=Non sended, erreur\nsubmit_button=Envoyer\nmoduleclass_sfx=\n\n', 'fd9f82b94d3065470512f88ae7a976cb', '', '2011-04-11 06:15:10', 62, 1),
(62, 2, 22, 'menu', 'name', 'formulaire de contact', '619fef488ade3f6b4e42ae71f696ce7e', '', '2011-04-03 14:06:46', 62, 0),
(63, 2, 22, 'menu', 'alias', 'formulaire-de-contact', '96cc1b4b8e01ae1d87e5c1cf6f14e7ca', '', '2011-04-03 14:06:46', 62, 0),
(64, 2, 22, 'menu', 'params', 'display_num=20\nimage=-1\nimage_align=right\nshow_limit=1\nshow_feed_link=1\npage_title=\nshow_page_title=1\npageclass_sfx=\nmenu_image=-1\nsecure=0\ncontact_icons=\nicon_address=\nicon_email=\nicon_telephone=\nicon_mobile=\nicon_fax=\nicon_misc=\nshow_headings=\nshow_position=\nshow_email=\nshow_telephone=\nshow_mobile=\nshow_fax=\nallow_vcard=\nbanned_email=\nbanned_subject=\nbanned_text=\nvalidate_session=1\ncustom_reply=1\n\n', 'fd1b94609810d802090d43c06a99cc76', '', '2011-04-03 14:06:46', 62, 0);
INSERT INTO `jos_jf_content` (`id`, `language_id`, `reference_id`, `reference_table`, `reference_field`, `value`, `original_value`, `original_text`, `modified`, `modified_by`, `published`) VALUES
(65, 2, 22, 'menu', 'link', 'index.php?option=com_contact&view=category&catid=1', '799a4301dcd2c41507ecb32cf2f3a284', '', '2011-04-03 14:06:46', 62, 0),
(66, 2, 22, 'menu', 'name', 'formulaire de contact', '619fef488ade3f6b4e42ae71f696ce7e', '', '2011-04-03 14:08:47', 62, 1),
(67, 2, 22, 'menu', 'alias', 'formulaire-de-contact', '96cc1b4b8e01ae1d87e5c1cf6f14e7ca', '', '2011-04-03 14:08:47', 62, 1),
(68, 2, 22, 'menu', 'params', 'display_num=20\nimage=-1\nimage_align=right\nshow_limit=1\nshow_feed_link=1\npage_title=\nshow_page_title=1\npageclass_sfx=\nmenu_image=-1\nsecure=0\ncontact_icons=\nicon_address=\nicon_email=\nicon_telephone=\nicon_mobile=\nicon_fax=\nicon_misc=\nshow_headings=\nshow_position=\nshow_email=\nshow_telephone=\nshow_mobile=\nshow_fax=\nallow_vcard=\nbanned_email=\nbanned_subject=\nbanned_text=\nvalidate_session=1\ncustom_reply=1\n\n', 'fd1b94609810d802090d43c06a99cc76', '', '2011-04-03 14:08:47', 62, 1),
(69, 2, 22, 'menu', 'link', 'index.php?option=com_contact&view=category&catid=1', '799a4301dcd2c41507ecb32cf2f3a284', '', '2011-04-03 14:08:47', 62, 1),
(70, 2, 14, 'menu', 'name', 'Hôtel Kamport ', '9b3e4b441505c699acd6da1a9e60b080', '', '2011-04-03 14:22:21', 62, 1),
(71, 2, 14, 'menu', 'alias', 'hotel-kamport-', '540dcc017162b014ba4a7882f8033a1d', '', '2011-04-03 14:22:21', 62, 1),
(72, 2, 14, 'menu', 'params', 'page_title=\nshow_page_title=1\npageclass_sfx=\nmenu_image=-1\nsecure=0\nshow_noauth=\nshow_title=\nlink_titles=\nshow_intro=\nshow_section=\nlink_section=\nshow_category=\nlink_category=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_item_navigation=\nshow_readmore=\nshow_vote=\nshow_icons=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nshow_hits=\nfeed_summary=\n\n', '5abdcb8e4a1b658293691263ef4674d4', '', '2011-04-03 14:22:21', 62, 1),
(73, 2, 14, 'menu', 'link', 'index.php?option=com_content&view=article&layout=form', '2516582f6717b1e9d6fcf1556ceb78c3', '', '2011-04-03 14:22:21', 62, 1),
(74, 2, 15, 'menu', 'name', 'Hôtel Kep ', 'c686a3ed307c13acb5d1f620636e4e8a', '', '2011-04-03 14:21:53', 62, 1),
(75, 2, 15, 'menu', 'alias', 'hotel-kep-', '46d67bca0ec905d66137875776604c7f', '', '2011-04-03 14:21:53', 62, 1),
(76, 2, 15, 'menu', 'params', 'page_title=\nshow_page_title=1\npageclass_sfx=\nmenu_image=-1\nsecure=0\nshow_noauth=\nshow_title=\nlink_titles=\nshow_intro=\nshow_section=\nlink_section=\nshow_category=\nlink_category=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_item_navigation=\nshow_readmore=\nshow_vote=\nshow_icons=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nshow_hits=\nfeed_summary=\n\n', '5abdcb8e4a1b658293691263ef4674d4', '', '2011-04-03 14:21:53', 62, 1),
(77, 2, 15, 'menu', 'link', 'index.php?option=com_content&view=article&layout=form', '2516582f6717b1e9d6fcf1556ceb78c3', '', '2011-04-03 14:21:53', 62, 1),
(78, 2, 16, 'menu', 'name', 'Hôtel Koh Kong', 'e480bc7ffcc273d46f4e8322336a9ed8', '', '2011-04-03 14:21:14', 62, 1),
(79, 2, 16, 'menu', 'alias', 'hotel-koh-kong', 'beaa5e427146dd89757653f8d7366607', '', '2011-04-03 14:21:14', 62, 1),
(80, 2, 16, 'menu', 'params', 'page_title=\nshow_page_title=1\npageclass_sfx=\nmenu_image=-1\nsecure=0\nshow_noauth=\nshow_title=\nlink_titles=\nshow_intro=\nshow_section=\nlink_section=\nshow_category=\nlink_category=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_item_navigation=\nshow_readmore=\nshow_vote=\nshow_icons=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nshow_hits=\nfeed_summary=\n\n', '5abdcb8e4a1b658293691263ef4674d4', '', '2011-04-03 14:21:14', 62, 1),
(81, 2, 16, 'menu', 'link', 'index.php?option=com_content&view=article&layout=form', '2516582f6717b1e9d6fcf1556ceb78c3', '', '2011-04-03 14:21:14', 62, 1),
(82, 2, 17, 'menu', 'name', 'Hôtel Kompong Tom', 'e0ab7879f083b25d3bd3f2caff995ecd', '', '2011-04-03 14:20:19', 62, 1),
(83, 2, 17, 'menu', 'alias', 'hotel-kompong-tom', '95c2721d9c4af8aadb523b2b327560fc', '', '2011-04-03 14:20:19', 62, 1),
(84, 2, 17, 'menu', 'params', 'page_title=\nshow_page_title=1\npageclass_sfx=\nmenu_image=-1\nsecure=0\nshow_noauth=\nshow_title=\nlink_titles=\nshow_intro=\nshow_section=\nlink_section=\nshow_category=\nlink_category=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_item_navigation=\nshow_readmore=\nshow_vote=\nshow_icons=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nshow_hits=\nfeed_summary=\n\n', '5abdcb8e4a1b658293691263ef4674d4', '', '2011-04-03 14:20:19', 62, 1),
(85, 2, 17, 'menu', 'link', 'index.php?option=com_content&view=article&layout=form', '2516582f6717b1e9d6fcf1556ceb78c3', '', '2011-04-03 14:20:19', 62, 1),
(86, 2, 18, 'menu', 'name', 'Hôtel Phnom Penh', 'b0e3bfe4a00ef36d8d7ead8129a69c15', '', '2011-04-03 14:19:29', 62, 1),
(87, 2, 18, 'menu', 'alias', 'hotel-phnom-penh', 'aa253bc7aec3585d2b1ad911f26ec33c', '', '2011-04-03 14:19:29', 62, 1),
(88, 2, 18, 'menu', 'params', 'page_title=\nshow_page_title=1\npageclass_sfx=\nmenu_image=-1\nsecure=0\nshow_noauth=\nshow_title=\nlink_titles=\nshow_intro=\nshow_section=\nlink_section=\nshow_category=\nlink_category=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_item_navigation=\nshow_readmore=\nshow_vote=\nshow_icons=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nshow_hits=\nfeed_summary=\n\n', '5abdcb8e4a1b658293691263ef4674d4', '', '2011-04-03 14:19:29', 62, 1),
(89, 2, 18, 'menu', 'link', 'index.php?option=com_content&view=article&layout=form', '2516582f6717b1e9d6fcf1556ceb78c3', '', '2011-04-03 14:19:29', 62, 1),
(90, 2, 11, 'menu', 'name', 'Tours à Phnom Penh', 'a6adf787a4e180bb4fe2eeefcd888c8a', '', '2011-04-03 14:18:37', 62, 1),
(91, 2, 11, 'menu', 'alias', 'tours-a-phnom-penh', 'a85c2744b0f04cccc2738169df668594', '', '2011-04-03 14:18:37', 62, 1),
(92, 2, 11, 'menu', 'params', 'page_title=\nshow_page_title=1\npageclass_sfx=\nmenu_image=-1\nsecure=0\nshow_noauth=\nshow_title=\nlink_titles=\nshow_intro=\nshow_section=\nlink_section=\nshow_category=\nlink_category=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_item_navigation=\nshow_readmore=\nshow_vote=\nshow_icons=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nshow_hits=\nfeed_summary=\n\n', '5abdcb8e4a1b658293691263ef4674d4', '', '2011-04-03 14:18:37', 62, 1),
(93, 2, 11, 'menu', 'link', 'index.php?option=com_content&view=article&layout=form', '2516582f6717b1e9d6fcf1556ceb78c3', '', '2011-04-03 14:18:37', 62, 1),
(94, 2, 19, 'menu', 'name', 'Hôtel Siem Reap ', '67a214ea9c3714e8679de4501dcf235d', '', '2011-04-03 14:26:14', 62, 1),
(95, 2, 19, 'menu', 'alias', 'siem-reap-hotel', 'b0b7c80526b01c6e8a088cae742485fd', '', '2011-04-03 14:26:14', 62, 1),
(96, 2, 19, 'menu', 'params', 'page_title=\nshow_page_title=1\npageclass_sfx=\nmenu_image=-1\nsecure=0\nshow_noauth=\nshow_title=\nlink_titles=\nshow_intro=\nshow_section=\nlink_section=\nshow_category=\nlink_category=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_item_navigation=\nshow_readmore=\nshow_vote=\nshow_icons=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nshow_hits=\nfeed_summary=\n\n', '5abdcb8e4a1b658293691263ef4674d4', '', '2011-04-03 14:26:14', 62, 1),
(97, 2, 19, 'menu', 'link', 'index.php?option=com_content&view=article&layout=form', '2516582f6717b1e9d6fcf1556ceb78c3', '', '2011-04-03 14:26:14', 62, 1),
(98, 2, 12, 'menu', 'name', 'Tours à Siem Reap', '2ba3492f99442ab61bdb3c20b8c2b301', '', '2011-04-03 14:27:15', 62, 1),
(99, 2, 12, 'menu', 'alias', 'tours-a-siem-reap', '04f4b924b20a6d3270cf1d98a2ca541e', '', '2011-04-03 14:27:15', 62, 1),
(100, 2, 12, 'menu', 'params', 'page_title=\nshow_page_title=1\npageclass_sfx=\nmenu_image=-1\nsecure=0\nshow_noauth=\nshow_title=\nlink_titles=\nshow_intro=\nshow_section=\nlink_section=\nshow_category=\nlink_category=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_item_navigation=\nshow_readmore=\nshow_vote=\nshow_icons=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nshow_hits=\nfeed_summary=\n\n', '5abdcb8e4a1b658293691263ef4674d4', '', '2011-04-03 14:27:15', 62, 1),
(101, 2, 12, 'menu', 'link', 'index.php?option=com_content&view=article&layout=form', '2516582f6717b1e9d6fcf1556ceb78c3', '', '2011-04-03 14:27:15', 62, 1),
(102, 2, 20, 'menu', 'name', 'Hôtels Sihanoukville', '7849f675d67d8950b9444f0b058321fb', '', '2011-04-03 14:28:31', 62, 1),
(103, 2, 20, 'menu', 'alias', 'hotels-sihanoukville', 'f92b2c62cf0859dd7a7e5cb8843dedac', '', '2011-04-03 14:28:31', 62, 1),
(104, 2, 20, 'menu', 'params', 'page_title=\nshow_page_title=1\npageclass_sfx=\nmenu_image=-1\nsecure=0\nshow_noauth=\nshow_title=\nlink_titles=\nshow_intro=\nshow_section=\nlink_section=\nshow_category=\nlink_category=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_item_navigation=\nshow_readmore=\nshow_vote=\nshow_icons=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nshow_hits=\nfeed_summary=\n\n', '5abdcb8e4a1b658293691263ef4674d4', '', '2011-04-03 14:28:31', 62, 1),
(105, 2, 20, 'menu', 'link', 'index.php?option=com_content&view=article&layout=form', '2516582f6717b1e9d6fcf1556ceb78c3', '', '2011-04-03 14:28:31', 62, 1),
(106, 2, 5, 'menu', 'name', 'Guide de Voyage', '5e39933c7a40620afaa6a2863f2c4952', '', '2011-04-11 06:00:59', 62, 1),
(107, 2, 5, 'menu', 'alias', 'guide-de-voyage', '16d572f3541c786131f44972f068bdea', '', '2011-04-11 06:00:59', 62, 1),
(108, 2, 5, 'menu', 'params', 'page_title=\nshow_page_title=1\npageclass_sfx=\nmenu_image=-1\nsecure=0\nshow_noauth=0\nshow_title=0\nlink_titles=0\nshow_intro=0\nshow_section=0\nlink_section=0\nshow_category=0\nlink_category=0\nshow_author=0\nshow_create_date=0\nshow_modify_date=0\nshow_item_navigation=0\nshow_readmore=0\nshow_vote=0\nshow_icons=0\nshow_pdf_icon=0\nshow_print_icon=0\nshow_email_icon=0\nshow_hits=0\nfeed_summary=\n\n', 'c3e4723696aa8fa0f0ccc451a0a0f161', '', '2011-04-11 06:00:59', 62, 1),
(109, 2, 5, 'menu', 'link', 'index.php?option=com_content&view=article&layout=form', '71ffa4ee856dc25ae97d8b2914104fa6', '', '2011-04-11 06:00:59', 62, 1),
(110, 2, 5, 'content', 'title', 'Sur le Cambodge', '69248bd10365f7ba7127cab0ac4ef906', '', '2011-04-24 13:14:55', 62, 1),
(111, 2, 5, 'content', 'alias', 'sur-le-cambodge', '287676a0d2bb9be6ca13cce276431c81', '', '2011-04-24 13:14:55', 62, 1),
(112, 2, 5, 'content', 'introtext', '<p style="text-align: justify;"><strong>Tour Operator par le ministère cambodgien du Tourisme</strong><br /><br /><br /> www.abktours.comest un tour opérateur leader au service des clients nationaux et internationaux dans la région de l''Indochine. Nous pouvons réparer votre besoins Voyage au Cambodge, au Vietnam et au Laos. Notre équipe dynamique et enthousiaste sont bien formés, expérimentés et multilingues. Nous pouvons répondre à vos besoins en anglais, en langues française et chinoise, et nous sommes toujours prêts à aider nos clients dans toutes les circonstances et les cas urgents. Nous nous sommes engagés à fournir des services de la plus haute qualité à nos clients afin de s''assurer que votre expérience est satisfaisante et que vous appréciez beaucoup de moments inoubliables lorsque vous voyagez avec nous.<br /><br />Nous offrons des petits groupes privés paquets Tour à toutes les parties du Cambodge, et spécialisé dans les voyages sur mesure et la personnalisation de décisions pour les individus, les familles et les groupes à besoins spécifiques à la grande valeur pour l''argent. Hôtels et restaurants sont sélectionnés avec soin pour offrir confort et la meilleure cuisine locale. Nos guides parlant anglais sont compétents et expérimentés. Nous vous amène à une des meilleures attractions et sites touristiques dans les voitures à l''aise avec la sécurité des conducteurs.<br /><br />Nous travaillons dur pour offrir à nos clients une expérience inoubliable au Cambodge et de nombreux clients sont revenus au Cambodge avec nous et nous a gentiment renvoyés dans leur famille et amis. Venez découvrir la beauté et la diversité du Cambodge avec nous.<br /><br /><strong>Pourquoi Voyage avec nous?</strong><br /><br />Nos collaborateurs ont visité de nombreux endroits que vous souhaitez voir. Nos services sont la vraie valeur de l''argent. Nous offrons une garantie de remboursement si nos services ne sont pas pour satisfaire vos attentes.<br /><br />En tant que conseil en tourisme spécialisé, nous comprenons ce que veulent nos clients. Nos consultants peuvent concevoir un itinéraire personnalisé en fonction de vos besoins et votre budget. Nous vous conseillerons et la conception d''un calendrier de la tournée unique à vos attentes. Notre service amical et fiable va ajouter à la jouissance de votre expérience Voyage dans la région de l''Indochine.<br /><br />CambodiaTripAdvisor place la sécurité de ses clients comme «première priorité». Le Cambodge est considéré comme l''une des destinations les plus sûres dans le monde à Voyage et nous sommes toujours à jour ce qui se passe dans la région.<br /><br />Quand vous venez à CambodiaTripAdvisor vous recevrez un efficace, la réponse favorable de nos guides. Nos guides sont très accueillants et expérimentés sont prêts à prendre soin de vous afin que vous puissiez profiter de merveilleuses vacances. La plupart de nos guides sont originaires, afin qu''ils puissent vous montrer beaucoup de choses intéressantes. Ils vous apporteront de Voyage sites à découvrir les populations locales et les vestiges historiques qui mettra au défi et vous surprendre.<br /><br />consultants Voyage Let''s CambodiaTripAdvisor organiser un voyage inoubliable pour vous. Nous nous engageons à dépasser vos attentes.<br /><br /><br />Cela implique de travailler directement avec vous, ensemble, nous concevons vos expériences Voyage unique, vous fournir les services actuels et vous offre au meilleur prix. Vous ne serez pas passer par un courtier! Lorsque vous traitez avec CambodiaTripAdvisor vous coupez tous les intermédiaires. Nos prix sont compétitifs. En outre, nous garantissons notre structure de prix est la vraie valeur de l''argent. Si vous n''êtes pas satisfait de CambodiaTripAdvisor vous pouvez demander un remboursement.</p>', '9f088fbfaf80fcd8e751e90aa7045c8d', '', '2011-04-24 13:14:55', 62, 1),
(113, 2, 5, 'content', 'fulltext', '', 'd41d8cd98f00b204e9800998ecf8427e', '', '2011-04-24 13:14:55', 62, 1),
(114, 2, 5, 'content', 'attribs', 'created_by=62\ncreated_by_alias=\naccess=0\ncreated=\npublish_up=\npublish_down=\nshow_title=0\nlink_titles=0\nshow_intro=0\nshow_section=0\nlink_section=0\nshow_category=0\nlink_category=0\nshow_vote=0\nshow_author=0\nshow_create_date=0\nshow_modify_date=0\nshow_pdf_icon=0\nshow_print_icon=1\nshow_email_icon=1\nlanguage=fr-FR\nkeyref=\nreadmore=\n\n', '0e2a1bdcc0e27655c05735d10f1d6a9e', '', '2011-04-24 13:14:55', 62, 1),
(115, 2, 8, 'content', 'title', 'Ambassade à l''étranger', '27a0f4f9c6db06be2c0ff328a7028052', '', '2011-04-26 11:20:44', 62, 1),
(116, 2, 8, 'content', 'alias', 'ambassade-a-letranger', '79bbbc512a30791a39ed90e1a3ed4787', '', '2011-04-26 11:20:44', 62, 1),
(117, 2, 8, 'content', 'introtext', '<div class="box_twothirds mt35 pr60">\r\n<table border="0" cellpadding="15" width="100%">\r\n<tbody>\r\n<tr>\r\n<td>\r\n<p align="center"><img src="images/stories/australi.png" border="0" /></p>\r\n<p align="center">AUSTRALIE<br />(Canberra)</p>\r\n</td>\r\n<td>\r\n<p align="center">Tel: (612) 6273 1259, 6273 1154<br />Fax: (612) 6273 1053<br />E-mail: cambodianembassy@ozemail.com.au<br />Website: www.embassyofcambodia.org.nz</p>\r\n</td>\r\n<td>\r\n<p align="center">Ambassade Royale du Cambodge<br />N ° 5 du Croissant-Rouge Canterbury,<br />Deakin, A.C.T. 2600, AUSTRALIE</p>\r\n</td>\r\n</tr>\r\n<tr>\r\n<td>\r\n<p align="center"><img src="images/stories/brunei00.png" border="0" /></p>\r\n<p align="center">BRUNEI DARUSSALAM<br />(Bandar Seri Begawan)</p>\r\n</td>\r\n<td>\r\n<p align="center">Tel: (673-2) 654 046<br />Fax: (673-2) 650 646<br />E-mail: cambodia@brunet.bn</p>\r\n</td>\r\n<td>\r\n<p align="center">Royal Embassy of Cambodia<br />8 Simpang 845 KG Tasek Meradum,<br />JLN Tutong, B.S.B,<br />BRUNEI DARUSSALAM</p>\r\n</td>\r\n</tr>\r\n<tr>\r\n<td>\r\n<p align="center"><img src="images/stories/china000.png" border="0" /></p>\r\n<p align="center">RÉPUBLIQUE POPULAIRE 0F CHINA<br />(Beijing)</p>\r\n</td>\r\n<td>\r\n<p align="center">Tel: (861) 06532 1889, 06532 7290<br />Fax: (861) 06532 3507<br />E-mail: cambassybeijing@yahoo.com</p>\r\n</td>\r\n<td>\r\n<p align="center">Royal Embassy of Cambodia<br />No. 9 Dong Zhi MenWai Dajio 100600 Beijing, P.R.CHINA</p>\r\n</td>\r\n</tr>\r\n<tr>\r\n<td>\r\n<p align="center"><img src="images/stories/china000.png" border="0" /></p>\r\n<p align="center">RÉPUBLIQUE POPULAIRE DE CHINE<br />(Guangzhou)</p>\r\n</td>\r\n<td>\r\n<p align="center">Tel: (8620) 838 79005<br />Fax: (8620) 838 79006<br />E-mail: cambodia@public.guangzhou.gd.cn</p>\r\n</td>\r\n<td>\r\n<p align="center">Royal Consulate General of Cambodia<br />The Garden Tower, Room 804 – 808Huanshi Rd.<br />E.Guangzhou P.R.. CHINA,P C : 510064</p>\r\n</td>\r\n</tr>\r\n<tr>\r\n<td>\r\n<p align="center"><img src="images/stories/china000.png" border="0" /></p>\r\n<p align="center">RÉPUBLIQUE POPULAIRE DE CHINE<br />(Hong Kong)</p>\r\n</td>\r\n<td>\r\n<p align="center">Tel : (852) 2546 0718, 2362 3656<br />Fax : (852) 2803 0570<br />E-mail : cacghk@netvigator.com</p>\r\n</td>\r\n<td>\r\n<p align="center">Royal Consulate General of Cambodia<br />Room No. 3606 Sigga CC 144-151, Connaught, Road West, HONG KONG, P.R.CHINA</p>\r\n</td>\r\n</tr>\r\n<tr>\r\n<td>\r\n<p align="center"><img src="images/stories/china000.png" border="0" /></p>\r\n<p align="center">RÉPUBLIQUE POPULAIRE DE CHINE<br />(Shanghai)</p>\r\n</td>\r\n<td>\r\n<p align="center">Tel : ( 8621) 636 1668, 636 00949<br />Fax : (8621) 636 11437<br />E-mail : tangjx@online.sh.cn</p>\r\n</td>\r\n<td>\r\n<p align="center">Royal Consulate General of Cambodia<br />Huasheng Commercial Building 9th Floor,<br />Hankou Road 400 Shanghai, P.R.CHINA</p>\r\n</td>\r\n</tr>\r\n<tr>\r\n<td>\r\n<p align="center"><img src="images/stories/cuba0000.png" border="0" /></p>\r\n<p align="center">REPUBLIC OF CUBA<br />( Havana )</p>\r\n</td>\r\n<td>\r\n<p align="center">Tel : (537) 241 495, 241 496, 242 333<br />Fax : (537) 246 400<br />E-mail : cambodia@ceniai.if.cu</p>\r\n</td>\r\n<td>\r\n<p align="center">Royal Embassy of Cambodia<br />No. 7001 Sta AV. ESQ 70 Miramar, Havana, CUBA</p>\r\n</td>\r\n</tr>\r\n<tr>\r\n<td>\r\n<p align="center"><img src="images/stories/france00.png" border="0" /></p>\r\n<p align="center">REPUBLIC OF FRANCE<br />( Paris )</p>\r\n</td>\r\n<td>\r\n<p align="center">Tel : (331) 4503 4720<br />Fax : (331) 4503 4740<br />Email : ambcambodgeparis@mangoosta.fr</p>\r\n</td>\r\n<td>\r\n<p align="center">Royal Embassy of Cambodia<br />4,rue Adolphe Yvon 75116 Paris, FRANCE</p>\r\n</td>\r\n</tr>\r\n<tr>\r\n<td>\r\n<p align="center"><img src="images/stories/france00.png" border="0" /></p>\r\n<p align="center">REPUBLIC OF FRANCE<br />( Paris )</p>\r\n</td>\r\n<td>\r\n<p align="center">Tel : (331) 4525 1502<br />Fax : (331) 4525 8472<br />E-mai l: DPCAMBODGE@wanadoo.fr</p>\r\n</td>\r\n<td>\r\n<p align="center">Permanent Delegation of the Kingdom of Cambodia to UNESCO<br />No. 2 Place de Barcelone75016 Paris, FRANCE</p>\r\n</td>\r\n</tr>\r\n<tr>\r\n<td>\r\n<p align="center"><img src="images/stories/germany0.png" border="0" /></p>\r\n<p align="center">FEDERAL REPUBLIC OF GERMANY<br />( Berlin )</p>\r\n</td>\r\n<td>\r\n<p align="center">Tel : (4930) 4863 7901<br />Fax : (4930) 4863 7973<br />E-mail : REC-Berlin@tonline.de</p>\r\n</td>\r\n<td>\r\n<p align="center">Royal Embassy of Cambodia<br />Benjamin-Vogelsdorf Str. 213187 Berlin, GERMANY</p>\r\n</td>\r\n</tr>\r\n<tr>\r\n<td>\r\n<p align="center"><img src="images/stories/india000.png" border="0" /></p>\r\n<p align="center">REPUBLIC OF INDIA<br />( New Delhi )</p>\r\n</td>\r\n<td>\r\n<p align="center">Tel: (91-11) 649 5091. 649 5092<br />Fax : (91-11) 649 5093<br />E-mail : camboemb@hclinfinet.com</p>\r\n</td>\r\n<td>\r\n<p align="center">Royal Embassy of Cambodia<br />N-14, Panchsheel Park, New Delhi-110017, INDIA</p>\r\n</td>\r\n</tr>\r\n<tr>\r\n<td>\r\n<p align="center"><img src="images/stories/indonesi.png" border="0" /></p>\r\n<p align="center">REPUBLIC OF INDONESIA<br />( Jakarta )</p>\r\n</td>\r\n<td>\r\n<p align="center">Tel : (62-21) 919 2895<br />Fax : (62-21) 520 2673<br />E-mail : recjkt@indo.net.id</p>\r\n</td>\r\n<td>\r\n<p align="center">Royal Embassy of Cambodia<br />JL.Kintamani Raya C15 No.33, Kuningan Timur<br />Jakarta Selatan 12950, Republic of Indonesia</p>\r\n</td>\r\n</tr>\r\n<tr>\r\n<td>\r\n<p align="center"><img src="images/stories/japan000.png" border="0" /></p>\r\n<p align="center">KINGDOM OF JAPAN<br />( Tokyo )</p>\r\n</td>\r\n<td>\r\n<p align="center">Tel : ( 813 ) 5412 8521-2-4<br />Fax : ( 813 ) 5412 8526<br />E-mail : aap33850@hkg.odn.ne.jp</p>\r\n</td>\r\n<td>\r\n<p align="center">Royal Embassy of Cambodia<br />8-6-9,Akasaka, Minato-Ku, Tokyo 1070052, JAPAN</p>\r\n</td>\r\n</tr>\r\n<tr>\r\n<td>\r\n<p align="center"><img src="images/stories/north korea.png" border="0" /></p>\r\n<p align="center">KOREA (D.P.R)<br />( Pyong Yang )</p>\r\n</td>\r\n<td>\r\n<p align="center">Tel : (8502) 381 7283<br />Fax : (8502) 381 7625</p>\r\n</td>\r\n<td>\r\n<p align="center">Royal Embassy of Cambodia.<br />Rue de L’université Commune Moscou<br />Arrondissement Daedongang<br />R.P.D. DU COREE</p>\r\n</td>\r\n</tr>\r\n<tr>\r\n<td>\r\n<p align="center"><img src="images/stories/south korea.png" border="0" /></p>\r\n<p align="center">KOREA REPUBLIC<br />( Seoul )</p>\r\n</td>\r\n<td>\r\n<p align="center">Tel : (822) 3785 1040<br />Fax : (822) 3785 1041<br />E-mail : camboemb@korea.com</p>\r\n</td>\r\n<td>\r\n<p align="center">Royal Embassy of Cambodia<br />653-8 Hanan Dong,Yougsan Gu,<br />Seoul , REPUBLIC OF KOREA</p>\r\n</td>\r\n</tr>\r\n<tr>\r\n<td>\r\n<p align="center"><img src="images/stories/laos0000.png" border="0" /></p>\r\n<p align="center">P.D.R. OF LAO<br />( Vientiane )</p>\r\n</td>\r\n<td>\r\n<p align="center">Tel : (8562) 131 4950, 131 4952, 131 5851<br />Fax : (8562) 131 4951<br />E-mail : recamlao@laotel.com</p>\r\n</td>\r\n<td>\r\n<p align="center">Royal Embassy of Cambodia<br />Thadeua Road, KM2Vientiane,<br />B.P. 34, LaoLAO P.D.R.</p>\r\n</td>\r\n</tr>\r\n<tr>\r\n<td>\r\n<p align="center"><img src="images/stories/malaysia.png" border="0" /></p>\r\n<p align="center">FEDERATION OF MALAYSIA<br />( Kuala Lumpur )</p>\r\n</td>\r\n<td>\r\n<p align="center">Tel : (603) 4257 1150, 4257 3711<br />Fax : (603) 4257 1157<br />E-mail : reckl@tm.net.my</p>\r\n</td>\r\n<td>\r\n<p align="center">Royal Embassy of Cambodia<br />Nº 46,Jalan U-Than55000 Kuala Lumpur, MALAYSIA</p>\r\n</td>\r\n</tr>\r\n<tr>\r\n<td>\r\n<p align="center"><img src="images/stories/myanmar0.png" border="0" /></p>\r\n<p align="center">UNION OF MYANMAR<br />( Yangon )</p>\r\n</td>\r\n<td>\r\n<p align="center">Tel : (951) 54 96 09, (951) 55 81 57<br />Fax : (951) 55 81 56<br />E-mail : RECYANGON@mptmail.net.mm</p>\r\n</td>\r\n<td>\r\n<p align="center">Royal Embassy of Cambodia<br />Nº. 25 &lt;3B, 4B&gt;, New University Avenue Road<br />Bahan Township, Yangon, MYANMAR</p>\r\n</td>\r\n</tr>\r\n<tr>\r\n<td>\r\n<p align="center"><img src="images/stories/philippi.png" border="0" /></p>\r\n<p align="center">REPUBLIC OF THE PHILIPPINES<br />( Manila )</p>\r\n</td>\r\n<td>\r\n<p align="center">Tel : (632) 818 9981<br />Fax : (632) 818 9983<br />E-mail : cam.emb.ma@netasia.net</p>\r\n</td>\r\n<td>\r\n<p align="center">Royal Embassy of Cambodia<br />Unit 7A/7th Floor, Country Space<br />I Bldg., Sen. Gil Puyat, Avenue Salcedo Village,<br />Makata City, MM, PHILIPPINES</p>\r\n</td>\r\n</tr>\r\n<tr>\r\n<td>\r\n<p align="center"><img src="images/stories/russian0.png" border="0" /></p>\r\n<p align="center">FERATION OF RUSSIA<br />( Moscow )</p>\r\n</td>\r\n<td>\r\n<p align="center">Tel : (7095) 201 7668, 201 2115,<br />201 3925, 201 2234<br />Fax : (7095) 956 6573<br />E-mail : cambodia@mail.cnt.ru</p>\r\n</td>\r\n<td>\r\n<p align="center">Royal Embassy of Cambodia<br />Starokonyushenny Per. 11, Moscow</p>\r\n</td>\r\n</tr>\r\n<tr>\r\n<td>\r\n<p align="center"><img src="images/stories/singapor.png" border="0" /></p>\r\n<p align="center">REPUBLIC OF SINGAPORE</p>\r\n</td>\r\n<td>\r\n<p align="center">Tel : (65) 299 3028<br />Fax : (65) 299 3622<br />E-mail : cambodiaembasy@pacific.net.sg</p>\r\n</td>\r\n<td>\r\n<p align="center">Royal Embassy of Cambodia<br />152 Beach Road, #11-05 Gateway East Singapore<br />189721, SINGAPORE</p>\r\n</td>\r\n</tr>\r\n<tr>\r\n<td>\r\n<p align="center"><img src="images/stories/switzerl.png" border="0" /></p>\r\n<p align="center">SWITZERLAND<br />( Geneva )</p>\r\n</td>\r\n<td>\r\n<p align="center">Tel : (41 22) 0479 341 776<br />Fax : (41 22)<br />E-mail : ssuos@wanadoo.fr</p>\r\n</td>\r\n<td>\r\n<p align="center">Permanent Mission of Cambodia<br />to UN and International Organizations<br />Geneva, SWITZERLAND</p>\r\n</td>\r\n</tr>\r\n<tr>\r\n<td>\r\n<p align="center"><img src="images/stories/thailand.png" border="0" /></p>\r\n<p align="center">KINGDOM OF THAILAND<br />( Bangkok )</p>\r\n</td>\r\n<td>\r\n<p align="center">Tel : (662) 254 6630, 253 9851, 253 7967<br />Fax : (662) 253 9859, 253 7961<br />E-mail : recbkk@cscoms.com</p>\r\n</td>\r\n<td>\r\n<p align="center">Royal Embassy of Cambodia<br />Nº 185 Rajdamri Road, Lumpini Patumwan Bangkok 10330, THAILAND</p>\r\n</td>\r\n</tr>\r\n<tr>\r\n<td>\r\n<p align="center"><img src="images/stories/thailand.png" border="0" /></p>\r\n<p align="center">KINGDOM OF THAILAND<br />( Sa Kaew )</p>\r\n</td>\r\n<td>\r\n<p align="center">Tel : (66 37) 421 734, 421 735<br />Fax : (66 37) 421 736<br />E-mail : consulsk@cscoms.com</p>\r\n</td>\r\n<td>\r\n<p align="center">Royal Consulate General of Cambodia<br />No. 666, Sovanasone Road Ampheu, Meung Sa Kaew 27000, Sa Kaew Province, THAILAND</p>\r\n</td>\r\n</tr>\r\n<tr>\r\n<td>\r\n<p align="center"><img src="images/stories/united states of america.png" border="0" /></p>\r\n<p align="center">U.S.A<br />( Washington )</p>\r\n</td>\r\n<td>\r\n<p align="center">Tel : (202) 726 7742<br />Fax : (202) 726 8381<br />E-mail : cambodia@embassy.org<br />Website : www.embassy.org/cambodia</p>\r\n</td>\r\n<td>\r\n<p align="center">Royal Embassy of Cambodia<br />4530 16th Street N.W. Washington , D.C 20011 U.S.A</p>\r\n</td>\r\n</tr>\r\n<tr>\r\n<td>\r\n<p align="center"><img src="images/stories/united states of america.png" border="0" /></p>\r\n<p align="center">U.S.A<br />( New York )</p>\r\n</td>\r\n<td>\r\n<p align="center">Tel : (1212) 223 0676, 369 1369<br />Fax : (1212) 223 0425<br />E-mail : cambodia@un.int<br />Website : www.un.int/cambodia</p>\r\n</td>\r\n<td>\r\n<p align="center">Permanent Mission of the Kingdom<br />of Cambodia to the United Nations<br />866 U.N.O, Plaza,Suite 420 New York, NY10017, USA</p>\r\n</td>\r\n</tr>\r\n<tr>\r\n<td>\r\n<p align="center"><img src="images/stories/united states of america.png" border="0" /></p>\r\n<p align="center">U.S.A<br />( Washington State )</p>\r\n</td>\r\n<td>\r\n<p align="center">Tel : (206) 217 0830<br />Fax : (206) 361 7888<br />E-mail : consul_huoth@diplomats.com</p>\r\n</td>\r\n<td>\r\n<p align="center">Royal Honorary Consulate of Cambodia<br />1818 Westlake Avenue N.,<br />Suite #315 Seattle, WA 98109, U.S.A</p>\r\n</td>\r\n</tr>\r\n<tr>\r\n<td>\r\n<p align="center"><img src="images/stories/viet0000.png" border="0" /></p>\r\n<p align="center">SOCIALIST REPUBLIC OF VIETNAM<br />( Hanoi )</p>\r\n</td>\r\n<td>\r\n<p align="center">Tel : (844) 942 4788, 942 4789<br />Mobile : 090 342 2034<br />Fax : (844) 942 3225<br />E-mail : arch@fpt.vn</p>\r\n</td>\r\n<td>\r\n<p align="center">Royal Embassy of Cambodia<br />71,Tran Hung Dao Str, Hanoi S.R.VIETNAM</p>\r\n</td>\r\n</tr>\r\n<tr>\r\n<td>\r\n<p align="center"><img src="images/stories/viet0000.png" border="0" /></p>\r\n<p align="center">SOCIALIST REPUBLIC OF VIETNAM<br />( Ho Chi Minh )</p>\r\n</td>\r\n<td>\r\n<p align="center">Tel : (848) 829 2751<br />Fax : (848) 829 2744<br />E-mail : cambocg@hcm.vnn.vn</p>\r\n</td>\r\n<td>\r\n<p align="center">Royal Consulate General of Cambodia<br />No. 41, Phung Khac Khoan,<br />Hochiminh City, S.R.VIETNAM</p>\r\n</td>\r\n</tr>\r\n</tbody>\r\n</table>\r\n</div>', '750e621f686f37f155a6f0af5c064de6', '', '2011-04-26 11:20:44', 62, 1),
(118, 2, 8, 'content', 'fulltext', '', 'd41d8cd98f00b204e9800998ecf8427e', '', '2011-04-26 11:20:44', 62, 1),
(119, 2, 8, 'content', 'attribs', 'created_by=62\ncreated_by_alias=\naccess=0\ncreated=\npublish_up=\npublish_down=\nshow_title=0\nlink_titles=0\nshow_intro=0\nshow_section=0\nlink_section=0\nshow_category=0\nlink_category=0\nshow_vote=0\nshow_author=0\nshow_create_date=0\nshow_modify_date=0\nshow_pdf_icon=0\nshow_print_icon=0\nshow_email_icon=0\nlanguage=fr-FR\nkeyref=\nreadmore=Ambassade à l''étranger\n\n', 'ade6b2f4433364cf113a6f0f4aa85686', '', '2011-04-26 11:20:44', 62, 1),
(120, 2, 10, 'content', 'title', 'Obtenez et sortir', '5efe30b3d8b0d5ef75bbbcada505475c', '', '2011-04-24 12:39:28', 62, 1),
(121, 2, 10, 'content', 'alias', 'obtenez-et-sortir', '5c8fe4bfe027be250e79e44e7a21d151', '', '2011-04-24 12:39:28', 62, 1),
(122, 2, 10, 'content', 'introtext', '<p> </p>\r\n', 'b4fd2950d719a280f071404d09085067', '', '2011-04-24 12:39:28', 62, 1),
(123, 2, 10, 'content', 'fulltext', '\r\n<p>Le Cambodge est desservi par un nombre croissant de vols en provenance des pays voisins à la fois à Phnom Penh et Siem Reap, bien que le meilleur choix est de Bangkok en Thaïlande. Il ya désormais cinq points de passage terrestres ouverts aux étrangers, deux en provenance de Thaïlande, du Vietnam et deux et un en provenance du Laos. Même si vous avez obtenu un visa avant l''entrée au Cambodge, il est essentiel d''obtenir un cachet d''entrée dans votre passeport pour franchir par voie terrestre, que l''insuffisance de le faire causer de sérieux problèmes quand vous venez de quitter le pays.<br /><br /><br /><strong><span style="text-decoration: underline;">THAÏLANDE</span></strong><br /><br />De Bangkok, il ya régulièrement des vols quotidiens à destination de Phnom Penh, prenant environ une heure, avec Thai Airways, Bangkok Airways, le dernier de ces offres de tarifs légèrement moins cher que les deux autres, mais ne peut pas être réservé à l''extérieur de la région. Bangkok Airways et Siem Reap Airways a également un vol quotidien à destination de Siem Reap, avec une fréquence légèrement plus élevée dans la haute saison de Décembre à Février. Le Cambodge Angkor Airways (National Ariline) sera opérationnel dès ce vol.<br /><br />Overland voyages au Cambodge en provenance de Thaïlande ont augmenté en popularité et sont bien connues à Bangkok, particularité sur la route de Khao San, où les agents Voyage essayer de vendre leurs Bangkok-Siem Reap voyages en alléguant que faire le voyage entraîne divers problèmes de manière indépendante (traitant du Cambodge agents à la frontière, le tri acheminement ultérieur, etc). En fait, c''est assez simple à faire le voyage par les transports publics, et la commodité d''utiliser l''une de ces entreprises privées peut être compensé par beaucoup d''attente autour jusqu''à ce que le nombre requis de passager se présente. Bien que la plupart de ces sociétés sont réputées, une petite minorité de voyageurs a déclaré avoir été arraché de visas, et même être laissés pendant des heures à la frontière d''attente pour la suite du transport, c''est pourquoi il vaut la peine de demander d''autres voyageurs du personnel de votre maison d''hôtes sur les entreprises qu''ils recommander ou à éviter.<br /><br />Le Aranyaprethet frontière Poipet passage à niveau est idéal si vous voulez commencer votre visite au Cambodge dans le nord de Battambang et de Siem Reap, tandis que Trat / Koh Kong est bon pour Sihanoukville et Phnom Penh. De Bangkok, vous pouvez rejoindre en train Aranyaprathet (7h) ou en bus de l''air-con (4 heures), il ya aussi des bus à air conditionné Trat 95hr). Les deux frontières sont ouvertes tous les jours (7 heures-17 heures) et les visas sont délivrés à l''arrivée. De Poipet, le transport par taxi partagé ou pick-up est à la disposition de Sisophon (pour Siem Reap) et les bateaux tous les jours de Hong Kong à Sre Ambel (pour Phnom Penh) et à Sihanoukville. Poipet est en ruines fait, la gare la plus proche étant à Sisophon.<br />Cambodge-Thaïlande passage de la frontière:<br />Yeam Cham Check Point International (province de Koh Kong)<br />Poi Pet Check Point International (province de Banteay Meanchey)<br />Point Osmach Vérifiez international (Province Meanchey odeur)<br />Point Sihanoukville Vérifiez international (province de Sihanoukville)<br />Sanguam Choam Check Point International (province de Banteay Meanchey)<br />Point Prum Vérifiez international (Province de Pailin)<br />Point Doung Vérifiez international (province de Battambang)<br />Preah Vihear Check Point International (province de Preah Vihear)<br /><br /><br /><strong><span style="text-decoration: underline;">VIETNAM</span></strong><br /><br />Il existe plusieurs vols quotidiens réguliers à destination de Phnom Penh et de Siem Reap au départ de Hô Chi Minh-Ville, exploités par Vietnam Airlines et Royal Phnom Penh Airways. Franchissement des frontières sont ouvertes aux étrangers à Moc Bai / Bavet, à 200km au sud-est de Phnom Penh, et à Chau Doc sur la rivière Bassac, grâce à noter que les visas cambodgiens ne sont pas émis à chaque point de passage. De Bavet, il est facile d''obtenir des taxis collectifs à Phnom Penh (6 heures), bien que la route a été dans un état déplorable, le temps de trajet devrait être réduit lorsque les réparations sont terminées au début de 2003. Si vous avez traversé à Chau Doc, vous pourriez être en mesure d''obtenir un moteur des 60 kilomètres de Phnom Penh, mais compte tenu de la rivière, il est plus facile de faire une promenade à moteur court au village du Mékong K''am Samnar, où vous pouvez obtenir un bateau au nord de Neak Leung (3h), 37 km à l''est de Phnom Penh et reliée à la capitale en bus et en taxi collectif.<br /><br />Note que les Cambodgiens et les Vietnamiens ne sont autorisés à franchir est de Kep, malgré les assurances contraires de la part du consulat vietnamien Sihanoukvill.<br />Cambodge-Vietnam passage de la frontière:<br />Point Bavet Vérifiez international (province de Svay Rieng)<br />Sam Orm Kha ne Check Point International (province de Kandal)<br />Koh Rohka Check Point International (province de Prey Veng)<br />Banteay Chakrey Check Point International (Province Preyveng)<br />Tropeang Point Sre Vérifiez international (province de Kratie)<br />Chak Prek Check Point International (province de Kampot)<br />Den Phnom Check Point International (province de Takeo)<br />Point Oyadav Vérifiez international (Province Rattankiri)<br />Tropieng Phlong Check Point International (Kampong Cham Province)<br /><br /><br /><strong><span style="text-decoration: underline;">LAOS</span></strong><br /><br />Aviation de Laos et Vietnam Airlines des vols quotidiens de Vientiane à Phnom Penh, avec des arrêts à Siem Reap, le mardi et le vendredi, parfois il ya aussi un arrêt imprévu à Paksé.<br /><br />Les voyageurs aventureux voudront peut-être essayer le passage entre Voeng Kham par bateau ou par Dong Khon (Parkse) par voie terrestre, et la ville cambodgienne de Stung Treng. Visa peut être obtenu à Dong Krolar points de contrôle frontaliers - côté Cambodge avec FEEE de 20USD. Cela prendra environ 6 à 7 heures pour atteindre ville de Phnom Penh en bus ou en taxi.<br />Cambodge-Laos passage de la frontière:<br />Dong Point Krolar Vérifiez international (Steung Treng Province)<br />Tropieng Point Kreal Vérifiez international (province de Stung Treng)<br /><br />New! Click the words above to view alternate translations. Dismiss</p>\r\n<p> </p>', '239ff61ce422fc826b5e088708502e23', '', '2011-04-24 12:39:28', 62, 1),
(125, 2, 9, 'content', 'title', 'Horaires et le dollar', 'e5aa1c1db12fb83842358f7df7e6ba53', '', '2011-04-24 12:23:29', 62, 1),
(126, 2, 9, 'content', 'alias', 'horaires-et-le-dollar', '2f9d4f1634f7354d17ebc577cae91fc4', '', '2011-04-24 12:23:29', 62, 1),
(127, 2, 9, 'content', 'introtext', '<p style="text-align: justify;"><strong>Heure locale</strong><br /><br />Cambodge tourne à 7 heures GMT, le même fuseau horaire que la Thaïlande, le Vietnam et le Laos.<br /><br /><br /><strong>Monnaie cambodgienne</strong><br /><br />Dollars des États-Unis sont aussi couramment utilisé comme Riel cambodgien et même baht thaï est acceptable dans de nombreux endroits. La plupart des hôtels et de nombreux restaurants et boutiques de fixer leurs prix en dollars. Les petites transactions sont habituellement fait dans Riel. Ayez toujours Riel petit pour motos-taxis, des collations, des mendiants et autres petits achats.<br /><br />Riel notes viennent dans 50, 100, 200, 500, 1000, 5000, 10.000, 50.000 et 100.000 confessions, mais le rouge distinctive 500 Note Riel est le plus couramment utilisé.<br />S''il vous plaît cliquez ici pour le taux de change avec votre propre monnaie.<br /><br />Les cartes de crédit et chèques de voyage ne ​​sont pas communs, mais sont sur la capture. Les voyageurs américains dollar contrôles sont beaucoup plus facilement encaissés que tout autre genre.<br /><br />L''argent des changeurs cluster autour des marchés. En acceptant de l''argent, d''inspecter les projets de loi. Riel est entaché d''appel d''offres acceptables, mais la plus petite déchirure dans une grande rend la note des Etats-Unis sans valeur.<br /><br />Il ya des banques dans toutes les grandes capitales provinciales, y compris Phnom Penh, Siem Reap, Sihanoukville, Battambang. Les banques peuvent changer de l''argent, effectuer des virements télégraphiques et certaines banques peuvent encaisser des chèques de voyage et d''accepter les cartes Visa.<br /><br />Il ya seulement deux ATM au Cambodge, à la Banque Canadia à Phnom Penh et ANZ Royal Bank à Phnom Penh, et vous devez avoir un compte local dans le but de l''utiliser. Vous ne pouvez pas accéder à des comptes étrangers de cette situation.<br /><br />New! Click the words above to view alternate translations. Dismiss</p>\r\n<p style="text-align: justify;"> </p>', '859f450758e526fd3a778c5232a8dc32', '', '2011-04-24 12:23:29', 62, 1),
(128, 2, 9, 'content', 'fulltext', '', '73ab2901aabe278ba8cd7e5486267588', '', '2011-04-24 12:23:29', 62, 1),
(130, 2, 20, 'categories', 'title', 'Guide de Voyage', '5e39933c7a40620afaa6a2863f2c4952', '', '2011-04-11 05:59:30', 62, 0),
(131, 2, 20, 'categories', 'alias', 'guide-de-voyage', '16d572f3541c786131f44972f068bdea', '', '2011-04-11 05:59:30', 62, 0),
(132, 2, 45, 'modules', 'title', 'Visiteurs Vinaora CounterTravel Guide', '330f21f3042be32ef5dac2e3cb672fb0', '', '2011-04-11 06:07:00', 62, 1),
(133, 2, 45, 'modules', 'params', 'moduleclass_sfx=\nmode=custom\ninitialvalue=0\ndigit_type=embwhite\nnumber_digits=5\nstats_type=checkout\nwidthtable=90\ntoday=Aujourd''hui\nyesterday=Hier\nweek=Cette semaine\nlweek=La semaine dernière,\nmonth=Ce mois-ci\nlmonth=Le mois dernier\nall=Tous les jours\nautohide=0\nhrline=1\nbeginday=\nonline=Nous avons\nguestip=Votre adresse IP\nguestinfo=Oui\nformattime=% b% d,% Y: Aujourd''hui\nissunday=1\ncache_time=15\npretext=\nposttext=\n\n', '9573a89f2a7547797b44dce080918ed6', '', '2011-04-11 06:07:00', 62, 1),
(134, 2, 43, 'modules', 'title', 'Rechercher', '13348442cc6a27032d2b4aa28b75a5d3', '', '2011-04-11 06:08:03', 62, 1),
(135, 2, 43, 'modules', 'params', 'moduleclass_sfx=\nwidth=60\ntext=Rechercher\nbutton=1\nbutton_pos=right\nimagebutton=\nbutton_text=Rechercher\nset_itemid=\ncache=1\ncache_time=900\n\n', '2eb72cc1a7c51f47ba62d19537d51ae9', '', '2011-04-11 06:08:03', 62, 1),
(136, 2, 26, 'modules', 'title', 'Les photos du Cambodge', '9896c813599bb0a4f80437b5300fcf27', '', '2011-04-11 06:09:18', 62, 1),
(137, 2, 26, 'modules', 'params', 'slider_source=0\nslider_type=0\nmootools=0\nlink_image=2\nimage_folder=images/image_slide/\nlink=\nshow_title=1\nshow_desc=1\nshow_readmore=1\nlink_title=1\nlink_desc=0\nlimit_desc=\nimage_width=80\nimage_height=80\nfit_to=2\nvisible_images=8\nspace_between_images=1\nmax_images=20\nsort_by=1\neffect=Circ\nautoplay=1\nshow_buttons=0\nshow_arrows=0\nshow_custom_nav=0\ndesc_width=\ndesc_bottom=0\ndesc_horizontal=0\nleft_arrow=\nright_arrow=\nplay_button=\npause_button=\narrows_top=30\narrows_horizontal=5\neffect_type=easeOut\nduration=\ndelay=\npreload=800\nmoduleclass_sfx=\ncache=0\n\n', '3cc86cc5b9a11c89943b462a20dd6d60', '', '2011-04-11 06:09:18', 62, 1),
(129, 2, 9, 'content', 'attribs', 'created_by=62\ncreated_by_alias=\naccess=0\ncreated=\npublish_up=\npublish_down=\nshow_title=0\nlink_titles=0\nshow_intro=0\nshow_section=0\nlink_section=0\nshow_category=0\nlink_category=0\nshow_vote=0\nshow_author=0\nshow_create_date=0\nshow_modify_date=0\nshow_pdf_icon=0\nshow_print_icon=1\nshow_email_icon=1\nlanguage=en-GB\nkeyref=Horaires et le dollar\nreadmore=Time and Currency\n\n', '47142694ee49aa28f2a127d461f162c6', '', '2011-04-24 12:23:29', 62, 1),
(138, 2, 36, 'modules', 'title', 'curseur', '10bf08f0bbd6689475be65b4ae441bd9', '', '2011-04-11 06:14:30', 62, 1),
(139, 2, 36, 'modules', 'params', 'lveisWidth=870\nulHeight=350\nlveisFloat=none\nuseNav=1\nnavHeight=20\nnextbutton=1\nprevbutton=1\nlveisindex=1\neffectFx=all\ntimeout=4000\nspeed=1000\npause=1\nrandom=0\nimageFolder=images/image_slide/\nstretchImages=1\nuselinks=1\nlinktarget=_self\nuseModalbox=1\ntransparentBgColor=0\nlveis_bgcolor=FFFFFF\nlveisnav_bgcolor=000000\nlveisnav_bordercolor=000000\nlveisnav_a=888888\nlveisnav_ahover=FFFFFF\nlveisnav_aborder=282828\nlveisnav_aact=FFFFFF\nlveisnav_aactbg=222222\nlveisnav_aactborder=111111\nuseCompression=1\nimageCentered=1\nslider_id=3\nmoduleclass_sfx=\ncache=1\ncache_time=900\n\n', '313f96c66dabb2092607acd25628ff29', '', '2011-04-11 06:14:30', 62, 1),
(124, 2, 10, 'content', 'attribs', 'created_by=62\ncreated_by_alias=\naccess=0\ncreated=\npublish_up=\npublish_down=\nshow_title=0\nlink_titles=0\nshow_intro=0\nshow_section=0\nlink_section=0\nshow_category=0\nlink_category=0\nshow_vote=0\nshow_author=0\nshow_create_date=0\nshow_modify_date=0\nshow_pdf_icon=0\nshow_print_icon=1\nshow_email_icon=1\nlanguage=fr-FR\nkeyref=\nreadmore=Prenez Sortez\n\n', '2760b54faaddfa594895004cff980f0c', '', '2011-04-24 12:39:28', 62, 1),
(140, 2, 14, 'content', 'title', 'visa-et-de-passeport', 'b891b28d083fe1d345e1e79a34be1878', '', '2011-04-24 12:41:36', 62, 1),
(141, 2, 14, 'content', 'alias', 'visa-et-de-passeport', 'cca1b5bfd0989b2a0300c71082f7478f', '', '2011-04-24 12:41:36', 62, 1),
(142, 2, 14, 'content', 'introtext', '<p>Taxe d''aéroport (redevances de services passagers)<br />Pour Voyage International<br />Foreigner:<br />Adulte 25 $ US<br />Moins de 12 ans 13 $ US<br />Moins de 2 ans GRATUIT<br /><br />Cambodge:<br />Adulte 18 $ US<br />Moins de 12 ans de 10 US $<br />Moins de 2 ans GRATUIT<br /><br />Pour Voyage intérieur<br />Foreigner:<br />Adultes 6 $ US<br /><br />Cambodge:<br />Adulte 5 $ US<br />Les points d''entrée pour obtenir un visa<br /><br />Aéroports:<br />L''aéroport de Phnom Penh International<br />Siem Reap International Airport<br /><br />la frontière Cambodge-Vietnam:<br /><br />Point Bavet Vérifiez international (province de Svay Rieng)<br /><br />Sam Orm Kha ne Check Point International (province de Kandal)<br /><br />Koh Rohka Check Point International (province de Prey Veng)<br /><br />Banteay Chakrey Check Point International (Province Preyveng)<br /><br />Tropeang Point Sre Vérifiez international (province de Kratie)<br /><br />Chak Prek Check Point International (province de Kampot)<br /><br />Den Phnom Check Point International (province de Takeo)<br /><br />Point Oyadav Vérifiez international (Province Rattankiri)<br /><br />Tropieng Phlong Check Point International (Kampong Cham Province)<br />la frontière Cambodge-Thaïlande:<br /><br />Yeam Cham Check Point International (province de Koh Kong)<br /><br />Poi Pet Check Point International (province de Banteay Meanchey)<br /><br />Point Osmach Vérifiez international (Province Meanchey odeur)<br /><br />Point Sihanoukville Vérifiez international (province de Sihanoukville)<br /><br />Sanguam Choam Check Point International (province de Banteay Meanchey)<br /><br />Point Prum Vérifiez international (Province de Pailin)<br /><br />Point Doung Vérifiez international (province de Battambang)<br /><br />Preah Vihear Check Point International (province de Preah Vihear)<br />frontière entre le Cambodge et le Laos:<br /><br />Dong Point Krolar Vérifiez international (Steung Treng Province)<br /><br />Tropieng Point Kreal Vérifiez international (province de Stung Treng)<br /><br />Demande de visas et frais<br />Il est nécessaire pour les demandeurs de visa à présenter de passeport, les formulaires de demande, une photo couleur récente de type passeport, et les autres documents tels que déterminés par le statut de séjour.<br /><br />Simple frais de visa d''entrée pour les touristes: 20 $ US<br /><br />Simple frais de visa d''entrée pour les entreprises: 25 $ US<br /><br /><br />Visa Type<br />Les visas de tourisme et d''affaires:<br />Les visiteurs en provenance de pays ne relevant pas d''exemption de visa accords doivent demander un visa d''affaires ou touristes valable pour un mois au niveau des points d''entrée.<br />Siem Reap International Airport<br /><br />K Visa:<br />Visa K peut être délivré à un national cambodgien entrer dans le Royaume sur un passeport étranger. (Le demandeur doit fournir des preuves bien documentées, comme la preuve que ses parents ont été cambodgienne).<br /><br />Exemption de visa:<br />Les ressortissants des Philippines et la Malaisie n''ont pas besoin d''un visa touristique et peut rester au Cambodge pour les 21 et 30 jours respectivement.<br /><br />Prolongation de visa<br />Les visas de tourisme et d''affaires:<br />Le touriste (T) et d''affaires (E) les visas peuvent être prolongés au ministère de l''Immigration, de la police nationale. La diplomatique (A), officiel (B) et de courtoisie (C) visas peuvent être prolongés au Département consulaire du ministère des Affaires étrangères. Un visa touristique peut être prolongée une seule fois pour un maximum de un mois (à entrée unique)<br /><br />Un visa d''affaires peut être reconduite pour:<br /><br />Un mois (entrée simple)<br /><br />Trois mois (entrées multiples)<br /><br />Six mois (entrées multiples)<br /><br />Un an (entrées multiples)<br /><br />Or ces personnes sera condamné à une amende de 5 $ US par jour.<br /><br />New! Click the words above to view alternate translations. Dismiss</p>', '9774f117a38ccead303f2747af4c8f47', '', '2011-04-24 12:41:36', 62, 1),
(143, 2, 14, 'content', 'fulltext', '', 'd41d8cd98f00b204e9800998ecf8427e', '', '2011-04-24 12:41:36', 62, 1),
(144, 2, 14, 'content', 'attribs', 'created_by=62\ncreated_by_alias=\naccess=0\ncreated=\npublish_up=\npublish_down=\nshow_title=0\nlink_titles=0\nshow_intro=0\nshow_section=0\nlink_section=0\nshow_category=0\nlink_category=0\nshow_vote=0\nshow_author=0\nshow_create_date=0\nshow_modify_date=0\nshow_pdf_icon=0\nshow_print_icon=1\nshow_email_icon=1\nlanguage=fr-FR\nkeyref=\nreadmore=Visa and Passport\n\n', '2da3d7b8f4fbcc73031ede20edbfaaa8', '', '2011-04-24 12:41:36', 62, 1),
(145, 2, 47, 'menu', 'name', 'Guide de Voyage', '5e39933c7a40620afaa6a2863f2c4952', '', '2011-04-21 03:32:48', 62, 0),
(146, 2, 47, 'menu', 'alias', 'voyage-guide', '16d572f3541c786131f44972f068bdea', '', '2011-04-21 03:32:48', 62, 0),
(147, 2, 47, 'menu', 'params', 'page_title=\nshow_page_title=1\npageclass_sfx=\nmenu_image=-1\nsecure=0\ntitle=\nimage=\ncontact=\ntelefon=\ncurrency=\nother=$\nfeeder=\nhotel_select=\nhotel=\nquestion=\narb_pdf=-1\npolicy_pdf=-1\n\n', 'a2d63cb1a640a4eb0260e244457679d8', '', '2011-04-21 03:32:48', 62, 0),
(148, 2, 47, 'menu', 'link', 'index.php?option=com_travelbook&view=travelbook&layout=travelbook', '69a1e38e3fdb2cd259e0403851a6ae3b', '', '2011-04-21 03:32:48', 62, 0),
(149, 2, 47, 'menu', 'name', 'Guide de Voyage', '5e39933c7a40620afaa6a2863f2c4952', '', '2011-04-21 03:34:24', 62, 1),
(150, 2, 47, 'menu', 'alias', 'voyage-guide', '16d572f3541c786131f44972f068bdea', '', '2011-04-21 03:34:24', 62, 1),
(151, 2, 47, 'menu', 'params', 'page_title=\nshow_page_title=1\npageclass_sfx=\nmenu_image=-1\nsecure=0\ntitle=\nimage=\ncontact=\ntelefon=\ncurrency=\nother=$\nfeeder=\nhotel_select=\nhotel=\nquestion=\narb_pdf=-1\npolicy_pdf=-1\n\n', 'a2d63cb1a640a4eb0260e244457679d8', '', '2011-04-21 03:34:24', 62, 1),
(152, 2, 47, 'menu', 'link', 'index.php?option=com_travelbook&view=travelbook&layout=travelbook', '69a1e38e3fdb2cd259e0403851a6ae3b', '', '2011-04-21 03:34:24', 62, 1),
(153, 2, 23, 'menu', 'name', 'Sur le Cambodge', '69248bd10365f7ba7127cab0ac4ef906', '', '2011-04-21 03:37:29', 62, 1),
(154, 2, 23, 'menu', 'alias', 'sur-le-cambodge', '287676a0d2bb9be6ca13cce276431c81', '', '2011-04-21 03:37:29', 62, 1),
(155, 2, 23, 'menu', 'params', 'page_title=\nshow_page_title=1\npageclass_sfx=\nmenu_image=-1\nsecure=0\nshow_noauth=0\nshow_title=0\nlink_titles=0\nshow_intro=0\nshow_section=0\nlink_section=0\nshow_category=0\nlink_category=0\nshow_author=0\nshow_create_date=0\nshow_modify_date=0\nshow_item_navigation=0\nshow_readmore=0\nshow_vote=0\nshow_icons=0\nshow_pdf_icon=0\nshow_print_icon=0\nshow_email_icon=0\nshow_hits=0\nfeed_summary=\n\n', 'cf6935fe58369fbb329ea3faff6063df', '', '2011-04-21 03:37:29', 62, 1);
INSERT INTO `jos_jf_content` (`id`, `language_id`, `reference_id`, `reference_table`, `reference_field`, `value`, `original_value`, `original_text`, `modified`, `modified_by`, `published`) VALUES
(156, 2, 23, 'menu', 'link', 'index.php?option=com_content&view=article&id=5', '9032ec55e40ba78164eac98de35f42b0', '', '2011-04-21 03:37:29', 62, 1),
(157, 2, 61, 'menu', 'name', 'Réservation', '0421bbd72ecdf96591342458b0d6905d', '', '2011-04-21 03:38:31', 62, 1),
(158, 2, 61, 'menu', 'alias', 'reservation', '5c8438bef7c60cf62b4a0aee3b0becc4', '', '2011-04-21 03:38:31', 62, 1),
(159, 2, 61, 'menu', 'params', 'page_title=\nshow_page_title=1\npageclass_sfx=\nmenu_image=-1\nsecure=0\ntitle=\nimage=\ncontact=\ntelefon=\ncurrency=\nother=$\nfeeder=\nhotel_select=\nhotel=\nquestion=\narb_pdf=-1\npolicy_pdf=-1\n\n', 'a2d63cb1a640a4eb0260e244457679d8', '', '2011-04-21 03:38:31', 62, 1),
(160, 2, 61, 'menu', 'link', 'index.php?option=com_travelbook&view=travelbook&layout=travelbook', '69a1e38e3fdb2cd259e0403851a6ae3b', '', '2011-04-21 03:38:31', 62, 1),
(161, 2, 51, 'menu', 'name', 'Climat et Wealther', 'dd9cc0589107c5fbeb44c5dae2f57d0c', '', '2011-04-21 03:39:37', 62, 1),
(162, 2, 51, 'menu', 'alias', 'climat-et-wealther', 'b2d73462ba69a5e77445ccb6641b3cff', '', '2011-04-21 03:39:37', 62, 1),
(163, 2, 51, 'menu', 'params', 'page_title=\nshow_page_title=1\npageclass_sfx=\nmenu_image=-1\nsecure=0\nshow_noauth=\nshow_title=\nlink_titles=\nshow_intro=\nshow_section=\nlink_section=\nshow_category=\nlink_category=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_item_navigation=\nshow_readmore=\nshow_vote=\nshow_icons=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nshow_hits=\nfeed_summary=\n\n', '5abdcb8e4a1b658293691263ef4674d4', '', '2011-04-21 03:39:37', 62, 1),
(164, 2, 51, 'menu', 'link', 'index.php?option=com_content&view=article&id=11', 'bfd78a28168dad7cbf0e314b7dc20e01', '', '2011-04-21 03:39:37', 62, 1),
(165, 2, 26, 'menu', 'name', 'Ambassade à l''étranger', '27a0f4f9c6db06be2c0ff328a7028052', '', '2011-04-21 03:43:22', 62, 1),
(166, 2, 26, 'menu', 'alias', 'ambassade-a-letranger', '79bbbc512a30791a39ed90e1a3ed4787', '', '2011-04-21 03:43:22', 62, 1),
(167, 2, 26, 'menu', 'params', 'page_title=\nshow_page_title=1\npageclass_sfx=\nmenu_image=-1\nsecure=0\nshow_noauth=\nshow_title=\nlink_titles=\nshow_intro=\nshow_section=\nlink_section=\nshow_category=\nlink_category=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_item_navigation=\nshow_readmore=\nshow_vote=\nshow_icons=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nshow_hits=\nfeed_summary=\n\n', '5abdcb8e4a1b658293691263ef4674d4', '', '2011-04-21 03:43:22', 62, 1),
(168, 2, 26, 'menu', 'link', 'index.php?option=com_content&view=article&id=8', 'e5cec327aee120b9c3dde9aea0e5de92', '', '2011-04-21 03:43:22', 62, 1),
(169, 2, 54, 'menu', 'name', 'Ambassade à l''étranger', '27a0f4f9c6db06be2c0ff328a7028052', '', '2011-04-21 03:44:11', 62, 1),
(170, 2, 54, 'menu', 'alias', 'ambassade-a-letranger', '79bbbc512a30791a39ed90e1a3ed4787', '', '2011-04-21 03:44:11', 62, 1),
(171, 2, 54, 'menu', 'params', 'page_title=\nshow_page_title=1\npageclass_sfx=\nmenu_image=-1\nsecure=0\nshow_noauth=\nshow_title=\nlink_titles=\nshow_intro=\nshow_section=\nlink_section=\nshow_category=\nlink_category=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_item_navigation=\nshow_readmore=\nshow_vote=\nshow_icons=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nshow_hits=\nfeed_summary=\n\n', '5abdcb8e4a1b658293691263ef4674d4', '', '2011-04-21 03:44:11', 62, 1),
(172, 2, 54, 'menu', 'link', 'index.php?option=com_content&view=article&id=8', 'e5cec327aee120b9c3dde9aea0e5de92', '', '2011-04-21 03:44:11', 62, 1),
(173, 2, 52, 'menu', 'name', 'Obtenez et sortir', '5efe30b3d8b0d5ef75bbbcada505475c', '', '2011-04-21 03:46:24', 62, 1),
(174, 2, 52, 'menu', 'alias', 'obtenez-et-sortir', '5c8fe4bfe027be250e79e44e7a21d151', '', '2011-04-21 03:46:24', 62, 1),
(175, 2, 52, 'menu', 'params', 'page_title=\nshow_page_title=1\npageclass_sfx=\nmenu_image=-1\nsecure=0\nshow_noauth=\nshow_title=\nlink_titles=\nshow_intro=\nshow_section=\nlink_section=\nshow_category=\nlink_category=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_item_navigation=\nshow_readmore=\nshow_vote=\nshow_icons=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nshow_hits=\nfeed_summary=\n\n', '5abdcb8e4a1b658293691263ef4674d4', '', '2011-04-21 03:46:24', 62, 1),
(176, 2, 52, 'menu', 'link', 'index.php?option=com_content&view=article&id=10', '31a904aa57ad4b2f1c3f595065260128', '', '2011-04-21 03:46:24', 62, 1),
(177, 2, 31, 'menu', 'name', 'Santé et conseils', 'cf9b818b7317bc6576ebdfd93934e7bc', '', '2011-04-21 03:47:37', 62, 1),
(178, 2, 31, 'menu', 'alias', 'sante-et-conseils', 'c822c89e68639543e85ae5006381a8d6', '', '2011-04-21 03:47:37', 62, 1),
(179, 2, 31, 'menu', 'params', 'page_title=\nshow_page_title=1\npageclass_sfx=\nmenu_image=-1\nsecure=0\nshow_noauth=\nshow_title=\nlink_titles=\nshow_intro=\nshow_section=\nlink_section=\nshow_category=\nlink_category=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_item_navigation=\nshow_readmore=\nshow_vote=\nshow_icons=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nshow_hits=\nfeed_summary=\n\n', '5abdcb8e4a1b658293691263ef4674d4', '', '2011-04-21 03:47:37', 62, 1),
(180, 2, 31, 'menu', 'link', 'index.php?option=com_content&view=article&id=12', '19dbdc122956b81f53d06f365bc792e5', '', '2011-04-21 03:47:37', 62, 1),
(181, 2, 30, 'menu', 'name', 'En savoir Khmer', 'd02383d10e8d803cb42c5b8c0efed13c', '', '2011-04-21 03:49:03', 62, 1),
(182, 2, 30, 'menu', 'alias', 'en-savoir-khmer', 'c0e5673fc7ad04e2bbe2a3796998ae77', '', '2011-04-21 03:49:03', 62, 1),
(183, 2, 30, 'menu', 'params', 'page_title=\nshow_page_title=1\npageclass_sfx=\nmenu_image=-1\nsecure=0\nshow_noauth=\nshow_title=\nlink_titles=\nshow_intro=\nshow_section=\nlink_section=\nshow_category=\nlink_category=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_item_navigation=\nshow_readmore=\nshow_vote=\nshow_icons=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nshow_hits=\nfeed_summary=\n\n', '5abdcb8e4a1b658293691263ef4674d4', '', '2011-04-21 03:49:03', 62, 1),
(184, 2, 30, 'menu', 'link', 'index.php?option=com_content&view=article&id=13', 'f8e328b9f9110c6fbe6831373b552291', '', '2011-04-21 03:49:03', 62, 1),
(185, 2, 49, 'menu', 'name', 'En savoir Khmer', 'd02383d10e8d803cb42c5b8c0efed13c', '', '2011-04-21 03:50:12', 62, 1),
(186, 2, 49, 'menu', 'alias', 'en-savoir-khmer', 'c0e5673fc7ad04e2bbe2a3796998ae77', '', '2011-04-21 03:50:12', 62, 1),
(187, 2, 49, 'menu', 'params', 'page_title=\nshow_page_title=1\npageclass_sfx=\nmenu_image=-1\nsecure=0\nshow_noauth=\nshow_title=\nlink_titles=\nshow_intro=\nshow_section=\nlink_section=\nshow_category=\nlink_category=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_item_navigation=\nshow_readmore=\nshow_vote=\nshow_icons=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nshow_hits=\nfeed_summary=\n\n', '5abdcb8e4a1b658293691263ef4674d4', '', '2011-04-21 03:50:12', 62, 1),
(188, 2, 49, 'menu', 'link', 'index.php?option=com_content&view=article&id=13', 'f8e328b9f9110c6fbe6831373b552291', '', '2011-04-21 03:50:12', 62, 1),
(189, 2, 27, 'menu', 'name', 'Horaires et le dollar', 'e5aa1c1db12fb83842358f7df7e6ba53', '', '2011-04-21 03:51:44', 62, 1),
(190, 2, 27, 'menu', 'alias', 'horaires-et-le-dollar', '2f9d4f1634f7354d17ebc577cae91fc4', '', '2011-04-21 03:51:44', 62, 1),
(191, 2, 27, 'menu', 'params', 'page_title=\nshow_page_title=1\npageclass_sfx=\nmenu_image=-1\nsecure=0\nshow_noauth=\nshow_title=\nlink_titles=\nshow_intro=\nshow_section=\nlink_section=\nshow_category=\nlink_category=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_item_navigation=\nshow_readmore=\nshow_vote=\nshow_icons=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nshow_hits=\nfeed_summary=\n\n', '5abdcb8e4a1b658293691263ef4674d4', '', '2011-04-21 03:51:44', 62, 1),
(192, 2, 27, 'menu', 'link', 'index.php?option=com_content&view=article&id=9', '798b95dfcbda690106c8ccbcb7a1d0be', '', '2011-04-21 03:51:44', 62, 1),
(193, 2, 53, 'menu', 'name', 'Horaires et le dollar', 'e5aa1c1db12fb83842358f7df7e6ba53', '', '2011-04-21 03:52:58', 62, 1),
(194, 2, 53, 'menu', 'alias', 'horaires-et-le-dollar', '2f9d4f1634f7354d17ebc577cae91fc4', '', '2011-04-21 03:52:58', 62, 1),
(195, 2, 53, 'menu', 'params', 'page_title=\nshow_page_title=1\npageclass_sfx=\nmenu_image=-1\nsecure=0\nshow_noauth=\nshow_title=\nlink_titles=\nshow_intro=\nshow_section=\nlink_section=\nshow_category=\nlink_category=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_item_navigation=\nshow_readmore=\nshow_vote=\nshow_icons=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nshow_hits=\nfeed_summary=\n\n', '5abdcb8e4a1b658293691263ef4674d4', '', '2011-04-21 03:52:58', 62, 1),
(196, 2, 53, 'menu', 'link', 'index.php?option=com_content&view=article&id=9', '798b95dfcbda690106c8ccbcb7a1d0be', '', '2011-04-21 03:52:58', 62, 1),
(197, 2, 48, 'menu', 'name', 'Visa et passeport', 'b891b28d083fe1d345e1e79a34be1878', '', '2011-04-21 08:56:01', 62, 1),
(198, 2, 48, 'menu', 'alias', 'visa-et-passeport', 'b2d73462ba69a5e77445ccb6641b3cff', '', '2011-04-21 08:56:01', 62, 1),
(199, 2, 48, 'menu', 'params', 'page_title=\nshow_page_title=1\npageclass_sfx=\nmenu_image=-1\nsecure=0\nshow_noauth=\nshow_title=\nlink_titles=\nshow_intro=\nshow_section=\nlink_section=\nshow_category=\nlink_category=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_item_navigation=\nshow_readmore=\nshow_vote=\nshow_icons=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nshow_hits=\nfeed_summary=\n\n', '5abdcb8e4a1b658293691263ef4674d4', '', '2011-04-21 08:56:01', 62, 1),
(200, 2, 48, 'menu', 'link', 'index.php?option=com_content&view=article&id=14', '5b3dbcbece275fe2da1dc601756fc32b', '', '2011-04-21 08:56:01', 62, 1),
(201, 2, 50, 'menu', 'name', 'Santé et conseils', 'cf9b818b7317bc6576ebdfd93934e7bc', '', '2011-04-21 09:03:00', 62, 1),
(202, 2, 50, 'menu', 'alias', 'sante-et-conseils', 'c822c89e68639543e85ae5006381a8d6', '', '2011-04-21 09:03:00', 62, 1),
(203, 2, 50, 'menu', 'params', 'page_title=\nshow_page_title=1\npageclass_sfx=\nmenu_image=-1\nsecure=0\nshow_noauth=\nshow_title=\nlink_titles=\nshow_intro=\nshow_section=\nlink_section=\nshow_category=\nlink_category=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_item_navigation=\nshow_readmore=\nshow_vote=\nshow_icons=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nshow_hits=\nfeed_summary=\n\n', '5abdcb8e4a1b658293691263ef4674d4', '', '2011-04-21 09:03:00', 62, 1),
(204, 2, 50, 'menu', 'link', 'index.php?option=com_content&view=article&id=12', '19dbdc122956b81f53d06f365bc792e5', '', '2011-04-21 09:03:00', 62, 1),
(205, 2, 13, 'content', 'introtext', '<p><span id="result_box" lang="fr"><span class="hps" title="Click for alternate translations">La</span> <span class="hps" title="Click for alternate translations">langue</span> <span class="hps" title="Click for alternate translations">cambodgienne</span> <span class="hps" title="Click for alternate translations">est le khmer</span><span title="Click for alternate translations">,</span> <span class="hps" title="Click for alternate translations">qui est</span> <span class="hps" title="Click for alternate translations">héritée</span> <span class="hps" title="Click for alternate translations">elle-même</span> <span class="hps" title="Click for alternate translations">-</span> <span class="hps" title="Click for alternate translations">et</span> <span class="hps" title="Click for alternate translations">avancées</span> <span class="hps" title="Click for alternate translations">en matière d''éducation</span> <span class="hps" title="Click for alternate translations">avec l''application des</span> <span class="hps" title="Click for alternate translations">langues</span> <span class="hps" title="Click for alternate translations">indo-aryennes</span> <span class="hps" title="Click for alternate translations">Pali</span> <span class="hps" title="Click for alternate translations">et</span> <span class="hps" title="Click for alternate translations">Sangkrit</span> <span class="hps" title="Click for alternate translations">de</span> <span class="hps" title="Click for alternate translations">l''Inde</span><span title="Click for alternate translations">.</span> <span class="hps" title="Click for alternate translations">En outre</span><span title="Click for alternate translations">,</span> <span class="hps" title="Click for alternate translations">la langue</span> <span class="hps" title="Click for alternate translations">khmère</span> <span class="hps" title="Click for alternate translations">est influencée</span> <span class="hps" title="Click for alternate translations">par</span> <span class="hps" title="Click for alternate translations">écrit et parlé</span> <span class="hps" title="Click for alternate translations">Thai</span><span title="Click for alternate translations">.</span> <span class="hps" title="Click for alternate translations">Certains</span> <span class="hps" title="Click for alternate translations">langages techniques</span> <span class="hps" title="Click for alternate translations">sont</span> <span class="hps" title="Click for alternate translations">empruntés</span> <span class="hps" title="Click for alternate translations">du français</span><span title="Click for alternate translations">.</span> <span class="hps" title="Click for alternate translations">Cependant</span><span title="Click for alternate translations">,</span> <span class="hps" title="Click for alternate translations">l''anglais</span> <span class="hps" title="Click for alternate translations">est</span> <span class="hps" title="Click for alternate translations">couramment</span> <span class="hps" title="Click for alternate translations">communiqués</span> <span class="hps" title="Click for alternate translations">dans</span> <span class="hps" title="Click for alternate translations">les hôtels</span> <span class="hps" title="Click for alternate translations">et</span> <span class="hps" title="Click for alternate translations">les composés</span> <span class="hps" title="Click for alternate translations">d''affaires</span> <span class="hps" title="Click for alternate translations">à</span> <span class="hps" title="Click for alternate translations">nos jours</span><span title="Click for alternate translations">.</span><br /><br /><span class="hps" title="Click for alternate translations">En savoir</span> <span class="hps" title="Click for alternate translations">khmer:</span><br /><span class="hps" title="Click for alternate translations">Voici</span> <span class="hps" title="Click for alternate translations">quelques</span> <span class="hps" title="Click for alternate translations">mots</span> <span class="hps" title="Click for alternate translations">et phrases</span> <span class="hps" title="Click for alternate translations">utiles</span> <span class="hps" title="Click for alternate translations">Khmer</span><span title="Click for alternate translations">,</span> <span class="hps" title="Click for alternate translations">écrit phonétiquement</span><span title="Click for alternate translations">,</span> <span class="hps" title="Click for alternate translations">qui</span> <span class="hps" title="Click for alternate translations">vous sera utile</span><span title="Click for alternate translations">.</span> <span class="hps" title="Click for alternate translations">Khmer</span> <span class="hps" title="Click for alternate translations">peut sembler</span> <span class="hps" title="Click for alternate translations">déroutant</span><span title="Click for alternate translations">.</span> <span class="hps" title="Click for alternate translations">Mais</span> <span class="hps" title="Click for alternate translations">avec</span> <span class="hps" title="Click for alternate translations">un peu de patience</span> <span class="hps" title="Click for alternate translations">et de</span> <span class="hps" title="Click for alternate translations">pratique</span><span title="Click for alternate translations">,</span> <span class="hps" title="Click for alternate translations">vous pouvez</span> <span class="hps" title="Click for alternate translations">obtenir en</span><span title="Click for alternate translations">.</span><br /><br /><span class="hps" title="Click for alternate translations">Il ya</span> <span class="hps" title="Click for alternate translations">33</span> <span class="hps" title="Click for alternate translations">consonnes</span> <span class="hps" title="Click for alternate translations">et</span> <span class="hps" title="Click for alternate translations">26</span> <span class="hps" title="Click for alternate translations">voyelles</span><span title="Click for alternate translations">.</span> <span class="hps atn" title="Click for alternate translations">"</span><span title="Click for alternate translations">Ai</span><span title="Click for alternate translations">"se prononce</span> <span class="hps" title="Click for alternate translations">comme</span> <span class="hps" title="Click for alternate translations">en</span> <span class="hps" title="Click for alternate translations">thaï</span><span title="Click for alternate translations">;</span> <span class="hps atn" title="Click for alternate translations">«</span><span title="Click for alternate translations">ay</span><span title="Click for alternate translations">»</span> <span class="hps" title="Click for alternate translations">que de la rémunération</span><span title="Click for alternate translations">;</span> <span class="hps" title="Click for alternate translations">"dt</span><span title="Click for alternate translations">"</span> <span class="hps" title="Click for alternate translations">prend</span> <span class="hps" title="Click for alternate translations">tout</span> <span class="hps" title="Click for alternate translations">son</span> <span class="hps" title="Click for alternate translations">t</span> <span class="hps atn" title="Click for alternate translations">"</span><span title="Click for alternate translations">pb</span><span title="Click for alternate translations">"</span> <span class="hps" title="Click for alternate translations">prend le</span> <span class="hps" title="Click for alternate translations">son</span> <span class="hps" title="Click for alternate translations">p</span><span title="Click for alternate translations">.</span> <span class="hps atn" title="Click for alternate translations">"</span><span title="Click for alternate translations">Oo</span><span title="Click for alternate translations">"</span> <span class="hps" title="Click for alternate translations">se prononce comme dans</span> <span class="hps" title="Click for alternate translations">la cuisine et</span> <span class="hps atn" title="Click for alternate translations">"</span><span title="Click for alternate translations">ao</span><span title="Click for alternate translations">"</span> <span class="hps" title="Click for alternate translations">au Laos</span><span title="Click for alternate translations">.</span></span></p>', 'd1b05b3c18d056ba2ac7854ed8bea0cc', '', '2011-04-21 09:12:26', 62, 1),
(206, 2, 13, 'content', 'fulltext', '', 'd41d8cd98f00b204e9800998ecf8427e', '', '2011-04-21 09:12:26', 62, 1),
(207, 2, 13, 'content', 'attribs', 'created_by=62\ncreated_by_alias=\naccess=0\ncreated=\npublish_up=\npublish_down=\nshow_title=0\nlink_titles=0\nshow_intro=0\nshow_section=0\nlink_section=0\nshow_category=0\nlink_category=0\nshow_vote=0\nshow_author=0\nshow_create_date=0\nshow_modify_date=0\nshow_pdf_icon=0\nshow_print_icon=0\nshow_email_icon=0\nlanguage=\nkeyref=\nreadmore=Learn Khmer\n\n', '1864e92e3f342d47fb81fa9743be233f', '', '2011-04-21 09:12:26', 62, 1),
(208, 2, 13, 'content', 'introtext', '<p align="justify"><span id="result_box" lang="fr"><span class="hps" title="Click for alternate translations">La</span> <span class="hps" title="Click for alternate translations">langue</span> <span class="hps" title="Click for alternate translations">cambodgienne</span> <span class="hps" title="Click for alternate translations">est le khmer</span><span title="Click for alternate translations">,</span> <span class="hps" title="Click for alternate translations">qui est</span> <span class="hps" title="Click for alternate translations">héritée</span> <span class="hps" title="Click for alternate translations">elle-même</span> <span class="hps" title="Click for alternate translations">-</span> <span class="hps" title="Click for alternate translations">et</span> <span class="hps" title="Click for alternate translations">avancées</span> <span class="hps" title="Click for alternate translations">en matière d''éducation</span> <span class="hps" title="Click for alternate translations">avec l''application des</span> <span class="hps" title="Click for alternate translations">langues</span> <span class="hps" title="Click for alternate translations">indo-aryennes</span> <span class="hps" title="Click for alternate translations">Pali</span> <span class="hps" title="Click for alternate translations">et</span> <span class="hps" title="Click for alternate translations">Sangkrit</span> <span class="hps" title="Click for alternate translations">de</span> <span class="hps" title="Click for alternate translations">l''Inde</span><span title="Click for alternate translations">.</span> <span class="hps" title="Click for alternate translations">En outre</span><span title="Click for alternate translations">,</span> <span class="hps" title="Click for alternate translations">la langue</span> <span class="hps" title="Click for alternate translations">khmère</span> <span class="hps" title="Click for alternate translations">est influencée</span> <span class="hps" title="Click for alternate translations">par</span> <span class="hps" title="Click for alternate translations">écrit et parlé</span> <span class="hps" title="Click for alternate translations">Thai</span><span title="Click for alternate translations">.</span> <span class="hps" title="Click for alternate translations">Certains</span> <span class="hps" title="Click for alternate translations">langages techniques</span> <span class="hps" title="Click for alternate translations">sont</span> <span class="hps" title="Click for alternate translations">empruntés</span> <span class="hps" title="Click for alternate translations">du français</span><span title="Click for alternate translations">.</span> <span class="hps" title="Click for alternate translations">Cependant</span><span title="Click for alternate translations">,</span> <span class="hps" title="Click for alternate translations">l''anglais</span> <span class="hps" title="Click for alternate translations">est</span> <span class="hps" title="Click for alternate translations">couramment</span> <span class="hps" title="Click for alternate translations">communiqués</span> <span class="hps" title="Click for alternate translations">dans</span> <span class="hps" title="Click for alternate translations">les hôtels</span> <span class="hps" title="Click for alternate translations">et</span> <span class="hps" title="Click for alternate translations">les composés</span> <span class="hps" title="Click for alternate translations">d''affaires</span> <span class="hps" title="Click for alternate translations">à</span> <span class="hps" title="Click for alternate translations">nos jours</span><span title="Click for alternate translations">.</span><br /><br /><span class="hps" title="Click for alternate translations">En savoir</span> <span class="hps" title="Click for alternate translations">khmer:</span><br /><span class="hps" title="Click for alternate translations">Voici</span> <span class="hps" title="Click for alternate translations">quelques</span> <span class="hps" title="Click for alternate translations">mots</span> <span class="hps" title="Click for alternate translations">et phrases</span> <span class="hps" title="Click for alternate translations">utiles</span> <span class="hps" title="Click for alternate translations">Khmer</span><span title="Click for alternate translations">,</span> <span class="hps" title="Click for alternate translations">écrit phonétiquement</span><span title="Click for alternate translations">,</span> <span class="hps" title="Click for alternate translations">qui</span> <span class="hps" title="Click for alternate translations">vous sera utile</span><span title="Click for alternate translations">.</span> <span class="hps" title="Click for alternate translations">Khmer</span> <span class="hps" title="Click for alternate translations">peut sembler</span> <span class="hps" title="Click for alternate translations">déroutant</span><span title="Click for alternate translations">.</span> <span class="hps" title="Click for alternate translations">Mais</span> <span class="hps" title="Click for alternate translations">avec</span> <span class="hps" title="Click for alternate translations">un peu de patience</span> <span class="hps" title="Click for alternate translations">et de</span> <span class="hps" title="Click for alternate translations">pratique</span><span title="Click for alternate translations">,</span> <span class="hps" title="Click for alternate translations">vous pouvez</span> <span class="hps" title="Click for alternate translations">obtenir en</span><span title="Click for alternate translations">.</span><br /><br /><span class="hps" title="Click for alternate translations">Il ya</span> <span class="hps" title="Click for alternate translations">33</span> <span class="hps" title="Click for alternate translations">consonnes</span> <span class="hps" title="Click for alternate translations">et</span> <span class="hps" title="Click for alternate translations">26</span> <span class="hps" title="Click for alternate translations">voyelles</span><span title="Click for alternate translations">.</span> <span class="hps atn" title="Click for alternate translations">"</span><span title="Click for alternate translations">Ai"se prononce</span> <span class="hps" title="Click for alternate translations">comme</span> <span class="hps" title="Click for alternate translations">en</span> <span class="hps" title="Click for alternate translations">thaï</span><span title="Click for alternate translations">;</span> <span class="hps atn" title="Click for alternate translations">«</span><span title="Click for alternate translations">ay»</span> <span class="hps" title="Click for alternate translations">que de la rémunération</span><span title="Click for alternate translations">;</span> <span class="hps" title="Click for alternate translations">"dt</span><span title="Click for alternate translations">"</span> <span class="hps" title="Click for alternate translations">prend</span> <span class="hps" title="Click for alternate translations">tout</span> <span class="hps" title="Click for alternate translations">son</span> <span class="hps" title="Click for alternate translations">t</span> <span class="hps atn" title="Click for alternate translations">"</span><span title="Click for alternate translations">pb"</span> <span class="hps" title="Click for alternate translations">prend le</span> <span class="hps" title="Click for alternate translations">son</span> <span class="hps" title="Click for alternate translations">p</span><span title="Click for alternate translations">.</span> <span class="hps atn" title="Click for alternate translations">"</span><span title="Click for alternate translations">Oo"</span> <span class="hps" title="Click for alternate translations">se prononce comme dans</span> <span class="hps" title="Click for alternate translations">la cuisine et</span> <span class="hps atn" title="Click for alternate translations">"</span><span title="Click for alternate translations">ao"</span> <span class="hps" title="Click for alternate translations">au Laos</span><span title="Click for alternate translations">.</span></span></p>\r\n<p><span lang="fr"><span title="Click for alternate translations"> </span></span></p>\r\n<table border="0" cellspacing="1" cellpadding="10" width="100%">\r\n<tbody>\r\n<tr>\r\n<td>\r\n<p style="margin-top: 0px; margin-bottom: 0px; text-align: left;"><strong>French </strong></p>\r\n<p style="margin-top: 0; margin-bottom: 0"> </p>\r\n<p style="margin-top: 0; margin-bottom: 0"><span id="result_box" lang="fr"><span class="hps" title="Click for alternate translations">Bonjour</span><br /></span><span lang="fr"><br /><span class="hps" title="Click for alternate translations">Comment</span> <span class="hps" title="Click for alternate translations">êtes-vous</span><span title="Click for alternate translations">?</span><br /><br /><span class="hps" title="Click for alternate translations">Bonjour</span><br /><br /><span class="hps" title="Click for alternate translations">Bonne nuit</span><br /><br /><span class="hps" title="Click for alternate translations">Après-midi</span><br /><br /><span class="hps" title="Click for alternate translations">Mon nom</span> <span class="hps" title="Click for alternate translations">est</span> <span class="hps" title="Click for alternate translations">...</span> <span class="hps" title="Click for alternate translations">..</span><br /><br /><span class="hps" title="Click for alternate translations">Oui</span><br /><br /><span class="hps" title="Click for alternate translations">N</span><br /><br /><span class="hps" title="Click for alternate translations">S''il vous plaît</span><br /><br /><span class="hps" title="Click for alternate translations">Je vous remercie</span><br /><br /><span class="hps" title="Click for alternate translations">Excusez</span><span title="Click for alternate translations">-moi</span><br /><br /><span class="hps" title="Click for alternate translations">Au revoir</span><br /><br /><span class="hps" title="Click for alternate translations">Je ne</span> <span class="hps" title="Click for alternate translations">comprends pas</span><br /><br /><span class="hps" title="Click for alternate translations">Je veux un</span> <span class="hps" title="Click for alternate translations">...</span><br /><br /><span class="hps" title="Click for alternate translations">L''eau</span><br /><br /><span class="hps" title="Click for alternate translations">Thé</span><br /><br /><span class="hps" title="Click for alternate translations">Riz</span> <span class="hps atn" title="Click for alternate translations">(</span><span title="Click for alternate translations">cuit)</span><br /><br /><span class="hps" title="Click for alternate translations">Rice</span> <span class="hps atn" title="Click for alternate translations">(</span><span title="Click for alternate translations">non cuits)</span><br /><br /><span class="hps" title="Click for alternate translations">Viande</span><br /><br /><span class="hps" title="Click for alternate translations">Fish</span><br /><br /><span class="hps" title="Click for alternate translations">Poulet</span><br /><br /><span class="hps" title="Click for alternate translations">Pain</span><br /><br /><span class="hps" title="Click for alternate translations">Restaurant</span><br /><br /><span class="hps" title="Click for alternate translations">Où est ...</span><span title="Click for alternate translations">?</span><br /><br /><span class="hps" title="Click for alternate translations">Marché</span><br /><br /><span class="hps" title="Click for alternate translations">Banque</span><br /><br /><span class="hps" title="Click for alternate translations">Post</span> <span class="hps" title="Click for alternate translations">Office</span><br /><br /><span class="hps" title="Click for alternate translations">Docteur</span><br /><br /><span class="hps" title="Click for alternate translations">Bus</span><br /><br /><span class="hps" title="Click for alternate translations">Train</span><br /><br /><span class="hps" title="Click for alternate translations">Cycle</span><br /><br /><span class="hps" title="Click for alternate translations">Policier</span><br /><br /><span class="hps" title="Click for alternate translations">Tourner à</span> <span class="hps" title="Click for alternate translations">gauche</span><br /><br /><span class="hps" title="Click for alternate translations">Tourner</span> <span class="hps" title="Click for alternate translations">à droite</span><br /><br /><span class="hps" title="Click for alternate translations">Allez</span> <span class="hps" title="Click for alternate translations">tout droit</span><br /><br /><span class="hps" title="Click for alternate translations">Matin</span><br /><br /><span class="hps" title="Click for alternate translations">Midnight</span><br /><br /><span class="hps" title="Click for alternate translations">Nuit</span><br /><br /><span class="hps" title="Click for alternate translations">Dimanche</span><br /><br /><span class="hps" title="Click for alternate translations">Lundi</span><br /><br /><span class="hps" title="Click for alternate translations">Mardi</span><br /><br /><span class="hps" title="Click for alternate translations">Mercredi</span><br /><br /><span class="hps" title="Click for alternate translations">Jeudi</span><br /><br /><span class="hps" title="Click for alternate translations">Vendredi</span><br /><br /><span class="hps" title="Click for alternate translations">Samedi</span></span></p>\r\n<p style="margin-top: 0; margin-bottom: 0"> </p>\r\n</td>\r\n<td>\r\n<p style="margin-top: 0px; margin-bottom: 0px; text-align: left;"><strong>Khmer </strong></p>\r\n<p style="margin-top: 0; margin-bottom: 0"> </p>\r\n<p style="margin-top: 0; margin-bottom: 0">jum-reap soo-a</p>\r\n<p style="margin-top: 0; margin-bottom: 0"> </p>\r\n<p style="margin-top: 0; margin-bottom: 0">tau neak sok sapbaiy teh?</p>\r\n<p style="margin-top: 0; margin-bottom: 0"> </p>\r\n<p style="margin-top: 0; margin-bottom: 0">arun sour sdei</p>\r\n<p style="margin-top: 0; margin-bottom: 0"> </p>\r\n<p style="margin-top: 0; margin-bottom: 0">tiveah sour sdei</p>\r\n<p style="margin-top: 0; margin-bottom: 0"> </p>\r\n<p style="margin-top: 0; margin-bottom: 0">reah-trey sour sdei</p>\r\n<p style="margin-top: 0; margin-bottom: 0"> </p>\r\n<p style="margin-top: 0; margin-bottom: 0">k’nyom tchmouh…</p>\r\n<p style="margin-top: 0; margin-bottom: 0"> </p>\r\n<p style="margin-top: 0; margin-bottom: 0">baat</p>\r\n<p style="margin-top: 0; margin-bottom: 0"> </p>\r\n<p style="margin-top: 0; margin-bottom: 0">dteh</p>\r\n<p style="margin-top: 0; margin-bottom: 0"> </p>\r\n<p style="margin-top: 0; margin-bottom: 0">suom mehta</p>\r\n<p style="margin-top: 0; margin-bottom: 0"> </p>\r\n<p style="margin-top: 0; margin-bottom: 0">or-koon</p>\r\n<p style="margin-top: 0; margin-bottom: 0"> </p>\r\n<p style="margin-top: 0; margin-bottom: 0">sohm dtoh</p>\r\n<p style="margin-top: 0; margin-bottom: 0"> </p>\r\n<p style="margin-top: 0; margin-bottom: 0">joom-reap leah</p>\r\n<p style="margin-top: 0; margin-bottom: 0"> </p>\r\n<p style="margin-top: 0; margin-bottom: 0">k’nyom men yoo-ul tee</p>\r\n<p style="margin-top: 0; margin-bottom: 0"> </p>\r\n<p style="margin-top: 0; margin-bottom: 0">k’nyom jang baan…</p>\r\n<p style="margin-top: 0; margin-bottom: 0"> </p>\r\n<p style="margin-top: 0; margin-bottom: 0">teuk</p>\r\n<p style="margin-top: 0; margin-bottom: 0"> </p>\r\n<p style="margin-top: 0; margin-bottom: 0">tai</p>\r\n<p style="margin-top: 0; margin-bottom: 0"> </p>\r\n<p style="margin-top: 0; margin-bottom: 0">bia</p>\r\n<p style="margin-top: 0; margin-bottom: 0"> </p>\r\n<p style="margin-top: 0; margin-bottom: 0">angkoh</p>\r\n<p style="margin-top: 0; margin-bottom: 0"> </p>\r\n<p style="margin-top: 0; margin-bottom: 0">saich</p>\r\n<p style="margin-top: 0; margin-bottom: 0"> </p>\r\n<p style="margin-top: 0; margin-bottom: 0">t’ray</p>\r\n<p style="margin-top: 0; margin-bottom: 0"> </p>\r\n<p style="margin-top: 0; margin-bottom: 0">moan</p>\r\n<p style="margin-top: 0; margin-bottom: 0"> </p>\r\n<p style="margin-top: 0; margin-bottom: 0">num pung</p>\r\n<p style="margin-top: 0; margin-bottom: 0"> </p>\r\n<p style="margin-top: 0; margin-bottom: 0">haang bai</p>\r\n<p style="margin-top: 0; margin-bottom: 0"> </p>\r\n<p style="margin-top: 0; margin-bottom: 0">noev eah nah…?</p>\r\n<p style="margin-top: 0; margin-bottom: 0"> </p>\r\n<p style="margin-top: 0; margin-bottom: 0">p’sah</p>\r\n<p style="margin-top: 0; margin-bottom: 0"> </p>\r\n<p style="margin-top: 0; margin-bottom: 0">tho neea kear</p>\r\n<p style="margin-top: 0; margin-bottom: 0"> </p>\r\n<p style="margin-top: 0; margin-bottom: 0">bprai sa nee</p>\r\n<p style="margin-top: 0; margin-bottom: 0"> </p>\r\n<p style="margin-top: 0; margin-bottom: 0">peth</p>\r\n<p style="margin-top: 0; margin-bottom: 0"> </p>\r\n<p style="margin-top: 0; margin-bottom: 0">laan ch’noul</p>\r\n<p style="margin-top: 0; margin-bottom: 0"> </p>\r\n<p style="margin-top: 0; margin-bottom: 0">ra dteah plerng</p>\r\n<p style="margin-top: 0; margin-bottom: 0"> </p>\r\n<p style="margin-top: 0; margin-bottom: 0">see kloa</p>\r\n<p style="margin-top: 0; margin-bottom: 0"> </p>\r\n<p style="margin-top: 0; margin-bottom: 0">bpoa leeh or norkor-bahl</p>\r\n<p style="margin-top: 0; margin-bottom: 0"> </p>\r\n<p style="margin-top: 0; margin-bottom: 0">bot dtoy ch’wayng</p>\r\n<p style="margin-top: 0; margin-bottom: 0"> </p>\r\n<p style="margin-top: 0; margin-bottom: 0">bot dtoy s’dum</p>\r\n<p style="margin-top: 0; margin-bottom: 0"> </p>\r\n<p style="margin-top: 0; margin-bottom: 0">dtov dtrong</p>\r\n<p style="margin-top: 0; margin-bottom: 0"> </p>\r\n<p style="margin-top: 0; margin-bottom: 0">bpreuk</p>\r\n<p style="margin-top: 0; margin-bottom: 0"> </p>\r\n<p style="margin-top: 0; margin-bottom: 0">aa-tree-at</p>\r\n<p style="margin-top: 0; margin-bottom: 0"> </p>\r\n<p style="margin-top: 0; margin-bottom: 0">yoop</p>\r\n<p style="margin-top: 0; margin-bottom: 0"> </p>\r\n<p style="margin-top: 0; margin-bottom: 0">t/ngai aa-dteut</p>\r\n<p style="margin-top: 0; margin-bottom: 0"> </p>\r\n<p style="margin-top: 0; margin-bottom: 0">t’ngai jan</p>\r\n<p style="margin-top: 0; margin-bottom: 0"> </p>\r\n<p style="margin-top: 0; margin-bottom: 0">t’ngai ong-gee-a</p>\r\n<p style="margin-top: 0; margin-bottom: 0"> </p>\r\n<p style="margin-top: 0; margin-bottom: 0">t’ngai bpoot</p>\r\n<p style="margin-top: 0; margin-bottom: 0"> </p>\r\n<p style="margin-top: 0; margin-bottom: 0">t’ngai bpra-hoa-a</p>\r\n<p style="margin-top: 0; margin-bottom: 0"> </p>\r\n<p style="margin-top: 0; margin-bottom: 0">t’ngai sok</p>\r\n<p style="margin-top: 0; margin-bottom: 0"> </p>\r\n<p style="margin-top: 0; margin-bottom: 0">t’ngai sao</p>\r\n<p style="margin-top: 0; margin-bottom: 0"> </p>\r\n</td>\r\n<td align="left">\r\n<p style="margin-top: 0px; margin-bottom: 0px; text-align: left;"><strong>French</strong></p>\r\n<p style="margin-top: 0; margin-bottom: 0"> </p>\r\n<p style="margin-top: 0; margin-bottom: 0"><span id="result_box" lang="fr"><span class="hps" title="Click for alternate translations">Hier</span><br /><br /><span class="hps" title="Click for alternate translations">Aujourd''hui</span><br /><br /><span class="hps" title="Click for alternate translations">Demain</span><br /><br /><span class="hps" title="Click for alternate translations">Mois</span><br /><br /><span class="hps" title="Click for alternate translations">Année</span><br /><br /><span class="hps" title="Click for alternate translations">L''année dernière</span><br /><br /><span class="hps" title="Click for alternate translations">Nouvel An</span><br /><br /><span class="hps" title="Click for alternate translations">Année suivante</span><br /><br /><span class="hps" title="Click for alternate translations">Janvier</span><br /><br /><span class="hps" title="Click for alternate translations">Février</span><br /><br /><span class="hps" title="Click for alternate translations">Mars</span><br /><br /><span class="hps" title="Click for alternate translations">Avril</span><br /><br /><span class="hps" title="Click for alternate translations">Mai</span><br /><br /><span class="hps" title="Click for alternate translations">Juin</span><br /><br /><span class="hps" title="Click for alternate translations">Juillet</span><br /><br /><span class="hps" title="Click for alternate translations">Août</span><br /><br /><span class="hps" title="Click for alternate translations">Septembre</span><br /><br /><span class="hps" title="Click for alternate translations">Octobre</span><br /><br /><span class="hps" title="Click for alternate translations">Novembre</span><br /><br /><span class="hps" title="Click for alternate translations">Décembre</span><br /><br /><span class="hps" title="Click for alternate translations">Une</span><br /><br /><span class="hps" title="Click for alternate translations">Deux</span><br /><br /><span class="hps" title="Click for alternate translations">Trois</span><br /><br /><span class="hps" title="Click for alternate translations">Quatre</span><br /><br /><span class="hps" title="Click for alternate translations">Cinq</span><br /><br /><span class="hps" title="Click for alternate translations">Six</span><br /><br /><span class="hps" title="Click for alternate translations">Sept</span><br /><br /><span class="hps" title="Click for alternate translations">Huit</span><br /><br /><span class="hps" title="Click for alternate translations">Nuit</span><br /><br /><span class="hps" title="Click for alternate translations">Dix</span><br /><br /><span class="hps" title="Click for alternate translations">Onze</span><br /><br /><span class="hps" title="Click for alternate translations">Vingt</span><br /><br /><span class="hps" title="Click for alternate translations">Trente</span><br /><br /><span class="hps" title="Click for alternate translations">Quarante</span><br /><br /><span class="hps" title="Click for alternate translations">Cinquante</span><br /><br /><span class="hps" title="Click for alternate translations">Soixante</span><br /><br /><span class="hps" title="Click for alternate translations">Soixante</span><br /><br /><span class="hps" title="Click for alternate translations">Quatre-vingts</span><br /><br /><span class="hps" title="Click for alternate translations">Quatre-vingt dix</span><br /><br /><span class="hps" title="Click for alternate translations">Cent</span><br /><br /><span class="hps" title="Click for alternate translations">Mille</span><br /><br /><span class="hps" title="Click for alternate translations">Dix</span> <span class="hps" title="Click for alternate translations">mille</span><br /><br /><span class="hps" title="Click for alternate translations">Cent</span> <span class="hps" title="Click for alternate translations">mille</span><br /><br /><span class="hps" title="Click for alternate translations">Million</span></span></p>\r\n<p style="margin-top: 0; margin-bottom: 0"> </p>\r\n<p style="margin-top: 0; margin-bottom: 0"> </p>\r\n<p style="margin-top: 0; margin-bottom: 0"> </p>\r\n</td>\r\n<td align="left">\r\n<p style="margin-top: 0px; margin-bottom: 0px; text-align: left;"><strong>Khmer </strong></p>\r\n<p style="margin-top: 0; margin-bottom: 0"> </p>\r\n<p style="margin-top: 0; margin-bottom: 0">m’serl menh</p>\r\n<p style="margin-top: 0; margin-bottom: 0"> </p>\r\n<p style="margin-top: 0; margin-bottom: 0">t’ngai nih</p>\r\n<p style="margin-top: 0; margin-bottom: 0"> </p>\r\n<p style="margin-top: 0; margin-bottom: 0">t’ngai sa-aik</p>\r\n<p style="margin-top: 0; margin-bottom: 0"> </p>\r\n<p style="margin-top: 0; margin-bottom: 0">khaeh</p>\r\n<p style="margin-top: 0; margin-bottom: 0"> </p>\r\n<p style="margin-top: 0; margin-bottom: 0">ch’nam</p>\r\n<p style="margin-top: 0; margin-bottom: 0"> </p>\r\n<p style="margin-top: 0; margin-bottom: 0">ch’nam moon</p>\r\n<p style="margin-top: 0; margin-bottom: 0"> </p>\r\n<p style="margin-top: 0; margin-bottom: 0">ch’nam thmey</p>\r\n<p style="margin-top: 0; margin-bottom: 0"> </p>\r\n<p style="margin-top: 0; margin-bottom: 0">ch’nam groy</p>\r\n<p style="margin-top: 0; margin-bottom: 0"> </p>\r\n<p style="margin-top: 0; margin-bottom: 0">ma ga raa</p>\r\n<p style="margin-top: 0; margin-bottom: 0"> </p>\r\n<p style="margin-top: 0; margin-bottom: 0">kompheak</p>\r\n<p style="margin-top: 0; margin-bottom: 0"> </p>\r\n<p style="margin-top: 0; margin-bottom: 0">mee nah</p>\r\n<p style="margin-top: 0; margin-bottom: 0"> </p>\r\n<p style="margin-top: 0; margin-bottom: 0">meh sah</p>\r\n<p style="margin-top: 0; margin-bottom: 0"> </p>\r\n<p style="margin-top: 0; margin-bottom: 0">oo sa phea</p>\r\n<p style="margin-top: 0; margin-bottom: 0"> </p>\r\n<p style="margin-top: 0; margin-bottom: 0">mi thok nah</p>\r\n<p style="margin-top: 0; margin-bottom: 0"> </p>\r\n<p style="margin-top: 0; margin-bottom: 0">ka kada</p>\r\n<p style="margin-top: 0; margin-bottom: 0"> </p>\r\n<p style="margin-top: 0; margin-bottom: 0">say haa</p>\r\n<p style="margin-top: 0; margin-bottom: 0"> </p>\r\n<p style="margin-top: 0; margin-bottom: 0">kan’ya</p>\r\n<p style="margin-top: 0; margin-bottom: 0"> </p>\r\n<p style="margin-top: 0; margin-bottom: 0">to laa</p>\r\n<p style="margin-top: 0; margin-bottom: 0"> </p>\r\n<p style="margin-top: 0; margin-bottom: 0">wech a gaa</p>\r\n<p style="margin-top: 0; margin-bottom: 0"> </p>\r\n<p style="margin-top: 0; margin-bottom: 0">t’noo</p>\r\n<p style="margin-top: 0; margin-bottom: 0"> </p>\r\n<p style="margin-top: 0; margin-bottom: 0">moo ay</p>\r\n<p style="margin-top: 0; margin-bottom: 0"> </p>\r\n<p style="margin-top: 0; margin-bottom: 0">bpee</p>\r\n<p style="margin-top: 0; margin-bottom: 0"> </p>\r\n<p style="margin-top: 0; margin-bottom: 0">bay</p>\r\n<p style="margin-top: 0; margin-bottom: 0"> </p>\r\n<p style="margin-top: 0; margin-bottom: 0">boun</p>\r\n<p style="margin-top: 0; margin-bottom: 0"> </p>\r\n<p style="margin-top: 0; margin-bottom: 0">bpram</p>\r\n<p style="margin-top: 0; margin-bottom: 0"> </p>\r\n<p style="margin-top: 0; margin-bottom: 0">bpram moo ay</p>\r\n<p style="margin-top: 0; margin-bottom: 0"> </p>\r\n<p style="margin-top: 0; margin-bottom: 0">bpram bpee</p>\r\n<p style="margin-top: 0; margin-bottom: 0"> </p>\r\n<p style="margin-top: 0; margin-bottom: 0">bpram bay</p>\r\n<p style="margin-top: 0; margin-bottom: 0"> </p>\r\n<p style="margin-top: 0; margin-bottom: 0">bpram buon</p>\r\n<p style="margin-top: 0; margin-bottom: 0"> </p>\r\n<p style="margin-top: 0; margin-bottom: 0">dahp</p>\r\n<p style="margin-top: 0; margin-bottom: 0"> </p>\r\n<p style="margin-top: 0; margin-bottom: 0">dahp moo ay</p>\r\n<p style="margin-top: 0; margin-bottom: 0"> </p>\r\n<p style="margin-top: 0; margin-bottom: 0">m’pay</p>\r\n<p style="margin-top: 0; margin-bottom: 0"> </p>\r\n<p style="margin-top: 0; margin-bottom: 0">saam seup</p>\r\n<p style="margin-top: 0; margin-bottom: 0"> </p>\r\n<p style="margin-top: 0; margin-bottom: 0">sai seup</p>\r\n<p style="margin-top: 0; margin-bottom: 0"> </p>\r\n<p style="margin-top: 0; margin-bottom: 0">ha seup</p>\r\n<p style="margin-top: 0; margin-bottom: 0"> </p>\r\n<p style="margin-top: 0; margin-bottom: 0">hok seup</p>\r\n<p style="margin-top: 0; margin-bottom: 0"> </p>\r\n<p style="margin-top: 0; margin-bottom: 0">jeht seup</p>\r\n<p style="margin-top: 0; margin-bottom: 0"> </p>\r\n<p style="margin-top: 0; margin-bottom: 0">bpait seup</p>\r\n<p style="margin-top: 0; margin-bottom: 0"> </p>\r\n<p style="margin-top: 0; margin-bottom: 0">gao seup</p>\r\n<p style="margin-top: 0; margin-bottom: 0"> </p>\r\n<p style="margin-top: 0; margin-bottom: 0">moo-ay roy</p>\r\n<p style="margin-top: 0; margin-bottom: 0"> </p>\r\n<p style="margin-top: 0; margin-bottom: 0">moo-aybpoan</p>\r\n<p style="margin-top: 0; margin-bottom: 0"> </p>\r\n<p style="margin-top: 0; margin-bottom: 0">moo-ay meun</p>\r\n<p style="margin-top: 0; margin-bottom: 0"> </p>\r\n<p style="margin-top: 0; margin-bottom: 0">moo-ay sain</p>\r\n<p style="margin-top: 0; margin-bottom: 0"> </p>\r\n<p style="margin-top: 0; margin-bottom: 0">moo-ay lee-un</p>\r\n<p style="margin-top: 0; margin-bottom: 0"> </p>\r\n<p style="margin-top: 0; margin-bottom: 0"> </p>\r\n<p style="margin-top: 0; margin-bottom: 0"> </p>\r\n</td>\r\n</tr>\r\n</tbody>\r\n</table>', '758130819e164c65f4332ec68be7c3d0', '', '2011-04-24 12:38:54', 62, 1),
(209, 2, 13, 'content', 'fulltext', '', 'd41d8cd98f00b204e9800998ecf8427e', '', '2011-04-24 12:38:54', 62, 1),
(210, 2, 13, 'content', 'attribs', 'created_by=62\ncreated_by_alias=\naccess=0\ncreated=\npublish_up=\npublish_down=\nshow_title=1\nlink_titles=0\nshow_intro=0\nshow_section=0\nlink_section=0\nshow_category=0\nlink_category=0\nshow_vote=0\nshow_author=0\nshow_create_date=0\nshow_modify_date=0\nshow_pdf_icon=0\nshow_print_icon=1\nshow_email_icon=1\nlanguage=fr-FR\nkeyref=\nreadmore=Learn Khmer\n\n', '642d749c656379e2e8089529f2e0c7b2', '', '2011-04-24 12:38:54', 62, 1),
(211, 2, 13, 'content', 'title', 'Learn Khmer', 'd02383d10e8d803cb42c5b8c0efed13c', '', '2011-04-24 12:38:54', 62, 1),
(212, 2, 13, 'content', 'alias', 'learn-khmer', 'c0e5673fc7ad04e2bbe2a3796998ae77', '', '2011-04-24 12:38:54', 62, 1);
INSERT INTO `jos_jf_content` (`id`, `language_id`, `reference_id`, `reference_table`, `reference_field`, `value`, `original_value`, `original_text`, `modified`, `modified_by`, `published`) VALUES
(213, 2, 12, 'content', 'introtext', '<p> </p>\r\n<div id="gt-res-content" class="almost_half_cell" style="display: block;">\r\n<div style="text-align: justify;" dir="ltr"><span id="result_box" class="long_text"><span style="background-color: #fff;" title="Drink lots of water." onmouseover="this.style.backgroundColor=''#ebeff9''" onmouseout="this.style.backgroundColor=''#fff''">Buvez beaucoup d''eau. </span><span style="background-color: #fff;" title="Never drink tap water purified, bottled water is available everywhere." onmouseover="this.style.backgroundColor=''#ebeff9''" onmouseout="this.style.backgroundColor=''#fff''">Ne buvez jamais l''eau du robinet  purifiée, l''eau en bouteille est disponible partout. <br /></span><span style="background-color: #fff;" title="Use an insect repellent against mosquitoes." onmouseover="this.style.backgroundColor=''#ebeff9''" onmouseout="this.style.backgroundColor=''#fff''">Utilisez un insectifuge contre  les moustiques. </span><span style="background-color: #fff;" title="It is the only way to be sure of protection against mosquito borne diseases." onmouseover="this.style.backgroundColor=''#ebeff9''" onmouseout="this.style.backgroundColor=''#fff''">Il est le seul moyen d''être sûr  de la protection contre les maladies transmises par les moustiques. </span><span title="Since Cambodia has a hot and humid tropical climate, casual and light-weight clothing is best." onmouseover="this.style.backgroundColor=''#ebeff9''" onmouseout="this.style.backgroundColor=''#fff''">Le Cambodge a un climat tropical  chaud et humide, de sport et vêtements légers est la meilleure. </span><span title="Clothing made from natural fibers is the best option." onmouseover="this.style.backgroundColor=''#ebeff9''" onmouseout="this.style.backgroundColor=''#fff''">Vêtements en fibres naturelles  est la meilleure option. </span><span style="background-color: #fff;" title="A jacket might be needed on cool winter evenings or in hotels and restaurants using excessive air-conditioning." onmouseover="this.style.backgroundColor=''#ebeff9''" onmouseout="this.style.backgroundColor=''#fff''">Une veste peut être nécessaire  sur les soirées d''hiver froid ou dans les hôtels et restaurants en utilisant  excessive de l''air conditionné. </span><span style="background-color: #fff;" title="A hat and high-factor sun block is advisable as protection against the hot sun when sightseeing." onmouseover="this.style.backgroundColor=''#ebeff9''" onmouseout="this.style.backgroundColor=''#fff''">Un chapeau et crème solaire à  indice élevé est souhaitable que la protection contre la chaleur du soleil quand  touristiques. <br /><br /></span><span style="background-color: #fff;" title="When visiting temples or pagodas, including those of Angkor Wat, shorts and T-shirts are acceptable." onmouseover="this.style.backgroundColor=''#ebeff9''" onmouseout="this.style.backgroundColor=''#fff''">Lors de la visite des temples ou  des pagodes, y compris ceux d''Angkor Wat, shorts et T-shirts sont acceptables. </span><span title="Shoes are generally removed at the entrance to pagodas." onmouseover="this.style.backgroundColor=''#ebeff9''" onmouseout="this.style.backgroundColor=''#fff''">Les chaussures sont généralement  éliminés à l''entrée de pagodes. </span><span style="background-color: #fff;" title="For visits to the Silver Pagoda, which is within the Royal Palace grounds, visitors are asked to dress more formally." onmouseover="this.style.backgroundColor=''#ebeff9''" onmouseout="this.style.backgroundColor=''#fff''">Pour les visites à la Pagode  d''Argent, qui se situe dans l''enceinte du Palais Royal, les visiteurs sont priés  de s''habiller de façon plus formelle. </span><span style="background-color: #fff;" title="Gentlemen are required to wear long trousers and ladies should wear long trousers or long skirts." onmouseover="this.style.backgroundColor=''#ebeff9''" onmouseout="this.style.backgroundColor=''#fff''">Les hommes doivent porter des  pantalons longs et les dames doivent porter des pantalons longs ou des jupes  longues. <br /><br /></span><span style="background-color: #fff;" title="Standard film, (such as Kodak, FUJI or Konica 100, ), slide and digital camera memory are widely available." onmouseover="this.style.backgroundColor=''#ebeff9''" onmouseout="this.style.backgroundColor=''#fff''">Le film standard, (tels que  Kodak, Fuji ou Konica 100,), de diapositives et de mémoire appareil photo  numérique sont largement disponibles. </span><span title="Photos are inexpensive to process in the country." onmouseover="this.style.backgroundColor=''#ebeff9''" onmouseout="this.style.backgroundColor=''#fff''">Les photos sont peu coûteux à  traiter dans le pays. </span><span title="Any specialized photo equipment should be brought with you." onmouseover="this.style.backgroundColor=''#ebeff9''" onmouseout="this.style.backgroundColor=''#fff''">Tout le matériel photo  spécialisée devrait être apporté avec vous. </span><span title="Photography in airports, railway stations and near any military installations is forbidden and discretion should be used when photographing people, particularly monks." onmouseover="this.style.backgroundColor=''#ebeff9''" onmouseout="this.style.backgroundColor=''#fff''">Droits dans les aéroports, les  gares et à proximité de toutes les installations militaires est interdite et la  discrétion doit être utilisé lorsque vous photographiez des personnes, en  particulier les moines. </span><span title="The cheapest &amp; best quality photo service in Phnom Penh is SPK Photo Studio FUJI Shop at Monivong Blvd." onmouseover="this.style.backgroundColor=''#ebeff9''" onmouseout="this.style.backgroundColor=''#fff''">Le service photo moins cher et la  meilleure qualité à Phnom Penh est SPK Photo Studio FUJI Shop à Monivong Blvd.  <br /><br /><br /></span><span title="HEALTH REQUIREMENTS" onmouseover="this.style.backgroundColor=''#ebeff9''" onmouseout="this.style.backgroundColor=''#fff''"><strong>EXIGENCES DE LA SANTÉ</strong> <br /><br /></span><span title="Although no vaccinations are officially required for entry to Cambodia, they are highly encouraged." onmouseover="this.style.backgroundColor=''#ebeff9''" onmouseout="this.style.backgroundColor=''#fff''">Bien qu''aucune vaccination sont  officiellement requis pour l''entrée au Cambodge, ils sont fortement encouragés. </span><span style="background-color: #fff;" title="Visitors are advised to check with their doctor or a travel immunization clinic regarding protection against malaria, typhoid, tetanus, hepatitis A and B. Any essential medications should be brought with you as there is no guarantee they will be available in Cambodia." onmouseover="this.style.backgroundColor=''#ebeff9''" onmouseout="this.style.backgroundColor=''#fff''">Les visiteurs sont invités à  vérifier avec leur médecin ou une clinique de vaccination Voyage en matière de  protection contre le paludisme, la typhoïde, le tétanos, l''hépatite A et B. Tous  les médicaments essentiels doivent être apportés avec vous car il n''y a aucune  garantie qu''elles seront disponibles au Cambodge.</span></span></div>\r\n</div>\r\n<p> </p>', '96157227b5c2acbba3eb8979689e7f60', '', '2011-04-24 12:44:12', 62, 0),
(214, 2, 12, 'content', 'fulltext', '', 'dbf2629fbead251f6aec6e00cf18045d', '', '2011-04-24 12:44:12', 62, 0),
(215, 2, 12, 'content', 'attribs', 'created_by=62\ncreated_by_alias=\naccess=0\ncreated=\npublish_up=\npublish_down=\nshow_title=0\nlink_titles=0\nshow_intro=0\nshow_section=0\nlink_section=0\nshow_category=0\nlink_category=0\nshow_vote=0\nshow_author=0\nshow_create_date=0\nshow_modify_date=0\nshow_pdf_icon=0\nshow_print_icon=1\nshow_email_icon=1\nlanguage=\nkeyref=\nreadmore=Health and Advice\n\n', 'f69bee574b894334dc9e24565bcf1817', '', '2011-04-24 12:44:12', 62, 0),
(216, 2, 11, 'content', 'introtext', '<p> </p>\r\n<div id="gt-res-content" class="almost_half_cell">\r\n<div style="zoom: 1;" dir="ltr"><span id="result_box" class="long_text" lang="fr"><span class="hps" title="Click for alternate translations">Le  climat</span> <span class="hps" title="Click for alternate translations">peut</span> <span class="hps" title="Click for alternate translations">généralement  être décrit comme</span> <span class="hps" title="Click for alternate translations">tropicales</span><span title="Click for alternate translations">.</span> <span class="hps" title="Click for alternate translations">Comme</span> <span class="hps" title="Click for alternate translations">le pays</span> <span class="hps" title="Click for alternate translations">est affecté</span> <span class="hps" title="Click for alternate translations">par</span> <span class="hps" title="Click for alternate translations">la mousson</span><span title="Click for alternate translations">,</span> <span class="hps" title="Click for alternate translations">il</span> <span class="hps" title="Click for alternate translations">est</span> <span class="hps" title="Click for alternate translations">chaud</span> <span class="hps" title="Click for alternate translations">et</span> <span class="hps" title="Click for alternate translations">humide avec une</span> <span class="hps" title="Click for alternate translations">température</span> <span class="hps" title="Click for alternate translations">autour  de</span> <span class="hps" title="Click for alternate translations">surdosage</span> <span class="hps" title="Click for alternate translations">27.C</span> <span class="hps atn" title="Click for alternate translations">(</span><span title="Click for alternate translations">80.F</span><span title="Click for alternate translations">)</span><span title="Click for alternate translations">.</span> <span class="hps" title="Click for alternate translations">Il  ya</span> <span class="hps" title="Click for alternate translations">deux</span> <span class="hps" title="Click for alternate translations">saisons  distinctes: la</span> <span class="hps" title="Click for alternate translations">saison</span> <span class="hps" title="Click for alternate translations">des  pluies</span> <span class="hps" title="Click for alternate translations">et</span> <span class="hps" title="Click for alternate translations">la saison  sèche</span><span title="Click for alternate translations">.</span> <span class="hps" title="Click for alternate translations">Cependant</span><span title="Click for alternate translations">,</span> <span class="hps" title="Click for alternate translations">la</span> <span class="hps" title="Click for alternate translations">saison  sèche</span> <span class="hps" title="Click for alternate translations">est divisé</span> <span class="hps" title="Click for alternate translations">en</span> <span class="hps" title="Click for alternate translations">deux sous</span><span class="atn" title="Click for alternate translations">-</span><span title="Click for alternate translations">saisons</span><span title="Click for alternate translations">,</span> <span class="hps" title="Click for alternate translations">froid et chaud</span><span title="Click for alternate translations">.</span> <span class="hps" title="Click for alternate translations">Ces</span> <span class="hps" title="Click for alternate translations">saisons</span> <span class="hps" title="Click for alternate translations">sont</span><span title="Click for alternate translations">:</span><br /><br /> <span class="hps" title="Click for alternate translations">La saison  des</span> <span class="hps" title="Click for alternate translations">pluies</span><span title="Click for alternate translations">:</span><br /><br /> <span class="hps" title="Click for alternate translations">De</span> <span class="hps" title="Click for alternate translations">Juin à</span> <span class="hps" title="Click for alternate translations">Octobre</span> <span class="hps atn" title="Click for alternate translations">27-</span><span title="Click for alternate translations">35.C</span> <span class="hps atn" title="Click for alternate translations">(</span><span title="Click for alternate translations">80</span><span class="atn" title="Click for alternate translations">-</span><span title="Click for alternate translations">95.f</span><span title="Click for alternate translations">)</span><br /><br /> <span class="hps" title="Click for alternate translations">La  saison</span> <span class="hps" title="Click for alternate translations">sèche</span> <span class="hps atn" title="Click for alternate translations">(</span><span title="Click for alternate translations">cool</span><span title="Click for alternate translations">)</span><span title="Click for alternate translations">:</span><br /> <span class="hps" title="Click for alternate translations">De</span> <span class="hps" title="Click for alternate translations">Novembre</span> <span class="hps" title="Click for alternate translations">à  Février</span> <span class="hps atn" title="Click for alternate translations">17-</span><span title="Click for alternate translations">27.C</span> <span class="hps atn" title="Click for alternate translations">(</span><span title="Click for alternate translations">80</span> <span class="hps" title="Click for alternate translations">95.F</span><span title="Click for alternate translations">)</span><br /><br /> <span class="hps" title="Click for alternate translations">La  saison</span> <span class="hps" title="Click for alternate translations">sèche</span> <span class="hps atn" title="Click for alternate translations">(</span><span title="Click for alternate translations">à  chaud</span><span title="Click for alternate translations">)</span><span title="Click for alternate translations">:</span><br /> <span class="hps" title="Click for alternate translations">De</span> <span class="hps" title="Click for alternate translations">Mars</span> <span class="hps" title="Click for alternate translations">à Mai</span> <span class="hps atn" title="Click for alternate translations">29-</span><span title="Click for alternate translations">38.C</span> <span class="hps atn" title="Click for alternate translations">(</span><span title="Click for alternate translations">84</span> <span class="hps" title="Click for alternate translations">100.F</span><span title="Click for alternate translations">)</span><br /><br /> <span class="hps" title="Click for alternate translations">S''il vous  plaît</span> <span class="hps" title="Click for alternate translations">cliquez ici</span> <span class="hps" title="Click for alternate translations">pour</span> <span class="hps" title="Click for alternate translations">Météo</span> <span class="hps" title="Click for alternate translations">au  Cambodge</span></span></div>\r\n</div>\r\n<p> </p>', '29b1c496dbcc9fc456ea95840600a40b', '', '2011-04-24 12:45:17', 62, 0),
(217, 2, 11, 'content', 'fulltext', '', '26362ce9921cd9b69aed240914f960d5', '', '2011-04-24 12:45:17', 62, 0),
(218, 2, 11, 'content', 'attribs', 'created_by=62\ncreated_by_alias=\naccess=0\ncreated=\npublish_up=\npublish_down=\nshow_title=0\nlink_titles=0\nshow_intro=0\nshow_section=0\nlink_section=0\nshow_category=0\nlink_category=0\nshow_vote=0\nshow_author=0\nshow_create_date=0\nshow_modify_date=0\nshow_pdf_icon=0\nshow_print_icon=1\nshow_email_icon=1\nlanguage=en-GB\nkeyref=\nreadmore=Climate and Weather\n\n', '77781ec7d2418c15124329fce735b305', '', '2011-04-24 12:45:17', 62, 0);

-- --------------------------------------------------------

--
-- Table structure for table `jos_jf_tableinfo`
--

CREATE TABLE IF NOT EXISTS `jos_jf_tableinfo` (
  `id` int(11) NOT NULL auto_increment,
  `joomlatablename` varchar(100) NOT NULL default '',
  `tablepkID` varchar(100) NOT NULL default '',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3641 ;

--
-- Dumping data for table `jos_jf_tableinfo`
--

INSERT INTO `jos_jf_tableinfo` (`id`, `joomlatablename`, `tablepkID`) VALUES
(3627, 'banner', 'bid'),
(3628, 'bannerclient', 'cid'),
(3629, 'categories', 'id'),
(3630, 'contact_details', 'id'),
(3631, 'content', 'id'),
(3632, 'languages', 'id'),
(3633, 'menu', 'id'),
(3634, 'modules', 'id'),
(3635, 'newsfeeds', 'id'),
(3636, 'poll_data', 'id'),
(3637, 'polls', 'id'),
(3638, 'sections', 'id'),
(3639, 'users', 'id'),
(3640, 'weblinks', 'id');

-- --------------------------------------------------------

--
-- Table structure for table `jos_languages`
--

CREATE TABLE IF NOT EXISTS `jos_languages` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(100) NOT NULL default '',
  `active` tinyint(1) NOT NULL default '0',
  `iso` varchar(20) default NULL,
  `code` varchar(20) NOT NULL default '',
  `shortcode` varchar(20) default NULL,
  `image` varchar(100) default NULL,
  `fallback_code` varchar(20) NOT NULL default '',
  `params` text NOT NULL,
  `ordering` int(11) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `jos_languages`
--

INSERT INTO `jos_languages` (`id`, `name`, `active`, `iso`, `code`, `shortcode`, `image`, `fallback_code`, `params`, `ordering`) VALUES
(1, 'English', 1, 'en_GB.utf8, en_GB.UT', 'en-GB', 'en', '', '', '', 1),
(2, 'French', 1, 'fr_FR.utf8, fr_FR.UT', 'fr-FR', 'fr', '', '', '', 0),
(5, 'Khmer (Cambodia)', 0, 'km_KH.utf8, km_KH.UT', 'km-KH', 'km', '', '', '', 0),
(4, 'English (United States)', 0, 'en_US.utf8, en_US.UT', 'en-US', 'en', '', '', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `jos_menu`
--

CREATE TABLE IF NOT EXISTS `jos_menu` (
  `id` int(11) NOT NULL auto_increment,
  `menutype` varchar(75) default NULL,
  `name` varchar(255) default NULL,
  `alias` varchar(255) NOT NULL default '',
  `link` text,
  `type` varchar(50) NOT NULL default '',
  `published` tinyint(1) NOT NULL default '0',
  `parent` int(11) unsigned NOT NULL default '0',
  `componentid` int(11) unsigned NOT NULL default '0',
  `sublevel` int(11) default '0',
  `ordering` int(11) default '0',
  `checked_out` int(11) unsigned NOT NULL default '0',
  `checked_out_time` datetime NOT NULL default '0000-00-00 00:00:00',
  `pollid` int(11) NOT NULL default '0',
  `browserNav` tinyint(4) default '0',
  `access` tinyint(3) unsigned NOT NULL default '0',
  `utaccess` tinyint(3) unsigned NOT NULL default '0',
  `params` text NOT NULL,
  `lft` int(11) unsigned NOT NULL default '0',
  `rgt` int(11) unsigned NOT NULL default '0',
  `home` int(1) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `componentid` (`componentid`,`menutype`,`published`,`access`),
  KEY `menutype` (`menutype`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=62 ;

--
-- Dumping data for table `jos_menu`
--

INSERT INTO `jos_menu` (`id`, `menutype`, `name`, `alias`, `link`, `type`, `published`, `parent`, `componentid`, `sublevel`, `ordering`, `checked_out`, `checked_out_time`, `pollid`, `browserNav`, `access`, `utaccess`, `params`, `lft`, `rgt`, `home`) VALUES
(1, 'mainmenu', 'Home', 'home', 'index.php?option=com_content&view=frontpage', 'component', 1, 0, 20, 0, 2, 0, '0000-00-00 00:00:00', 0, 0, 0, 3, 'num_leading_articles=1\nnum_intro_articles=4\nnum_columns=2\nnum_links=4\norderby_pri=\norderby_sec=front\nshow_pagination=2\nshow_pagination_results=1\nshow_feed_link=1\nshow_noauth=\nshow_title=\nlink_titles=\nshow_intro=\nshow_section=\nlink_section=\nshow_category=\nlink_category=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_item_navigation=\nshow_readmore=\nshow_vote=\nshow_icons=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nshow_hits=\nfeed_summary=\npage_title=\nshow_page_title=1\npageclass_sfx=\nmenu_image=-1\nsecure=0\n\n', 0, 0, 1),
(2, 'mainmenu', 'Cambodia Tours', 'cambodia-tours', 'index.php?option=com_content&view=category&id=24', 'component', 1, 0, 20, 0, 3, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'display_num=10\nshow_headings=1\nshow_date=0\ndate_format=\nfilter=1\nfilter_type=title\norderby_sec=\nshow_pagination=1\nshow_pagination_limit=1\nshow_feed_link=1\nshow_noauth=\nshow_title=\nlink_titles=\nshow_intro=\nshow_section=\nlink_section=\nshow_category=\nlink_category=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_item_navigation=\nshow_readmore=\nshow_vote=\nshow_icons=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nshow_hits=\nfeed_summary=\npage_title=\nshow_page_title=1\npageclass_sfx=\nmenu_image=55350715__f2p0166.jpg\nsecure=0\n\n', 0, 0, 0),
(3, 'mainmenu', 'Cambodia Hotel', 'cambodia-hotel', 'index.php?option=com_content&view=article&layout=form', 'component', 1, 0, 20, 0, 4, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'show_noauth=\nshow_title=\nlink_titles=\nshow_intro=\nshow_section=\nlink_section=\nshow_category=\nlink_category=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_item_navigation=\nshow_readmore=\nshow_vote=\nshow_icons=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nshow_hits=\nfeed_summary=\npage_title=\nshow_page_title=1\npageclass_sfx=\nmenu_image=-1\nsecure=0\n\n', 0, 0, 0),
(4, 'mainmenu', 'Gallery', 'gallery', 'index.php?option=com_content&view=article&id=6', 'component', 1, 0, 20, 0, 5, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'show_noauth=\nshow_title=\nlink_titles=\nshow_intro=\nshow_section=\nlink_section=\nshow_category=\nlink_category=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_item_navigation=\nshow_readmore=\nshow_vote=\nshow_icons=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nshow_hits=\nfeed_summary=\npage_title=\nshow_page_title=1\npageclass_sfx=\nmenu_image=-1\nsecure=0\n\n', 0, 0, 0),
(6, 'mainmenu', 'About Us', 'about-us', 'index.php?option=com_content&view=article&id=5', 'component', 1, 0, 20, 0, 7, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'show_noauth=\nshow_title=\nlink_titles=\nshow_intro=\nshow_section=\nlink_section=\nshow_category=\nlink_category=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_item_navigation=\nshow_readmore=\nshow_vote=\nshow_icons=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nshow_hits=\nfeed_summary=\npage_title=\nshow_page_title=1\npageclass_sfx=\nmenu_image=-1\nsecure=0\n\n', 0, 0, 0),
(7, 'mainmenu', 'Classic Tours', 'classic-tours', 'index.php?option=com_content&view=category&layout=blog&id=24', 'component', 1, 2, 20, 1, 1, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'show_description=0\nshow_description_image=0\nnum_leading_articles=1\nnum_intro_articles=4\nnum_columns=2\nnum_links=4\norderby_pri=\norderby_sec=\nmulti_column_order=0\nshow_pagination=2\nshow_pagination_results=1\nshow_feed_link=1\nshow_noauth=\nshow_title=\nlink_titles=\nshow_intro=\nshow_section=\nlink_section=\nshow_category=\nlink_category=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_item_navigation=\nshow_readmore=\nshow_vote=\nshow_icons=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nshow_hits=\nfeed_summary=\npage_title=\nshow_page_title=1\npageclass_sfx=\nmenu_image=-1\nsecure=0\n\n', 0, 0, 0),
(8, 'mainmenu', 'Honeymoon Tours', 'honeymoon-tours', 'index.php?option=com_content&view=article&layout=form', 'component', 1, 2, 20, 1, 2, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'show_noauth=\nshow_title=\nlink_titles=\nshow_intro=\nshow_section=\nlink_section=\nshow_category=\nlink_category=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_item_navigation=\nshow_readmore=\nshow_vote=\nshow_icons=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nshow_hits=\nfeed_summary=\npage_title=\nshow_page_title=1\npageclass_sfx=\nmenu_image=-1\nsecure=0\n\n', 0, 0, 0),
(9, 'mainmenu', 'Adventure Tours', 'adventure-tours', 'index.php?option=com_content&view=article&layout=form', 'component', 1, 2, 20, 1, 3, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'show_noauth=\nshow_title=\nlink_titles=\nshow_intro=\nshow_section=\nlink_section=\nshow_category=\nlink_category=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_item_navigation=\nshow_readmore=\nshow_vote=\nshow_icons=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nshow_hits=\nfeed_summary=\npage_title=\nshow_page_title=1\npageclass_sfx=\nmenu_image=-1\nsecure=0\n\n', 0, 0, 0),
(10, 'mainmenu', 'Golf Tours', 'golf-tours', 'index.php?option=com_content&view=article&layout=form', 'component', 1, 2, 20, 1, 6, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'show_noauth=\nshow_title=\nlink_titles=\nshow_intro=\nshow_section=\nlink_section=\nshow_category=\nlink_category=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_item_navigation=\nshow_readmore=\nshow_vote=\nshow_icons=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nshow_hits=\nfeed_summary=\npage_title=\nshow_page_title=1\npageclass_sfx=\nmenu_image=-1\nsecure=0\n\n', 0, 0, 0),
(11, 'mainmenu', 'Phnom Penh Tours', 'phnom-penh-tours', 'index.php?option=com_content&view=article&layout=form', 'component', 1, 2, 20, 1, 5, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'show_noauth=\nshow_title=\nlink_titles=\nshow_intro=\nshow_section=\nlink_section=\nshow_category=\nlink_category=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_item_navigation=\nshow_readmore=\nshow_vote=\nshow_icons=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nshow_hits=\nfeed_summary=\npage_title=\nshow_page_title=1\npageclass_sfx=\nmenu_image=-1\nsecure=0\n\n', 0, 0, 0),
(12, 'mainmenu', 'Siem Reap Tours', 'siem-reap-tours', 'index.php?option=com_content&view=article&layout=form', 'component', 1, 2, 20, 1, 4, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'show_noauth=\nshow_title=\nlink_titles=\nshow_intro=\nshow_section=\nlink_section=\nshow_category=\nlink_category=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_item_navigation=\nshow_readmore=\nshow_vote=\nshow_icons=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nshow_hits=\nfeed_summary=\npage_title=\nshow_page_title=1\npageclass_sfx=\nmenu_image=-1\nsecure=0\n\n', 0, 0, 0),
(13, 'mainmenu', 'Battambang Hotel', 'battambang-hotel', 'index.php?option=com_content&view=article&layout=form', 'component', 1, 3, 20, 1, 1, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'show_noauth=\nshow_title=\nlink_titles=\nshow_intro=\nshow_section=\nlink_section=\nshow_category=\nlink_category=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_item_navigation=\nshow_readmore=\nshow_vote=\nshow_icons=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nshow_hits=\nfeed_summary=\npage_title=\nshow_page_title=1\npageclass_sfx=\nmenu_image=-1\nsecure=0\n\n', 0, 0, 0),
(14, 'mainmenu', 'Kamport Hotel', 'kamport-hotel', 'index.php?option=com_content&view=article&layout=form', 'component', 1, 3, 20, 1, 2, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'show_noauth=\nshow_title=\nlink_titles=\nshow_intro=\nshow_section=\nlink_section=\nshow_category=\nlink_category=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_item_navigation=\nshow_readmore=\nshow_vote=\nshow_icons=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nshow_hits=\nfeed_summary=\npage_title=\nshow_page_title=1\npageclass_sfx=\nmenu_image=-1\nsecure=0\n\n', 0, 0, 0),
(15, 'mainmenu', 'Kep Hotel', 'kep-hotel', 'index.php?option=com_content&view=article&layout=form', 'component', 1, 3, 20, 1, 3, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'show_noauth=\nshow_title=\nlink_titles=\nshow_intro=\nshow_section=\nlink_section=\nshow_category=\nlink_category=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_item_navigation=\nshow_readmore=\nshow_vote=\nshow_icons=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nshow_hits=\nfeed_summary=\npage_title=\nshow_page_title=1\npageclass_sfx=\nmenu_image=-1\nsecure=0\n\n', 0, 0, 0),
(16, 'mainmenu', 'Koh Kong Hotel', 'koh-kong-hotel', 'index.php?option=com_content&view=article&layout=form', 'component', 1, 3, 20, 1, 4, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'show_noauth=\nshow_title=\nlink_titles=\nshow_intro=\nshow_section=\nlink_section=\nshow_category=\nlink_category=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_item_navigation=\nshow_readmore=\nshow_vote=\nshow_icons=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nshow_hits=\nfeed_summary=\npage_title=\nshow_page_title=1\npageclass_sfx=\nmenu_image=-1\nsecure=0\n\n', 0, 0, 0),
(17, 'mainmenu', 'Kompong Tom Hotel', 'kompong-tom-hotel', 'index.php?option=com_content&view=article&layout=form', 'component', 1, 3, 20, 1, 5, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'show_noauth=\nshow_title=\nlink_titles=\nshow_intro=\nshow_section=\nlink_section=\nshow_category=\nlink_category=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_item_navigation=\nshow_readmore=\nshow_vote=\nshow_icons=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nshow_hits=\nfeed_summary=\npage_title=\nshow_page_title=1\npageclass_sfx=\nmenu_image=-1\nsecure=0\n\n', 0, 0, 0),
(18, 'mainmenu', 'Phnom Penh Hotel', 'phnom-penh-hotel', 'index.php?option=com_content&view=article&layout=form', 'component', 1, 3, 20, 1, 6, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'show_noauth=\nshow_title=\nlink_titles=\nshow_intro=\nshow_section=\nlink_section=\nshow_category=\nlink_category=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_item_navigation=\nshow_readmore=\nshow_vote=\nshow_icons=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nshow_hits=\nfeed_summary=\npage_title=\nshow_page_title=1\npageclass_sfx=\nmenu_image=-1\nsecure=0\n\n', 0, 0, 0),
(19, 'mainmenu', 'Siem Reap Hotel', 'siem-reap-hotel', 'index.php?option=com_content&view=article&layout=form', 'component', 1, 3, 20, 1, 7, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'show_noauth=\nshow_title=\nlink_titles=\nshow_intro=\nshow_section=\nlink_section=\nshow_category=\nlink_category=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_item_navigation=\nshow_readmore=\nshow_vote=\nshow_icons=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nshow_hits=\nfeed_summary=\npage_title=\nshow_page_title=1\npageclass_sfx=\nmenu_image=-1\nsecure=0\n\n', 0, 0, 0),
(20, 'mainmenu', 'Syhanoukvill Hotels', 'syhanoukvill-hotels', 'index.php?option=com_content&view=article&layout=form', 'component', 1, 3, 20, 1, 8, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'show_noauth=\nshow_title=\nlink_titles=\nshow_intro=\nshow_section=\nlink_section=\nshow_category=\nlink_category=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_item_navigation=\nshow_readmore=\nshow_vote=\nshow_icons=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nshow_hits=\nfeed_summary=\npage_title=\nshow_page_title=1\npageclass_sfx=\nmenu_image=-1\nsecure=0\n\n', 0, 0, 0),
(47, 'mainmenu', 'Travel Guide', 'travel-guide', 'index.php?option=com_travelbook&view=travelbook&layout=travelbook', 'component', 1, 0, 91, 0, 6, 62, '2011-04-11 07:57:03', 0, 0, 0, 0, 'title=\nimage=\ncontact=\ntelefon=\ncurrency=\nother=$\nfeeder=\nhotel_select=\nhotel=\nquestion=\narb=\npolicy=\narb_pdf=-1\npolicy_pdf=-1\nredirect=\npage_title=\nshow_page_title=1\npageclass_sfx=\nmenu_image=-1\nsecure=0\n\n', 0, 0, 0),
(61, 'mainmenu', 'Booking', 'booking', 'index.php?option=com_ttbooking&view=ttbooking', 'component', 1, 0, 132, 0, 8, 62, '2011-05-01 18:37:41', 0, 0, 0, 0, 'page_title=\nshow_page_title=1\npageclass_sfx=\nmenu_image=-1\nsecure=0\n\n', 0, 0, 0),
(48, 'mainmenu', 'Visa and Passport', 'climate-and-wealther', 'index.php?option=com_content&view=article&id=14', 'component', 1, 47, 20, 1, 1, 62, '2011-04-21 03:29:01', 0, 0, 0, 0, 'show_noauth=\nshow_title=\nlink_titles=\nshow_intro=\nshow_section=\nlink_section=\nshow_category=\nlink_category=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_item_navigation=\nshow_readmore=\nshow_vote=\nshow_icons=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nshow_hits=\nfeed_summary=\npage_title=\nshow_page_title=1\npageclass_sfx=\nmenu_image=-1\nsecure=0\n\n', 0, 0, 0),
(23, 'mainmenu', 'About Cambodia', 'about-cambodia', 'index.php?option=com_content&view=article&id=5', 'component', -2, 0, 20, 1, 1, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'show_noauth=0\nshow_title=0\nlink_titles=0\nshow_intro=0\nshow_section=0\nlink_section=0\nshow_category=0\nlink_category=0\nshow_author=0\nshow_create_date=0\nshow_modify_date=0\nshow_item_navigation=0\nshow_readmore=0\nshow_vote=0\nshow_icons=0\nshow_pdf_icon=0\nshow_print_icon=0\nshow_email_icon=0\nshow_hits=0\nfeed_summary=\npage_title=\nshow_page_title=1\npageclass_sfx=\nmenu_image=-1\nsecure=0\n\n', 0, 0, 0),
(49, 'mainmenu', 'Learn Khmer', 'learn-khmer', 'index.php?option=com_content&view=article&id=13', 'component', 1, 47, 20, 1, 2, 62, '2011-04-22 02:17:28', 0, 0, 0, 0, 'show_noauth=\nshow_title=\nlink_titles=\nshow_intro=\nshow_section=\nlink_section=\nshow_category=\nlink_category=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_item_navigation=\nshow_readmore=\nshow_vote=\nshow_icons=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nshow_hits=\nfeed_summary=\npage_title=\nshow_page_title=1\npageclass_sfx=\nmenu_image=-1\nsecure=0\n\n', 0, 0, 0),
(50, 'mainmenu', 'Health and Advice', 'health-and-advice', 'index.php?option=com_content&view=article&id=12', 'component', 1, 47, 20, 1, 3, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'show_noauth=\nshow_title=\nlink_titles=\nshow_intro=\nshow_section=\nlink_section=\nshow_category=\nlink_category=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_item_navigation=\nshow_readmore=\nshow_vote=\nshow_icons=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nshow_hits=\nfeed_summary=\npage_title=\nshow_page_title=1\npageclass_sfx=\nmenu_image=-1\nsecure=0\n\n', 0, 0, 0),
(26, 'mainmenu', 'Embassy Abroad', 'embassy-abroad', 'index.php?option=com_content&view=article&id=8', 'component', 1, 5, 20, 1, 1, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'show_noauth=\nshow_title=\nlink_titles=\nshow_intro=\nshow_section=\nlink_section=\nshow_category=\nlink_category=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_item_navigation=\nshow_readmore=\nshow_vote=\nshow_icons=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nshow_hits=\nfeed_summary=\npage_title=\nshow_page_title=1\npageclass_sfx=\nmenu_image=-1\nsecure=0\n\n', 0, 0, 0),
(27, 'mainmenu', 'Time and Currency', 'time-and-currency', 'index.php?option=com_content&view=article&id=9', 'component', 1, 5, 20, 1, 2, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'show_noauth=\nshow_title=\nlink_titles=\nshow_intro=\nshow_section=\nlink_section=\nshow_category=\nlink_category=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_item_navigation=\nshow_readmore=\nshow_vote=\nshow_icons=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nshow_hits=\nfeed_summary=\npage_title=\nshow_page_title=1\npageclass_sfx=\nmenu_image=-1\nsecure=0\n\n', 0, 0, 0),
(28, 'mainmenu', 'Get in and get out', 'get-in-and-get-out', 'index.php?option=com_content&view=article&id=10', 'component', 1, 5, 20, 1, 3, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'show_noauth=\nshow_title=\nlink_titles=\nshow_intro=\nshow_section=\nlink_section=\nshow_category=\nlink_category=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_item_navigation=\nshow_readmore=\nshow_vote=\nshow_icons=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nshow_hits=\nfeed_summary=\npage_title=\nshow_page_title=1\npageclass_sfx=\nmenu_image=-1\nsecure=0\n\n', 0, 0, 0),
(29, 'mainmenu', 'Visa and Passport', 'visa-and-passport', 'index.php?option=com_content&view=article&id=14', 'component', 1, 5, 20, 1, 4, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'show_noauth=\nshow_title=\nlink_titles=\nshow_intro=\nshow_section=\nlink_section=\nshow_category=\nlink_category=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_item_navigation=\nshow_readmore=\nshow_vote=\nshow_icons=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nshow_hits=\nfeed_summary=\npage_title=\nshow_page_title=1\npageclass_sfx=\nmenu_image=-1\nsecure=0\n\n', 0, 0, 0),
(30, 'mainmenu', 'Learn Khmer', 'learn-khmer', 'index.php?option=com_content&view=article&id=13', 'component', 1, 5, 20, 1, 5, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'show_noauth=\nshow_title=\nlink_titles=\nshow_intro=\nshow_section=\nlink_section=\nshow_category=\nlink_category=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_item_navigation=\nshow_readmore=\nshow_vote=\nshow_icons=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nshow_hits=\nfeed_summary=\npage_title=\nshow_page_title=1\npageclass_sfx=\nmenu_image=-1\nsecure=0\n\n', 0, 0, 0),
(31, 'mainmenu', 'Health and Advice', 'health-and-advice', 'index.php?option=com_content&view=article&id=12', 'component', 1, 5, 20, 1, 6, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'show_noauth=\nshow_title=\nlink_titles=\nshow_intro=\nshow_section=\nlink_section=\nshow_category=\nlink_category=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_item_navigation=\nshow_readmore=\nshow_vote=\nshow_icons=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nshow_hits=\nfeed_summary=\npage_title=\nshow_page_title=1\npageclass_sfx=\nmenu_image=-1\nsecure=0\n\n', 0, 0, 0),
(32, 'mainmenu', 'Climate and Weather', 'climate-and-weather', 'index.php?option=com_content&view=article&id=11', 'component', 1, 5, 20, 1, 7, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'show_noauth=\nshow_title=\nlink_titles=\nshow_intro=\nshow_section=\nlink_section=\nshow_category=\nlink_category=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_item_navigation=\nshow_readmore=\nshow_vote=\nshow_icons=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nshow_hits=\nfeed_summary=\npage_title=\nshow_page_title=1\npageclass_sfx=\nmenu_image=-1\nsecure=0\n\n', 0, 0, 0),
(54, 'mainmenu', 'Embassy Abroad', 'embassy-abroad', 'index.php?option=com_content&view=article&id=8', 'component', 1, 47, 20, 1, 7, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'show_noauth=\nshow_title=\nlink_titles=\nshow_intro=\nshow_section=\nlink_section=\nshow_category=\nlink_category=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_item_navigation=\nshow_readmore=\nshow_vote=\nshow_icons=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nshow_hits=\nfeed_summary=\npage_title=\nshow_page_title=1\npageclass_sfx=\nmenu_image=-1\nsecure=0\n\n', 0, 0, 0),
(53, 'mainmenu', 'Time and Currency', 'time-and-currency', 'index.php?option=com_content&view=article&id=9', 'component', 1, 47, 20, 1, 6, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'show_noauth=\nshow_title=\nlink_titles=\nshow_intro=\nshow_section=\nlink_section=\nshow_category=\nlink_category=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_item_navigation=\nshow_readmore=\nshow_vote=\nshow_icons=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nshow_hits=\nfeed_summary=\npage_title=\nshow_page_title=1\npageclass_sfx=\nmenu_image=-1\nsecure=0\n\n', 0, 0, 0),
(51, 'mainmenu', 'Climate and Wealther', 'climate-and-wealther', 'index.php?option=com_content&view=article&id=11', 'component', 1, 47, 20, 1, 4, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'show_noauth=\nshow_title=\nlink_titles=\nshow_intro=\nshow_section=\nlink_section=\nshow_category=\nlink_category=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_item_navigation=\nshow_readmore=\nshow_vote=\nshow_icons=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nshow_hits=\nfeed_summary=\npage_title=\nshow_page_title=1\npageclass_sfx=\nmenu_image=-1\nsecure=0\n\n', 0, 0, 0),
(52, 'mainmenu', 'Get in and Get out', 'get-in-and-get-out', 'index.php?option=com_content&view=article&id=10', 'component', 1, 47, 20, 1, 5, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'show_noauth=\nshow_title=\nlink_titles=\nshow_intro=\nshow_section=\nlink_section=\nshow_category=\nlink_category=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_item_navigation=\nshow_readmore=\nshow_vote=\nshow_icons=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nshow_hits=\nfeed_summary=\npage_title=\nshow_page_title=1\npageclass_sfx=\nmenu_image=-1\nsecure=0\n\n', 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `jos_menu_types`
--

CREATE TABLE IF NOT EXISTS `jos_menu_types` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `menutype` varchar(75) NOT NULL default '',
  `title` varchar(255) NOT NULL default '',
  `description` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`id`),
  UNIQUE KEY `menutype` (`menutype`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `jos_menu_types`
--

INSERT INTO `jos_menu_types` (`id`, `menutype`, `title`, `description`) VALUES
(1, 'mainmenu', 'Main Menu', 'The main menu for the site');

-- --------------------------------------------------------

--
-- Table structure for table `jos_messages`
--

CREATE TABLE IF NOT EXISTS `jos_messages` (
  `message_id` int(10) unsigned NOT NULL auto_increment,
  `user_id_from` int(10) unsigned NOT NULL default '0',
  `user_id_to` int(10) unsigned NOT NULL default '0',
  `folder_id` int(10) unsigned NOT NULL default '0',
  `date_time` datetime NOT NULL default '0000-00-00 00:00:00',
  `state` int(11) NOT NULL default '0',
  `priority` int(1) unsigned NOT NULL default '0',
  `subject` text NOT NULL,
  `message` text NOT NULL,
  PRIMARY KEY  (`message_id`),
  KEY `useridto_state` (`user_id_to`,`state`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `jos_messages`
--


-- --------------------------------------------------------

--
-- Table structure for table `jos_messages_cfg`
--

CREATE TABLE IF NOT EXISTS `jos_messages_cfg` (
  `user_id` int(10) unsigned NOT NULL default '0',
  `cfg_name` varchar(100) NOT NULL default '',
  `cfg_value` varchar(255) NOT NULL default '',
  UNIQUE KEY `idx_user_var_name` (`user_id`,`cfg_name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `jos_messages_cfg`
--


-- --------------------------------------------------------

--
-- Table structure for table `jos_migration_backlinks`
--

CREATE TABLE IF NOT EXISTS `jos_migration_backlinks` (
  `itemid` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `url` text NOT NULL,
  `sefurl` text NOT NULL,
  `newurl` text NOT NULL,
  PRIMARY KEY  (`itemid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `jos_migration_backlinks`
--


-- --------------------------------------------------------

--
-- Table structure for table `jos_modules`
--

CREATE TABLE IF NOT EXISTS `jos_modules` (
  `id` int(11) NOT NULL auto_increment,
  `title` text NOT NULL,
  `content` text NOT NULL,
  `ordering` int(11) NOT NULL default '0',
  `position` varchar(50) default NULL,
  `checked_out` int(11) unsigned NOT NULL default '0',
  `checked_out_time` datetime NOT NULL default '0000-00-00 00:00:00',
  `published` tinyint(1) NOT NULL default '0',
  `module` varchar(50) default NULL,
  `numnews` int(11) NOT NULL default '0',
  `access` tinyint(3) unsigned NOT NULL default '0',
  `showtitle` tinyint(3) unsigned NOT NULL default '1',
  `params` text NOT NULL,
  `iscore` tinyint(4) NOT NULL default '0',
  `client_id` tinyint(4) NOT NULL default '0',
  `control` text NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `published` (`published`,`access`),
  KEY `newsfeeds` (`module`,`published`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=55 ;

--
-- Dumping data for table `jos_modules`
--

INSERT INTO `jos_modules` (`id`, `title`, `content`, `ordering`, `position`, `checked_out`, `checked_out_time`, `published`, `module`, `numnews`, `access`, `showtitle`, `params`, `iscore`, `client_id`, `control`) VALUES
(1, 'Main Menu', '', 0, 'hornav', 0, '0000-00-00 00:00:00', 1, 'mod_mainmenu', 0, 0, 1, 'menutype=mainmenu\nmenu_style=list\nstartLevel=0\nendLevel=0\nshowAllChildren=1\nwindow_open=\nshow_whitespace=0\ncache=1\ntag_id=\nclass_sfx=\nmoduleclass_sfx=_menu\nmaxdepth=10\nmenu_images=0\nmenu_images_align=2\nmenu_images_link=0\nexpand_menu=0\nactivate_parent=0\nfull_active_id=0\nindent_image=1\nindent_image1=\nindent_image2=\nindent_image3=\nindent_image4=\nindent_image5=\nindent_image6=\nspacer=\nend_spacer=\n\n', 1, 0, ''),
(2, 'Login', '', 1, 'login', 0, '0000-00-00 00:00:00', 1, 'mod_login', 0, 0, 1, '', 1, 1, ''),
(3, 'Popular', '', 3, 'cpanel', 0, '0000-00-00 00:00:00', 1, 'mod_popular', 0, 2, 1, '', 0, 1, ''),
(4, 'Recent added Articles', '', 4, 'cpanel', 0, '0000-00-00 00:00:00', 1, 'mod_latest', 0, 2, 1, 'ordering=c_dsc\nuser_id=0\ncache=0\n\n', 0, 1, ''),
(5, 'Menu Stats', '', 5, 'cpanel', 0, '0000-00-00 00:00:00', 1, 'mod_stats', 0, 2, 1, '', 0, 1, ''),
(6, 'Unread Messages', '', 1, 'header', 0, '0000-00-00 00:00:00', 1, 'mod_unread', 0, 2, 1, '', 1, 1, ''),
(7, 'Online Users', '', 2, 'header', 0, '0000-00-00 00:00:00', 1, 'mod_online', 0, 2, 1, '', 1, 1, ''),
(8, 'Toolbar', '', 1, 'toolbar', 0, '0000-00-00 00:00:00', 1, 'mod_toolbar', 0, 2, 1, '', 1, 1, ''),
(9, 'Quick Icons', '', 1, 'icon', 0, '0000-00-00 00:00:00', 1, 'mod_quickicon', 0, 2, 1, '', 1, 1, ''),
(10, 'Logged in Users', '', 2, 'cpanel', 0, '0000-00-00 00:00:00', 1, 'mod_logged', 0, 2, 1, '', 0, 1, ''),
(11, 'Footer', '', 0, 'footer', 0, '0000-00-00 00:00:00', 1, 'mod_footer', 0, 0, 1, '', 1, 1, ''),
(12, 'Admin Menu', '', 1, 'menu', 0, '0000-00-00 00:00:00', 1, 'mod_menu', 0, 2, 1, '', 0, 1, ''),
(13, 'Admin SubMenu', '', 1, 'submenu', 0, '0000-00-00 00:00:00', 1, 'mod_submenu', 0, 2, 1, '', 0, 1, ''),
(14, 'User Status', '', 1, 'status', 0, '0000-00-00 00:00:00', 1, 'mod_status', 0, 2, 1, '', 0, 1, ''),
(15, 'Title', '', 1, 'title', 0, '0000-00-00 00:00:00', 1, 'mod_title', 0, 2, 1, '', 0, 1, ''),
(16, 'Language Selection', '', -1, 'user4', 62, '2011-04-21 03:01:51', 1, 'mod_jflanguageselection', 0, 0, 0, '', 0, 0, ''),
(17, 'Direct Translation', '', 0, 'status', 0, '0000-00-00 00:00:00', 1, 'mod_translate', 0, 2, 0, '', 0, 1, ''),
(26, 'The Cambodia Photos', '', 0, 'top', 62, '2011-04-11 06:08:15', 1, 'mod_djimageslider', 0, 0, 1, 'slider_source=0\nslider_type=0\nmootools=0\nlink_image=2\nimage_folder=images/image_slide/\nlink=\nshow_title=1\nshow_desc=1\nshow_readmore=1\nlink_title=1\nlink_desc=0\nlimit_desc=\nimage_width=80\nimage_height=80\nfit_to=2\nvisible_images=8\nspace_between_images=1\nmax_images=20\nsort_by=1\neffect=Circ\nautoplay=1\nshow_buttons=0\nshow_arrows=0\nshow_custom_nav=0\ndesc_width=\ndesc_bottom=0\ndesc_horizontal=0\nleft_arrow=\nright_arrow=\nplay_button=\npause_button=\narrows_top=30\narrows_horizontal=5\neffect_type=easeOut\nduration=\ndelay=\npreload=800\nmoduleclass_sfx=\ncache=0\n\n', 0, 0, ''),
(27, 'Subcription', '', 0, 'right', 0, '0000-00-00 00:00:00', 1, 'mod_freecontact', 0, 0, 1, 'introtext=Contact us by Mail\nreceipt_email=reachponlue@gmail.com\nsubject=test mail\nthanks=Send Mail is successfull\nerror=Not sended , Error\nsubmit_button=Send\nmoduleclass_sfx=\n\n', 0, 0, ''),
(36, 'slider', '', 0, 'banner', 0, '0000-00-00 00:00:00', 1, 'mod_lv_enhanced_image_slider', 0, 0, 1, 'lveisWidth=870\nulHeight=350\nlveisFloat=none\nuseNav=1\nnavHeight=20\nnextbutton=1\nprevbutton=1\nlveisindex=1\neffectFx=all\ntimeout=4000\nspeed=1000\npause=1\nrandom=0\nimageFolder=images/image_slide/\nstretchImages=1\nuselinks=1\nlinktarget=_self\nuseModalbox=1\ntransparentBgColor=0\nlveis_bgcolor=FFFFFF\nlveisnav_bgcolor=000000\nlveisnav_bordercolor=000000\nlveisnav_a=888888\nlveisnav_ahover=FFFFFF\nlveisnav_aborder=282828\nlveisnav_aact=FFFFFF\nlveisnav_aactbg=222222\nlveisnav_aactborder=111111\nuseCompression=1\nimageCentered=1\nslider_id=3\nmoduleclass_sfx=\ncache=1\ncache_time=900\n\n', 0, 0, ''),
(45, 'Vinaora Visitors Counter', '', 0, 'right', 0, '0000-00-00 00:00:00', 1, 'mod_vvisit_counter', 0, 0, 0, 'moduleclass_sfx=\nmode=custom\ninitialvalue=0\ndigit_type=embwhite\nnumber_digits=5\nstats_type=checkout\nwidthtable=90\ntoday=Today\nyesterday=Yesterday\nweek=This week\nlweek=Last week\nmonth=This month\nlmonth=Last month\nall=All days\nautohide=0\nhrline=1\nbeginday=\nonline=We have\nguestip=Your IP\nguestinfo=Yes\nformattime=Today: %b %d, %Y\nissunday=1\ncache_time=15\npretext=\nposttext=\n\n', 0, 0, ''),
(43, 'Search', '', 2, 'banner', 0, '0000-00-00 00:00:00', 1, 'mod_search', 0, 0, 1, 'moduleclass_sfx=\nwidth=60\ntext=Serach\nbutton=1\nbutton_pos=right\nimagebutton=\nbutton_text=Search\nset_itemid=\ncache=1\ncache_time=900\n\n', 0, 0, ''),
(54, 'Iyosis Facebook Module', '', 0, 'right', 0, '0000-00-00 00:00:00', 1, 'mod_iyosis_facebook', 0, 0, 1, 'plugin=LikeBox\nURLLikeButton=http://www.facebook.com/joomla\ncodeTypeLikeButton=iframe\nwidthLikeButton=180\nheightLikeButton=30\ncolorSchemeLikeButton=light\nshowFacesLikeButton=1\nlayoutLikeButton=standard\nURLLikeBox=http://www.facebook.com/joomla\ncodeTypeLikeBox=iframe\nwidthLikeBox=250\nheightLikeBox=600\ncolorSchemeLikeBox=light\nshowFacesLikeBox=1\nshowStreamLikeBox=1\nshowHeaderLikeBox=1\ndomainActivityFeed=abktours.com\ncodeTypeActivityFeed=iframe\nwidthActivityFeed=250\nheightActivityFeed=600\ncolorSchemeActivityFeed=light\nshowHeaderActivityFeed=1\ndomainRecommendations=abktours.com\ncodeTypeRecommendations=iframe\nwidthRecommendations=250\nheightRecommendations=600\ncolorSchemeRecommendations=light\nshowHeaderRecommendations=1\nmoduleclass_sfx=\n\n', 0, 0, '');

-- --------------------------------------------------------

--
-- Table structure for table `jos_modules_menu`
--

CREATE TABLE IF NOT EXISTS `jos_modules_menu` (
  `moduleid` int(11) NOT NULL default '0',
  `menuid` int(11) NOT NULL default '0',
  PRIMARY KEY  (`moduleid`,`menuid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `jos_modules_menu`
--

INSERT INTO `jos_modules_menu` (`moduleid`, `menuid`) VALUES
(1, 0),
(16, 0),
(26, 1),
(27, 1),
(27, 2),
(27, 3),
(27, 5),
(27, 6),
(27, 7),
(27, 8),
(27, 9),
(27, 10),
(27, 11),
(27, 12),
(27, 13),
(27, 14),
(27, 15),
(27, 16),
(27, 17),
(27, 18),
(27, 19),
(27, 20),
(27, 23),
(27, 26),
(27, 27),
(27, 28),
(36, 1),
(43, 1),
(43, 2),
(43, 3),
(43, 5),
(43, 6),
(43, 7),
(43, 8),
(43, 9),
(43, 10),
(43, 11),
(43, 12),
(43, 13),
(43, 14),
(43, 15),
(43, 16),
(43, 17),
(43, 18),
(43, 19),
(43, 20),
(43, 23),
(43, 26),
(43, 27),
(43, 28),
(45, 1),
(45, 2),
(45, 3),
(45, 5),
(45, 6),
(45, 7),
(45, 8),
(45, 9),
(45, 10),
(45, 11),
(45, 12),
(45, 13),
(45, 14),
(45, 15),
(45, 16),
(45, 17),
(45, 18),
(45, 19),
(45, 20),
(45, 23),
(45, 26),
(45, 27),
(45, 28),
(54, 0);

-- --------------------------------------------------------

--
-- Table structure for table `jos_newsfeeds`
--

CREATE TABLE IF NOT EXISTS `jos_newsfeeds` (
  `catid` int(11) NOT NULL default '0',
  `id` int(11) NOT NULL auto_increment,
  `name` text NOT NULL,
  `alias` varchar(255) NOT NULL default '',
  `link` text NOT NULL,
  `filename` varchar(200) default NULL,
  `published` tinyint(1) NOT NULL default '0',
  `numarticles` int(11) unsigned NOT NULL default '1',
  `cache_time` int(11) unsigned NOT NULL default '3600',
  `checked_out` tinyint(3) unsigned NOT NULL default '0',
  `checked_out_time` datetime NOT NULL default '0000-00-00 00:00:00',
  `ordering` int(11) NOT NULL default '0',
  `rtl` tinyint(4) NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `published` (`published`),
  KEY `catid` (`catid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `jos_newsfeeds`
--


-- --------------------------------------------------------

--
-- Table structure for table `jos_plugins`
--

CREATE TABLE IF NOT EXISTS `jos_plugins` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(100) NOT NULL default '',
  `element` varchar(100) NOT NULL default '',
  `folder` varchar(100) NOT NULL default '',
  `access` tinyint(3) unsigned NOT NULL default '0',
  `ordering` int(11) NOT NULL default '0',
  `published` tinyint(3) NOT NULL default '0',
  `iscore` tinyint(3) NOT NULL default '0',
  `client_id` tinyint(3) NOT NULL default '0',
  `checked_out` int(11) unsigned NOT NULL default '0',
  `checked_out_time` datetime NOT NULL default '0000-00-00 00:00:00',
  `params` text NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `idx_folder` (`published`,`client_id`,`access`,`folder`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=57 ;

--
-- Dumping data for table `jos_plugins`
--

INSERT INTO `jos_plugins` (`id`, `name`, `element`, `folder`, `access`, `ordering`, `published`, `iscore`, `client_id`, `checked_out`, `checked_out_time`, `params`) VALUES
(1, 'Authentication - Joomla', 'joomla', 'authentication', 0, 1, 1, 1, 0, 0, '0000-00-00 00:00:00', ''),
(2, 'Authentication - LDAP', 'ldap', 'authentication', 0, 2, 0, 1, 0, 0, '0000-00-00 00:00:00', 'host=\nport=389\nuse_ldapV3=0\nnegotiate_tls=0\nno_referrals=0\nauth_method=bind\nbase_dn=\nsearch_string=\nusers_dn=\nusername=\npassword=\nldap_fullname=fullName\nldap_email=mail\nldap_uid=uid\n\n'),
(3, 'Authentication - GMail', 'gmail', 'authentication', 0, 4, 0, 0, 0, 62, '2011-04-08 06:48:26', ''),
(4, 'Authentication - OpenID', 'openid', 'authentication', 0, 3, 0, 0, 0, 0, '0000-00-00 00:00:00', ''),
(5, 'User - Joomla!', 'joomla', 'user', 0, 0, 1, 0, 0, 0, '0000-00-00 00:00:00', 'autoregister=1\n\n'),
(6, 'Search - Content', 'content', 'search', 0, 1, 1, 1, 0, 0, '0000-00-00 00:00:00', 'search_limit=50\nsearch_content=1\nsearch_uncategorised=1\nsearch_archived=1\n\n'),
(7, 'Search - Contacts', 'contacts', 'search', 0, 3, 1, 1, 0, 0, '0000-00-00 00:00:00', 'search_limit=50\n\n'),
(8, 'Search - Categories', 'categories', 'search', 0, 4, 1, 0, 0, 0, '0000-00-00 00:00:00', 'search_limit=50\n\n'),
(9, 'Search - Sections', 'sections', 'search', 0, 5, 1, 0, 0, 0, '0000-00-00 00:00:00', 'search_limit=50\n\n'),
(10, 'Search - Newsfeeds', 'newsfeeds', 'search', 0, 6, 1, 0, 0, 0, '0000-00-00 00:00:00', 'search_limit=50\n\n'),
(11, 'Search - Weblinks', 'weblinks', 'search', 0, 2, 1, 1, 0, 0, '0000-00-00 00:00:00', 'search_limit=50\n\n'),
(12, 'Content - Pagebreak', 'pagebreak', 'content', 0, 10000, 1, 1, 0, 0, '0000-00-00 00:00:00', 'enabled=1\ntitle=1\nmultipage_toc=1\nshowall=1\n\n'),
(13, 'Content - Rating', 'vote', 'content', 0, 4, 1, 1, 0, 0, '0000-00-00 00:00:00', ''),
(14, 'Content - Email Cloaking', 'emailcloak', 'content', 0, 5, 1, 0, 0, 0, '0000-00-00 00:00:00', 'mode=1\n\n'),
(15, 'Content - Code Hightlighter (GeSHi)', 'geshi', 'content', 0, 5, 0, 0, 0, 0, '0000-00-00 00:00:00', ''),
(16, 'Content - Load Module', 'loadmodule', 'content', 0, 6, 1, 0, 0, 0, '0000-00-00 00:00:00', 'enabled=1\nstyle=0\n\n'),
(17, 'Content - Page Navigation', 'pagenavigation', 'content', 0, 2, 1, 1, 0, 0, '0000-00-00 00:00:00', 'position=1\n\n'),
(18, 'Editor - No Editor', 'none', 'editors', 0, 0, 1, 1, 0, 0, '0000-00-00 00:00:00', ''),
(19, 'Editor - TinyMCE', 'tinymce', 'editors', 0, 0, 1, 1, 0, 0, '0000-00-00 00:00:00', 'mode=advanced\nskin=0\ncompressed=0\ncleanup_startup=0\ncleanup_save=2\nentity_encoding=raw\nlang_mode=0\nlang_code=en\ntext_direction=ltr\ncontent_css=1\ncontent_css_custom=\nrelative_urls=1\nnewlines=0\ninvalid_elements=applet\nextended_elements=\ntoolbar=top\ntoolbar_align=left\nhtml_height=550\nhtml_width=750\nelement_path=1\nfonts=1\npaste=1\nsearchreplace=1\ninsertdate=1\nformat_date=%Y-%m-%d\ninserttime=1\nformat_time=%H:%M:%S\ncolors=1\ntable=1\nsmilies=1\nmedia=1\nhr=1\ndirectionality=1\nfullscreen=1\nstyle=1\nlayer=1\nxhtmlxtras=1\nvisualchars=1\nnonbreaking=1\ntemplate=0\nadvimage=1\nadvlink=1\nautosave=1\ncontextmenu=1\ninlinepopups=1\nsafari=1\ncustom_plugin=\ncustom_button=\n\n'),
(20, 'Editor - XStandard Lite 2.0', 'xstandard', 'editors', 0, 0, 0, 1, 0, 0, '0000-00-00 00:00:00', ''),
(21, 'Editor Button - Image', 'image', 'editors-xtd', 0, 0, 1, 0, 0, 0, '0000-00-00 00:00:00', ''),
(22, 'Editor Button - Pagebreak', 'pagebreak', 'editors-xtd', 0, 0, 1, 0, 0, 0, '0000-00-00 00:00:00', ''),
(23, 'Editor Button - Readmore', 'readmore', 'editors-xtd', 0, 0, 1, 0, 0, 62, '2011-04-08 06:49:28', ''),
(24, 'XML-RPC - Joomla', 'joomla', 'xmlrpc', 0, 7, 0, 1, 0, 0, '0000-00-00 00:00:00', ''),
(25, 'XML-RPC - Blogger API', 'blogger', 'xmlrpc', 0, 7, 0, 1, 0, 0, '0000-00-00 00:00:00', 'catid=1\nsectionid=0\n\n'),
(27, 'System - SEF', 'sef', 'system', 0, 1, 1, 0, 0, 0, '0000-00-00 00:00:00', ''),
(28, 'System - Debug', 'debug', 'system', 0, 2, 1, 0, 0, 0, '0000-00-00 00:00:00', 'queries=1\nmemory=1\nlangauge=1\n\n'),
(29, 'System - Legacy', 'legacy', 'system', 0, 3, 0, 1, 0, 0, '0000-00-00 00:00:00', 'route=0\n\n'),
(30, 'System - Cache', 'cache', 'system', 0, 4, 0, 1, 0, 0, '0000-00-00 00:00:00', 'browsercache=0\ncachetime=15\n\n'),
(31, 'System - Log', 'log', 'system', 0, 5, 0, 1, 0, 0, '0000-00-00 00:00:00', ''),
(32, 'System - Remember Me', 'remember', 'system', 0, 6, 1, 1, 0, 0, '0000-00-00 00:00:00', ''),
(33, 'System - Backlink', 'backlink', 'system', 0, 7, 0, 1, 0, 0, '0000-00-00 00:00:00', ''),
(34, 'System - Mootools Upgrade', 'mtupgrade', 'system', 0, 8, 0, 1, 0, 0, '0000-00-00 00:00:00', ''),
(35, 'System - Jfdatabase', 'jfdatabase', 'system', 0, -100, 1, 0, 0, 0, '0000-00-00 00:00:00', ''),
(36, 'System - Jfrouter', 'jfrouter', 'system', 0, -101, 1, 0, 0, 0, '0000-00-00 00:00:00', ''),
(37, 'Content - Jfalternative', 'jfalternative', 'content', 0, 0, 1, 0, 0, 0, '0000-00-00 00:00:00', ''),
(38, 'Search - Jfcategories', 'jfcategories', 'search', 0, 0, 1, 0, 0, 0, '0000-00-00 00:00:00', ''),
(39, 'Search - Jfcontacts', 'jfcontacts', 'search', 0, 0, 1, 0, 0, 0, '0000-00-00 00:00:00', ''),
(40, 'Search - Jfcontent', 'jfcontent', 'search', 0, 0, 1, 0, 0, 0, '0000-00-00 00:00:00', ''),
(41, 'Search - Jfnewsfeeds', 'jfnewsfeeds', 'search', 0, 0, 1, 0, 0, 0, '0000-00-00 00:00:00', ''),
(42, 'Search - Jfsections', 'jfsections', 'search', 0, 0, 1, 0, 0, 0, '0000-00-00 00:00:00', ''),
(43, 'Search - Jfweblinks', 'jfweblinks', 'search', 0, 0, 1, 0, 0, 0, '0000-00-00 00:00:00', ''),
(44, 'Joomfish - Missing_translation', 'missing_translation', 'joomfish', 0, 0, 1, 0, 0, 0, '0000-00-00 00:00:00', ''),
(45, 'Simple Picture Slideshow', 'besps', 'content', 0, 0, 1, 0, 0, 0, '0000-00-00 00:00:00', 'im_width=400\nim_height=300\nim_align=1\nsl_bgcol=FFFFFF\nbs_sort=0\nsl_sdur=3\nsl_fdur=1\nsl_steps=20\nautostart=1\nctrl_show=1\nctrl_sort=1-2345\nctrl_start=\nctrl_stop=\nctrl_back=\nctrl_fwd=\ncap_show=1\ncap_pos=1\nlink_use=1\nimagepath=/images/image_slide/\nbuttonpath=/images/stories/besps_buttons/\nstylesheet=besps.css\njavascript=besps.js\npreld=\nsetid=0\n\n'),
(46, 'Content - Fade Gallery', 'fadegallery', 'content', 0, 0, 1, 0, 0, 0, '0000-00-00 00:00:00', ''),
(49, 'System - Vinaora Visitors Counter', 'vvisit_counter', 'system', 0, -100, 1, 0, 0, 0, '0000-00-00 00:00:00', ''),
(48, 'Content - Booking Wizard', 'BookingWizard', 'content', 0, 0, 1, 0, 0, 0, '0000-00-00 00:00:00', 'booking_language=en\nuse_page_language=1\naccount=demoAccount\nlayout=classic\nclassid=booking\ndebug=1\ntestInstruct={booking property,Portal}\navailability={booking availability}\nadministration={booking administration}\n\n'),
(50, 'Very Simple Image Gallery', 'vsig', 'content', 0, 0, 1, 0, 0, 0, '0000-00-00 00:00:00', 'im_width=800\nim_height=450\nim_quality=500\nim_align=1\nth_width=120\nth_height=90\nth_keep=keep\nth_quality=80\nth_space=9\nth_right=2\nth_cols=2\nth_sort=0\nsets_use=\nsets_txt=Set\nctrl_fwd=\nctrl_back=\ncap_show=1\ncap_pos=0\nlink_use=1\nlink_orig=0\nimagepath=/images/image_slide/\nbuttonpath=/images/stories/vsig_buttons/\nusescript=1\nth_hover=0\npreload=0\ntooltip=1\nsetid=0\n\n'),
(53, 'CSS Gallery', 'becssg', 'content', 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00', 'im_width=400\nim_height=300\nim_quality=95\nim_keep=keep\nim_align=1\nth_sort=0\nim_preload=1\nim_fixstart=1\nth_row=4\nth_quality=80\nth_space=5\nth_keep=keep\ncap_show=1\nlink_use=1\nimagepath=/images/image_slide/\n\n'),
(51, 'Content - bo:VideoJS', 'bo_videojs', 'content', 0, 0, 1, 0, 0, 0, '0000-00-00 00:00:00', 'video_mp4=http://video-js.zencoder.com/oceans-clip.mp4\nvideo_webm=http://video-js.zencoder.com/oceans-clip.webm\nvideo_ogg=http://video-js.zencoder.com/oceans-clip.ogv\nflash=http://video-js.zencoder.com/oceans-clip.mp4\nimage=http://video-js.zencoder.com/oceans-clip.png\nwidth=640\nheight=264\nskin=vim\nautoplay=0\npreload=1\nloop=0\ncontrolsBelow=0\ncontrolsAtStart=0\ncontrolsHiding=1\ndefaultVolume=0.85\nplayerFallbackOrder=''html5'', ''flash'', ''links''\nwmode=default\nflashPlayerVersion=9\n\n'),
(52, 'AllVideos (by JoomlaWorks)', 'jw_allvideos', 'content', 0, 0, 1, 0, 0, 0, '0000-00-00 00:00:00', 'gzipScripts=1\nvfolder=images/video_gallery\nvwidth=350\nvheight=250\ntransparency=transparent\nbackground=#010101\nbackgroundQT=green\ncontrolBarLocation=over\nlightboxLink=1\nlightboxWidth=800\nlightboxHeight=600\nafolder=images/stories/audio\nawidth=300\naheight=20\nautoplay=0\ndownloadLink=1\nembedForm=1\ndebugMode=1\n\n'),
(54, 'Content - pPGallery', 'ppgallery', 'content', 0, 0, 1, 0, 0, 0, '0000-00-00 00:00:00', 'width=200\nheight=130\ncrop=0\nfixed_w=0\nvalign=middle\npadd_h=5\npadd_v=5\nquality_jpg=75\nquality_png=6\nlogo=-1\nlogo_pos=9\ncaption=none\nt_limit=\npre_txt=\nlnk_pop=\nt_only=0\ncssclass_sfx=\nsubfolders=0\nfilter=\nppTitle=1\nppResize=1\nppSlide=\nppSlideAuto=0\nppThumbs=1\nppSep=/\nppTheme=dark_rounded\nppAni=normal\nppOpac=0.80\nppModal=0\nppHidef=0\ncsvfile=ppgallery.txt\nplgstring=ppgallery\nnoconflict=1\n\n'),
(55, 'Ignite Gallery Plugin v2.7.3', 'igallery', 'content', 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00', ''),
(56, 'Simple Image Gallery (by JoomlaWorks)', 'jw_simpleImageGallery', 'content', 0, 0, 1, 0, 0, 62, '2011-04-11 03:56:11', 'galleries_rootfolder=images/image_galleries\nthb_width=150\nthb_height=120\njpg_quality=160\nsmartResize=1\ngalleryMessages=1\ncache_expire_time=120\nmemoryLimit=\n\n');

-- --------------------------------------------------------

--
-- Table structure for table `jos_polls`
--

CREATE TABLE IF NOT EXISTS `jos_polls` (
  `id` int(11) unsigned NOT NULL auto_increment,
  `title` varchar(255) NOT NULL default '',
  `alias` varchar(255) NOT NULL default '',
  `voters` int(9) NOT NULL default '0',
  `checked_out` int(11) NOT NULL default '0',
  `checked_out_time` datetime NOT NULL default '0000-00-00 00:00:00',
  `published` tinyint(1) NOT NULL default '0',
  `access` int(11) NOT NULL default '0',
  `lag` int(11) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `jos_polls`
--


-- --------------------------------------------------------

--
-- Table structure for table `jos_poll_data`
--

CREATE TABLE IF NOT EXISTS `jos_poll_data` (
  `id` int(11) NOT NULL auto_increment,
  `pollid` int(11) NOT NULL default '0',
  `text` text NOT NULL,
  `hits` int(11) NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `pollid` (`pollid`,`text`(1))
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `jos_poll_data`
--


-- --------------------------------------------------------

--
-- Table structure for table `jos_poll_date`
--

CREATE TABLE IF NOT EXISTS `jos_poll_date` (
  `id` bigint(20) NOT NULL auto_increment,
  `date` datetime NOT NULL default '0000-00-00 00:00:00',
  `vote_id` int(11) NOT NULL default '0',
  `poll_id` int(11) NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `poll_id` (`poll_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `jos_poll_date`
--


-- --------------------------------------------------------

--
-- Table structure for table `jos_poll_menu`
--

CREATE TABLE IF NOT EXISTS `jos_poll_menu` (
  `pollid` int(11) NOT NULL default '0',
  `menuid` int(11) NOT NULL default '0',
  PRIMARY KEY  (`pollid`,`menuid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `jos_poll_menu`
--


-- --------------------------------------------------------

--
-- Table structure for table `jos_sections`
--

CREATE TABLE IF NOT EXISTS `jos_sections` (
  `id` int(11) NOT NULL auto_increment,
  `title` varchar(255) NOT NULL default '',
  `name` varchar(255) NOT NULL default '',
  `alias` varchar(255) NOT NULL default '',
  `image` text NOT NULL,
  `scope` varchar(50) NOT NULL default '',
  `image_position` varchar(30) NOT NULL default '',
  `description` text NOT NULL,
  `published` tinyint(1) NOT NULL default '0',
  `checked_out` int(11) unsigned NOT NULL default '0',
  `checked_out_time` datetime NOT NULL default '0000-00-00 00:00:00',
  `ordering` int(11) NOT NULL default '0',
  `access` tinyint(3) unsigned NOT NULL default '0',
  `count` int(11) NOT NULL default '0',
  `params` text NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `idx_scope` (`scope`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `jos_sections`
--

INSERT INTO `jos_sections` (`id`, `title`, `name`, `alias`, `image`, `scope`, `image_position`, `description`, `published`, `checked_out`, `checked_out_time`, `ordering`, `access`, `count`, `params`) VALUES
(1, 'Travel Guide', '', 'travel-guide', '', 'content', 'left', '', 1, 0, '0000-00-00 00:00:00', 1, 0, 3, ''),
(2, 'Tours', '', 'tours', '', 'content', 'left', '', 1, 0, '0000-00-00 00:00:00', 2, 0, 8, ''),
(3, 'Hotels', '', 'hotels', '', 'content', 'left', '', 1, 0, '0000-00-00 00:00:00', 3, 0, 8, '');

-- --------------------------------------------------------

--
-- Table structure for table `jos_session`
--

CREATE TABLE IF NOT EXISTS `jos_session` (
  `username` varchar(150) default '',
  `time` varchar(14) default '',
  `session_id` varchar(200) NOT NULL default '0',
  `guest` tinyint(4) default '1',
  `userid` int(11) default '0',
  `usertype` varchar(50) default '',
  `gid` tinyint(3) unsigned NOT NULL default '0',
  `client_id` tinyint(3) unsigned NOT NULL default '0',
  `data` longtext,
  PRIMARY KEY  (`session_id`(64)),
  KEY `whosonline` (`guest`,`usertype`),
  KEY `userid` (`userid`),
  KEY `time` (`time`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `jos_session`
--

INSERT INTO `jos_session` (`username`, `time`, `session_id`, `guest`, `userid`, `usertype`, `gid`, `client_id`, `data`) VALUES
('admin', '1304305915', '5bec3d6f08b8e0375cbf5dc38622a494', 0, 62, 'Super Administrator', 25, 1, '__default|a:8:{s:15:"session.counter";i:126;s:19:"session.timer.start";i:1304302546;s:18:"session.timer.last";i:1304305910;s:17:"session.timer.now";i:1304305915;s:22:"session.client.browser";s:90:"Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US; rv:1.9.2.17) Gecko/20110420 Firefox/3.6.17";s:8:"registry";O:9:"JRegistry":3:{s:17:"_defaultNameSpace";s:7:"session";s:9:"_registry";a:5:{s:7:"session";a:1:{s:4:"data";O:8:"stdClass":0:{}}s:11:"application";a:1:{s:4:"data";O:8:"stdClass":1:{s:4:"lang";s:0:"";}}s:10:"com_cpanel";a:1:{s:4:"data";O:8:"stdClass":1:{s:9:"mtupgrade";O:8:"stdClass":1:{s:7:"checked";b:1;}}}s:6:"global";a:1:{s:4:"data";O:8:"stdClass":1:{s:4:"list";O:8:"stdClass":1:{s:5:"limit";s:2:"20";}}}s:13:"com_installer";a:1:{s:4:"data";O:8:"stdClass":1:{s:10:"limitstart";O:8:"stdClass":1:{s:9:"component";i:0;}}}}s:7:"_errors";a:0:{}}s:4:"user";O:5:"JUser":19:{s:2:"id";s:2:"62";s:4:"name";s:13:"Administrator";s:8:"username";s:5:"admin";s:5:"email";s:21:"reachponlue@yahoo.com";s:8:"password";s:65:"89d1aa74831e72a244a021148163e48d:Lg53zC9LsNjefg5lmMyL1IdkZwG9JNHj";s:14:"password_clear";s:0:"";s:8:"usertype";s:19:"Super Administrator";s:5:"block";s:1:"0";s:9:"sendEmail";s:1:"1";s:3:"gid";s:2:"25";s:12:"registerDate";s:19:"2011-04-01 21:34:26";s:13:"lastvisitDate";s:19:"2011-05-02 00:55:32";s:10:"activation";s:0:"";s:6:"params";s:56:"admin_language=\nlanguage=\neditor=\nhelpsite=\ntimezone=0\n\n";s:3:"aid";i:2;s:5:"guest";i:0;s:7:"_params";O:10:"JParameter":7:{s:4:"_raw";s:0:"";s:4:"_xml";N;s:9:"_elements";a:0:{}s:12:"_elementPath";a:1:{i:0;s:61:"C:\\xampp\\htdocs\\tours\\libraries\\joomla\\html\\parameter\\element";}s:17:"_defaultNameSpace";s:8:"_default";s:9:"_registry";a:1:{s:8:"_default";a:1:{s:4:"data";O:8:"stdClass":5:{s:14:"admin_language";s:0:"";s:8:"language";s:0:"";s:6:"editor";s:0:"";s:8:"helpsite";s:0:"";s:8:"timezone";s:1:"0";}}}s:7:"_errors";a:0:{}}s:9:"_errorMsg";N;s:7:"_errors";a:0:{}}s:13:"session.token";s:32:"7abc47f4316d5baf2493c321049ef06c";}');

-- --------------------------------------------------------

--
-- Table structure for table `jos_stats_agents`
--

CREATE TABLE IF NOT EXISTS `jos_stats_agents` (
  `agent` varchar(255) NOT NULL default '',
  `type` tinyint(1) unsigned NOT NULL default '0',
  `hits` int(11) unsigned NOT NULL default '1'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `jos_stats_agents`
--


-- --------------------------------------------------------

--
-- Table structure for table `jos_tbooking`
--

CREATE TABLE IF NOT EXISTS `jos_tbooking` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `fullname` varchar(250) NOT NULL,
  `address` varchar(500) NOT NULL,
  `gender` varchar(10) NOT NULL,
  `dob` date default NULL,
  `countries` varchar(150) default NULL,
  `mail` varchar(250) default NULL,
  `tcode` varchar(50) default NULL,
  `hotel` varchar(50) default NULL,
  `idt` int(4) default NULL,
  `departuredate` date default NULL,
  `rp_single` tinyint(4) default NULL,
  `rp_double` tinyint(4) default NULL,
  `rp_twin` tinyint(4) default NULL,
  `np_adult` tinyint(4) default NULL,
  `np_child` tinyint(4) default NULL,
  `detail` varchar(500) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `jos_tbooking`
--


-- --------------------------------------------------------

--
-- Table structure for table `jos_templates_menu`
--

CREATE TABLE IF NOT EXISTS `jos_templates_menu` (
  `template` varchar(255) NOT NULL default '',
  `menuid` int(11) NOT NULL default '0',
  `client_id` tinyint(4) NOT NULL default '0',
  PRIMARY KEY  (`menuid`,`client_id`,`template`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `jos_templates_menu`
--

INSERT INTO `jos_templates_menu` (`template`, `menuid`, `client_id`) VALUES
('ja_purity', 0, 0),
('khepri', 0, 1);

-- --------------------------------------------------------

--
-- Table structure for table `jos_ttbooking`
--

CREATE TABLE IF NOT EXISTS `jos_ttbooking` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `fullname` varchar(250) NOT NULL,
  `address` varchar(500) NOT NULL,
  `gender` varchar(10) NOT NULL,
  `dob` date default NULL,
  `countries` varchar(150) default NULL,
  `mail` varchar(250) default NULL,
  `tcode` varchar(50) default NULL,
  `hotel` varchar(50) default NULL,
  `idt` int(4) default NULL,
  `departuredate` date default NULL,
  `rp_single` tinyint(4) default NULL,
  `rp_double` tinyint(4) default NULL,
  `rp_twin` tinyint(4) default NULL,
  `np_adult` tinyint(4) default NULL,
  `np_child` tinyint(4) default NULL,
  `detail` varchar(500) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `jos_ttbooking`
--


-- --------------------------------------------------------

--
-- Table structure for table `jos_users`
--

CREATE TABLE IF NOT EXISTS `jos_users` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(255) NOT NULL default '',
  `username` varchar(150) NOT NULL default '',
  `email` varchar(100) NOT NULL default '',
  `password` varchar(100) NOT NULL default '',
  `usertype` varchar(25) NOT NULL default '',
  `block` tinyint(4) NOT NULL default '0',
  `sendEmail` tinyint(4) default '0',
  `gid` tinyint(3) unsigned NOT NULL default '1',
  `registerDate` datetime NOT NULL default '0000-00-00 00:00:00',
  `lastvisitDate` datetime NOT NULL default '0000-00-00 00:00:00',
  `activation` varchar(100) NOT NULL default '',
  `params` text NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `usertype` (`usertype`),
  KEY `idx_name` (`name`),
  KEY `gid_block` (`gid`,`block`),
  KEY `username` (`username`),
  KEY `email` (`email`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=64 ;

--
-- Dumping data for table `jos_users`
--

INSERT INTO `jos_users` (`id`, `name`, `username`, `email`, `password`, `usertype`, `block`, `sendEmail`, `gid`, `registerDate`, `lastvisitDate`, `activation`, `params`) VALUES
(62, 'Administrator', 'admin', 'reachponlue@yahoo.com', '89d1aa74831e72a244a021148163e48d:Lg53zC9LsNjefg5lmMyL1IdkZwG9JNHj', 'Super Administrator', 0, 1, 25, '2011-04-01 21:34:26', '2011-05-02 02:15:55', '', 'admin_language=\nlanguage=\neditor=\nhelpsite=\ntimezone=0\n\n'),
(63, 'reach ponlue', 'reachponlue', 'reachponlue@gmail.com', '1d2057a2e17a5bf0965e9a3810558420:FBLTYgBSGIgh29bg4GPyG55cwrrZI1sk', 'Super Administrator', 0, 0, 25, '2011-04-07 13:34:59', '2011-04-08 08:22:52', '', 'admin_language=en-GB\nlanguage=en-GB\neditor=\nhelpsite=\ntimezone=0\n\n');

-- --------------------------------------------------------

--
-- Table structure for table `jos_vvcounter_logs`
--

CREATE TABLE IF NOT EXISTS `jos_vvcounter_logs` (
  `time` int(10) unsigned NOT NULL,
  `visits` mediumint(8) unsigned NOT NULL default '0',
  `guests` mediumint(8) unsigned NOT NULL default '0',
  `members` mediumint(8) unsigned NOT NULL default '0',
  `bots` mediumint(8) unsigned NOT NULL default '0',
  UNIQUE KEY `time` (`time`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `jos_vvcounter_logs`
--

INSERT INTO `jos_vvcounter_logs` (`time`, `visits`, `guests`, `members`, `bots`) VALUES
(1302364807, 2, 1, 1, 0),
(1302365784, 3, 2, 0, 1),
(1302366707, 0, 0, 0, 0),
(1302368400, 0, 0, 0, 0),
(1302369318, 2, 1, 1, 0),
(1302370286, 4, 1, 0, 3),
(1302371209, 0, 0, 0, 0),
(1302372000, 0, 0, 0, 0),
(1302374478, 1, 1, 0, 0),
(1302393600, 0, 0, 0, 0),
(1302396302, 1, 1, 0, 0),
(1302408000, 0, 0, 0, 0),
(1302411138, 1, 1, 0, 0),
(1302415200, 0, 0, 0, 0),
(1302418711, 1, 1, 0, 0),
(1302418800, 0, 0, 0, 0),
(1302426000, 0, 0, 0, 0),
(1302427717, 1, 1, 0, 0),
(1302428674, 2, 1, 1, 0),
(1302429585, 1, 1, 0, 0),
(1302429600, 0, 0, 0, 0),
(1302433200, 0, 0, 0, 0),
(1302434827, 1, 1, 0, 0),
(1302436462, 1, 1, 0, 0),
(1302436800, 0, 0, 0, 0),
(1302437700, 0, 0, 0, 0),
(1302438820, 0, 0, 0, 0),
(1302439746, 0, 0, 0, 0),
(1302440400, 1, 1, 0, 0),
(1302441312, 1, 1, 0, 0),
(1302442215, 0, 0, 0, 0),
(1302443212, 0, 0, 0, 0),
(1302444000, 0, 0, 0, 0),
(1302444935, 0, 0, 0, 0),
(1302445892, 0, 0, 0, 0),
(1302446801, 4, 4, 0, 0),
(1302447600, 0, 0, 0, 0),
(1302448612, 1, 1, 0, 0),
(1302450387, 1, 1, 0, 0),
(1302451200, 2, 2, 0, 0),
(1302454800, 0, 0, 0, 0),
(1302456972, 1, 1, 0, 0),
(1302458400, 0, 0, 0, 0),
(1302459598, 2, 1, 0, 1),
(1302483600, 0, 0, 0, 0),
(1302484520, 3, 2, 1, 0),
(1302485423, 0, 0, 0, 0),
(1302486344, 0, 0, 0, 0),
(1302487200, 0, 0, 0, 0),
(1302489086, 1, 1, 0, 0),
(1302490800, 0, 0, 0, 0),
(1302491968, 3, 2, 1, 0),
(1302492871, 1, 1, 0, 0),
(1302493826, 0, 0, 0, 0),
(1302494400, 0, 0, 0, 0),
(1302495307, 2, 1, 1, 0),
(1302496513, 2, 2, 0, 0),
(1302497978, 1, 1, 0, 0),
(1302498000, 0, 0, 0, 0),
(1302499094, 0, 0, 0, 0),
(1302499996, 1, 1, 0, 0),
(1302501137, 0, 0, 0, 0),
(1302501600, 0, 0, 0, 0),
(1302502510, 0, 0, 0, 0),
(1302503438, 0, 0, 0, 0),
(1302505200, 0, 0, 0, 0),
(1302506100, 4, 3, 1, 0),
(1302507000, 0, 0, 0, 0),
(1302507902, 0, 0, 0, 0),
(1302508800, 1, 0, 0, 1),
(1302512400, 0, 0, 0, 0),
(1302513550, 1, 1, 0, 0),
(1302514472, 3, 2, 1, 0),
(1302516000, 0, 0, 0, 0),
(1302517096, 1, 1, 0, 0),
(1302544800, 0, 0, 0, 0),
(1302546100, 1, 1, 0, 0),
(1302548400, 0, 0, 0, 0),
(1302549772, 1, 1, 0, 0),
(1302580800, 0, 0, 0, 0),
(1302583325, 1, 1, 0, 0),
(1302588000, 0, 0, 0, 0),
(1302590128, 1, 1, 0, 0),
(1302598800, 0, 0, 0, 0),
(1302602331, 1, 1, 0, 0),
(1302624000, 0, 0, 0, 0),
(1302624901, 2, 2, 0, 0),
(1302656400, 0, 0, 0, 0),
(1302659570, 1, 1, 0, 0),
(1302681600, 0, 0, 0, 0),
(1302684188, 1, 1, 0, 0),
(1302685200, 0, 0, 0, 0),
(1302710400, 0, 0, 0, 0),
(1302714000, 0, 0, 0, 0),
(1302716917, 1, 1, 0, 0),
(1302735600, 0, 0, 0, 0),
(1302738986, 1, 1, 0, 0),
(1302757200, 0, 0, 0, 0),
(1302759720, 1, 1, 0, 0),
(1302793200, 0, 0, 0, 0),
(1302796372, 1, 1, 0, 0),
(1302843600, 0, 0, 0, 0),
(1302845793, 1, 1, 0, 0),
(1302850800, 0, 0, 0, 0),
(1302853553, 1, 1, 0, 0),
(1302861600, 0, 0, 0, 0),
(1302862960, 1, 1, 0, 0),
(1302955200, 0, 0, 0, 0),
(1302958428, 1, 1, 0, 0),
(1302962400, 0, 0, 0, 0),
(1302963317, 1, 1, 0, 0),
(1302966000, 0, 0, 0, 0),
(1302968545, 1, 1, 0, 0),
(1303009200, 0, 0, 0, 0),
(1303010434, 1, 1, 0, 0),
(1303016400, 0, 0, 0, 0),
(1303017349, 1, 1, 0, 0),
(1303018848, 1, 1, 0, 0),
(1303020000, 0, 0, 0, 0),
(1303021623, 1, 1, 0, 0),
(1303023600, 0, 0, 0, 0),
(1303024791, 1, 1, 0, 0),
(1303034400, 0, 0, 0, 0),
(1303036098, 1, 1, 0, 0),
(1303041600, 0, 0, 0, 0),
(1303044712, 1, 1, 0, 0),
(1303088400, 0, 0, 0, 0),
(1303090256, 1, 1, 0, 0),
(1303091449, 1, 1, 0, 0),
(1303092000, 0, 0, 0, 0),
(1303093551, 1, 1, 0, 0),
(1303095600, 0, 0, 0, 0),
(1303097010, 2, 1, 0, 1),
(1303110000, 0, 0, 0, 0),
(1303113383, 1, 1, 0, 0),
(1303117200, 0, 0, 0, 0),
(1303119637, 1, 1, 0, 0),
(1303120800, 1, 1, 0, 0),
(1303122835, 1, 1, 0, 0),
(1303124400, 0, 0, 0, 0),
(1303174800, 0, 0, 0, 0),
(1303176338, 1, 1, 0, 0),
(1303178400, 0, 0, 0, 0),
(1303181638, 1, 1, 0, 0),
(1303182000, 1, 1, 0, 0),
(1303192800, 0, 0, 0, 0),
(1303195437, 1, 1, 0, 0),
(1303218000, 0, 0, 0, 0),
(1303219784, 1, 1, 0, 0),
(1303221600, 0, 0, 0, 0),
(1303223498, 1, 1, 0, 0),
(1303225147, 1, 1, 0, 0),
(1303225200, 0, 0, 0, 0),
(1303226234, 2, 1, 1, 0),
(1303257600, 0, 0, 0, 0),
(1303260004, 1, 1, 0, 0),
(1303261152, 1, 1, 0, 0),
(1303261200, 0, 0, 0, 0),
(1303272000, 0, 0, 0, 0),
(1303273776, 1, 1, 0, 0),
(1303286400, 0, 0, 0, 0),
(1303287998, 1, 1, 0, 0),
(1303289449, 1, 1, 0, 0),
(1303290000, 0, 0, 0, 0),
(1303293184, 1, 1, 0, 0),
(1303293600, 0, 0, 0, 0),
(1303295622, 1, 1, 0, 0),
(1303297200, 0, 0, 0, 0),
(1303299339, 1, 1, 0, 0),
(1303300402, 2, 2, 0, 0),
(1303300800, 2, 1, 1, 0),
(1303301852, 0, 0, 0, 0),
(1303303533, 0, 0, 0, 0),
(1303308000, 0, 0, 0, 0),
(1303310491, 1, 1, 0, 0),
(1303318800, 0, 0, 0, 0),
(1303321226, 1, 1, 0, 0),
(1303322400, 0, 0, 0, 0),
(1303324690, 1, 1, 0, 0),
(1303326000, 0, 0, 0, 0),
(1303327344, 2, 2, 0, 0),
(1303329600, 0, 0, 0, 0),
(1303340400, 0, 0, 0, 0),
(1303343540, 1, 1, 0, 0),
(1303344000, 0, 0, 0, 0),
(1303346571, 1, 1, 0, 0),
(1303347600, 1, 1, 0, 0),
(1303348790, 0, 0, 0, 0),
(1303349826, 2, 1, 0, 1),
(1303350987, 0, 0, 0, 0),
(1303351200, 0, 0, 0, 0),
(1303352253, 0, 0, 0, 0),
(1303353170, 0, 0, 0, 0),
(1303354332, 0, 0, 0, 0),
(1303354800, 0, 0, 0, 0),
(1303355702, 0, 0, 0, 0),
(1303356608, 5, 4, 1, 0),
(1303357522, 0, 0, 0, 0),
(1303358400, 0, 0, 0, 0),
(1303359850, 0, 0, 0, 0),
(1303360753, 0, 0, 0, 0),
(1303361671, 1, 1, 0, 0),
(1303362000, 1, 1, 0, 0),
(1303363054, 0, 0, 0, 0),
(1303365600, 0, 0, 0, 0),
(1303366829, 3, 2, 1, 0),
(1303367789, 1, 1, 0, 0),
(1303369200, 0, 0, 0, 0),
(1303370904, 1, 1, 0, 0),
(1303371813, 4, 3, 1, 0),
(1303372800, 0, 0, 0, 0),
(1303373709, 1, 1, 0, 0),
(1303374629, 1, 1, 0, 0),
(1303375696, 8, 1, 0, 7),
(1303376400, 0, 0, 0, 0),
(1303377325, 0, 0, 0, 0),
(1303378269, 0, 0, 0, 0),
(1303379816, 1, 1, 0, 0),
(1303380000, 0, 0, 0, 0),
(1303382090, 1, 1, 0, 0),
(1303383000, 1, 1, 0, 0),
(1303383600, 0, 0, 0, 0),
(1303405200, 0, 0, 0, 0),
(1303416000, 0, 0, 0, 0),
(1303418013, 1, 1, 0, 0),
(1303423200, 0, 0, 0, 0),
(1303426465, 1, 1, 0, 0),
(1303430400, 0, 0, 0, 0),
(1303433594, 1, 1, 0, 0),
(1303434000, 0, 0, 0, 0),
(1303435752, 1, 1, 0, 0),
(1303437136, 1, 1, 0, 0),
(1303437600, 0, 0, 0, 0),
(1303438532, 3, 2, 1, 0),
(1303440137, 1, 1, 0, 0),
(1303441200, 0, 0, 0, 0),
(1303442805, 1, 1, 0, 0),
(1303443720, 3, 2, 0, 1),
(1303444800, 0, 0, 0, 0),
(1303446875, 1, 1, 0, 0),
(1303455600, 0, 0, 0, 0),
(1303457858, 1, 1, 0, 0),
(1303458908, 3, 2, 1, 0),
(1303459200, 0, 0, 0, 0),
(1303460148, 1, 1, 0, 0),
(1303461605, 1, 1, 0, 0),
(1303462671, 0, 0, 0, 0),
(1303462800, 0, 0, 0, 0),
(1303464348, 0, 0, 0, 0),
(1303466400, 0, 0, 0, 0),
(1303468273, 1, 1, 0, 0),
(1303469705, 2, 2, 0, 0),
(1303470000, 0, 0, 0, 0),
(1303470971, 1, 1, 0, 0),
(1303471991, 0, 0, 0, 0),
(1303477200, 0, 0, 0, 0),
(1303480800, 0, 0, 0, 0),
(1303483014, 1, 1, 0, 0),
(1303506000, 0, 0, 0, 0),
(1303509378, 1, 1, 0, 0),
(1303527600, 0, 0, 0, 0),
(1303530975, 1, 1, 0, 0),
(1303531200, 0, 0, 0, 0),
(1303532247, 2, 2, 0, 0),
(1303533172, 2, 1, 1, 0),
(1303534506, 2, 2, 0, 0),
(1303534800, 1, 1, 0, 0),
(1303535777, 1, 1, 0, 0),
(1303536692, 0, 0, 0, 0),
(1303537712, 0, 0, 0, 0),
(1303538400, 0, 0, 0, 0),
(1303539306, 0, 0, 0, 0),
(1303540257, 1, 1, 0, 0),
(1303552800, 0, 0, 0, 0),
(1303553703, 3, 2, 1, 0),
(1303554606, 2, 2, 0, 0),
(1303555595, 5, 5, 0, 0),
(1303556400, 0, 0, 0, 0),
(1303557441, 1, 1, 0, 0),
(1303559135, 1, 1, 0, 0),
(1303560000, 0, 0, 0, 0),
(1303561711, 1, 1, 0, 0),
(1303562901, 1, 1, 0, 0),
(1303578000, 0, 0, 0, 0),
(1303588800, 0, 0, 0, 0),
(1303591740, 1, 1, 0, 0),
(1303610400, 0, 0, 0, 0),
(1303612428, 1, 1, 0, 0),
(1303613341, 2, 1, 1, 0),
(1303614000, 0, 0, 0, 0),
(1303615211, 1, 1, 0, 0),
(1303616120, 3, 2, 1, 0),
(1303617600, 0, 0, 0, 0),
(1303618521, 4, 3, 1, 0),
(1303635600, 0, 0, 0, 0),
(1303637010, 2, 2, 0, 0),
(1303637975, 0, 0, 0, 0),
(1303638896, 1, 1, 0, 0),
(1303639200, 0, 0, 0, 0),
(1303640228, 1, 1, 0, 0),
(1303641189, 1, 1, 0, 0),
(1303642466, 1, 1, 0, 0),
(1303642800, 0, 0, 0, 0),
(1303643715, 0, 0, 0, 0),
(1303644617, 2, 2, 0, 0),
(1303645529, 0, 0, 0, 0),
(1303646400, 0, 0, 0, 0),
(1303647300, 2, 2, 0, 0),
(1303648407, 2, 2, 0, 0),
(1303649333, 3, 2, 1, 0),
(1303650000, 0, 0, 0, 0),
(1303650901, 0, 0, 0, 0),
(1303675200, 0, 0, 0, 0),
(1303696800, 0, 0, 0, 0),
(1303698768, 1, 1, 0, 0),
(1303700400, 0, 0, 0, 0),
(1303714800, 0, 0, 0, 0),
(1303716842, 1, 1, 0, 0),
(1303743600, 0, 0, 0, 0),
(1303745566, 1, 1, 0, 0),
(1303746890, 1, 1, 0, 0),
(1303747200, 0, 0, 0, 0),
(1303748386, 1, 1, 0, 0),
(1303749503, 1, 0, 1, 0),
(1303758000, 0, 0, 0, 0),
(1303776000, 0, 0, 0, 0),
(1303779212, 1, 1, 0, 0),
(1303779600, 0, 0, 0, 0),
(1303780607, 1, 1, 0, 0),
(1303790400, 0, 0, 0, 0),
(1303791488, 1, 1, 0, 0),
(1303793051, 1, 1, 0, 0),
(1303801200, 0, 0, 0, 0),
(1303804398, 1, 1, 0, 0),
(1303804800, 0, 0, 0, 0),
(1303808344, 1, 1, 0, 0),
(1303808400, 0, 0, 0, 0),
(1303810837, 1, 1, 0, 0),
(1303811828, 2, 2, 0, 0),
(1303815600, 0, 0, 0, 0),
(1303816600, 3, 2, 1, 0),
(1303818259, 1, 1, 0, 0),
(1303819200, 0, 0, 0, 0),
(1303822800, 0, 0, 0, 0),
(1303824714, 1, 1, 0, 0),
(1303825846, 1, 1, 0, 0),
(1303826400, 0, 0, 0, 0),
(1303827892, 1, 1, 0, 0),
(1303833600, 0, 0, 0, 0),
(1303855200, 0, 0, 0, 0),
(1303857860, 1, 1, 0, 0),
(1303898400, 0, 0, 0, 0),
(1303900340, 1, 1, 0, 0),
(1303945200, 0, 0, 0, 0),
(1303947875, 1, 1, 0, 0),
(1303948800, 0, 0, 0, 0),
(1303950525, 1, 1, 0, 0),
(1303966800, 0, 0, 0, 0),
(1303967953, 1, 1, 0, 0),
(1303968867, 1, 1, 0, 0),
(1303984800, 0, 0, 0, 0),
(1303986577, 1, 1, 0, 0),
(1303987491, 1, 1, 0, 0),
(1303988400, 0, 0, 0, 0),
(1303989357, 1, 1, 0, 0),
(1303990487, 0, 0, 0, 0),
(1303991504, 0, 0, 0, 0),
(1303992000, 0, 0, 0, 0),
(1303992984, 0, 0, 0, 0),
(1303994044, 0, 0, 0, 0),
(1303994949, 0, 0, 0, 0),
(1303995600, 0, 0, 0, 0),
(1304024400, 0, 0, 0, 0),
(1304026114, 1, 1, 0, 0),
(1304038800, 0, 0, 0, 0),
(1304042120, 1, 1, 0, 0),
(1304042400, 0, 0, 0, 0),
(1304044297, 1, 1, 0, 0),
(1304045688, 1, 1, 0, 0),
(1304046000, 0, 0, 0, 0),
(1304048411, 1, 1, 0, 0),
(1304049328, 1, 1, 0, 0),
(1304049600, 0, 0, 0, 0),
(1304050514, 1, 1, 0, 0),
(1304053200, 0, 0, 0, 0),
(1304054100, 1, 1, 0, 0),
(1304056537, 1, 1, 0, 0),
(1304056800, 0, 0, 0, 0),
(1304058050, 0, 0, 0, 0),
(1304059498, 1, 1, 0, 0),
(1304071200, 0, 0, 0, 0),
(1304073107, 1, 1, 0, 0),
(1304074800, 0, 0, 0, 0),
(1304077645, 1, 1, 0, 0),
(1304078400, 1, 1, 0, 0),
(1304079780, 3, 2, 1, 0),
(1304080780, 0, 0, 0, 0),
(1304081683, 0, 0, 0, 0),
(1304082000, 0, 0, 0, 0),
(1304083315, 0, 0, 0, 0),
(1304089200, 0, 0, 0, 0),
(1304090569, 2, 1, 1, 0),
(1304092800, 0, 0, 0, 0),
(1304093979, 1, 1, 0, 0),
(1304095712, 1, 1, 0, 0),
(1304096400, 0, 0, 0, 0),
(1304097714, 0, 0, 0, 0),
(1304099105, 0, 0, 0, 0),
(1304100000, 0, 0, 0, 0),
(1304101167, 1, 1, 0, 0),
(1304102227, 0, 0, 0, 0),
(1304128800, 0, 0, 0, 0),
(1304129981, 2, 2, 0, 0),
(1304132400, 0, 0, 0, 0),
(1304134310, 1, 1, 0, 0),
(1304135225, 0, 0, 0, 0),
(1304161200, 0, 0, 0, 0),
(1304162143, 2, 1, 1, 0),
(1304164800, 0, 0, 0, 0),
(1304166807, 1, 1, 0, 0),
(1304226000, 0, 0, 0, 0),
(1304229078, 1, 1, 0, 0),
(1304229600, 1, 1, 0, 0),
(1304233200, 0, 0, 0, 0),
(1304235714, 1, 1, 0, 0),
(1304236631, 1, 0, 1, 0),
(1304236800, 0, 0, 0, 0),
(1304237775, 0, 0, 0, 0),
(1304238798, 0, 0, 0, 0),
(1304240040, 0, 0, 0, 0),
(1304240400, 0, 0, 0, 0),
(1304241302, 0, 0, 0, 0),
(1304244000, 0, 0, 0, 0),
(1304247600, 0, 0, 0, 0),
(1304248724, 1, 1, 0, 0),
(1304249817, 1, 0, 1, 0),
(1304254800, 0, 0, 0, 0),
(1304255727, 2, 2, 0, 0),
(1304256630, 0, 0, 0, 0),
(1304257726, 0, 0, 0, 0),
(1304258400, 1, 1, 0, 0),
(1304262000, 0, 0, 0, 0),
(1304264123, 1, 1, 0, 0),
(1304265600, 0, 0, 0, 0),
(1304266540, 0, 0, 0, 0),
(1304267647, 0, 0, 0, 0),
(1304269200, 0, 0, 0, 0),
(1304270633, 1, 1, 0, 0),
(1304271569, 1, 0, 1, 0),
(1304272800, 0, 0, 0, 0),
(1304273825, 3, 2, 1, 0),
(1304274924, 0, 0, 0, 0),
(1304294400, 0, 0, 0, 0),
(1304296556, 1, 1, 0, 0),
(1304297723, 1, 1, 0, 0),
(1304298000, 1, 1, 0, 0),
(1304299161, 0, 0, 0, 0),
(1304300232, 0, 0, 0, 0),
(1304301132, 0, 0, 0, 0),
(1304301600, 0, 0, 0, 0),
(1304302546, 2, 2, 0, 0),
(1304303454, 0, 0, 0, 0),
(1304304417, 0, 0, 0, 0),
(1304305200, 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `jos_weblinks`
--

CREATE TABLE IF NOT EXISTS `jos_weblinks` (
  `id` int(11) unsigned NOT NULL auto_increment,
  `catid` int(11) NOT NULL default '0',
  `sid` int(11) NOT NULL default '0',
  `title` varchar(250) NOT NULL default '',
  `alias` varchar(255) NOT NULL default '',
  `url` varchar(250) NOT NULL default '',
  `description` text NOT NULL,
  `date` datetime NOT NULL default '0000-00-00 00:00:00',
  `hits` int(11) NOT NULL default '0',
  `published` tinyint(1) NOT NULL default '0',
  `checked_out` int(11) NOT NULL default '0',
  `checked_out_time` datetime NOT NULL default '0000-00-00 00:00:00',
  `ordering` int(11) NOT NULL default '0',
  `archived` tinyint(1) NOT NULL default '0',
  `approved` tinyint(1) NOT NULL default '1',
  `params` text NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `catid` (`catid`,`published`,`archived`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `jos_weblinks`
--

